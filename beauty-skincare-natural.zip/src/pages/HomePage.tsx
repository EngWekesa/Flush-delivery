import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { formatPrice } from '@/lib/formatPrice';
import ProductCard from '@/components/ProductCard';
import { Star, Leaf, Shield, Recycle, Droplets, Sun, Sparkles, ArrowRight, ChevronLeft, ChevronRight } from 'lucide-react';
import { toast } from 'sonner';

const HERO_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601711651_4319719d.jpg';
const LIFESTYLE_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601948858_085f0240.png';
const POPPY_OIL_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601982143_48f52fc6.png';
const SHEA_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775602029812_3a54d901.png';
const CALENDULA_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775602047701_f0a45298.jpg';

const PROJECT_ID = window.location.hostname.split('.')[0];

const reviews = [
  { name: 'Sarah M.', rating: 5, text: 'The Hydrating Poppy Lotion is absolutely divine! My skin has never felt softer. The scent is subtle and beautiful.', product: 'Hydrating Poppy Body Lotion' },
  { name: 'Amina K.', rating: 5, text: 'I bought the gift set for my mum and she loved it! The packaging is gorgeous and the products are top quality.', product: 'Poppy Essentials Gift Set' },
  { name: 'Grace W.', rating: 4, text: 'The Golden Poppy Body Oil is my new holy grail. It absorbs so fast and leaves my skin glowing all day.', product: 'Golden Poppy Body Oil' },
  { name: 'Diana L.', rating: 5, text: 'Finally found a soap that doesn\'t dry out my sensitive skin. The Lavender & Oat bar is perfect for bedtime.', product: 'Lavender & Oat Calming Bar' },
  { name: 'Joy N.', rating: 5, text: 'The Calendula lotion saved my skin during the dry season. So soothing and gentle. Will definitely repurchase!', product: 'Calendula Soothing Lotion' },
  { name: 'Faith O.', rating: 4, text: 'Love the Mini Discovery Set — perfect for trying everything before committing. The Jasmine Night Oil is my favourite!', product: 'Mini Discovery Set' },
];

const blogPosts = [
  { title: 'How to Layer Body Oils for Maximum Glow', excerpt: 'Learn the art of layering body oils with lotions for all-day hydration and radiance...', date: 'Mar 28, 2026', image: POPPY_OIL_IMG },
  { title: 'Benefits of Poppy Seed Oil for Your Skin', excerpt: 'Discover why poppy seed oil is our hero ingredient and how it transforms your skin...', date: 'Mar 15, 2026', image: LIFESTYLE_IMG },
  { title: 'Gift Ideas Under KSH 5,000', excerpt: 'Thoughtful, luxurious gifts that won\'t break the bank. Perfect for any occasion...', date: 'Mar 5, 2026', image: SHEA_IMG },
];

const HomePage: React.FC = () => {
  const [products, setProducts] = useState<any[]>([]);
  const [collections, setCollections] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewIndex, setReviewIndex] = useState(0);
  const [promoEmail, setPromoEmail] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchData = async () => {
      const [productsRes, collectionsRes] = await Promise.all([
        supabase.from('ecom_products').select('*, variants:ecom_product_variants(*)').eq('status', 'active').limit(8),
        supabase.from('ecom_collections').select('*').eq('is_visible', true),
      ]);
      if (productsRes.data) setProducts(productsRes.data);
      if (collectionsRes.data) setCollections(collectionsRes.data);
      setLoading(false);
    };
    fetchData();
  }, []);

  const featuredCollections = collections.filter(c => ['bestsellers', 'new-arrivals', 'gift-sets'].includes(c.handle));

  const handlePromoSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoEmail.trim()) return;
    try {
      await fetch(`https://famous.ai/api/crm/${PROJECT_ID}/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: promoEmail, source: 'popup', tags: ['newsletter', 'promo-15off'] })
      });
    } catch {}
    toast.success('Welcome! Check your email for your 15% off code.');
    setPromoEmail('');
  };

  return (
    <div className="min-h-screen bg-white">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={HERO_IMG} alt="LushPoppy Products" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-black/40 to-transparent" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 lg:py-40">
          <div className="max-w-2xl">
            <span className="inline-block px-4 py-1.5 bg-rose-500/20 text-rose-200 rounded-full text-sm font-medium mb-6 backdrop-blur-sm border border-rose-400/30">
              Handcrafted in Kenya
            </span>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-serif font-bold text-white leading-tight">
              Lush<span className="text-rose-400">Poppy</span> — Handcrafted, Petal-Soft Body Care
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-gray-200 leading-relaxed max-w-xl">
              Clean botanicals, indulgent textures, and sustainable packaging for skin that glows.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 mt-8">
              <Link to="/collections/bestsellers"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-rose-500 text-white font-semibold rounded-xl hover:bg-rose-600 transition shadow-lg shadow-rose-500/30">
                Shop Bestsellers <ArrowRight size={18} />
              </Link>
              <Link to="/ingredients"
                className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white/10 text-white font-semibold rounded-xl hover:bg-white/20 transition backdrop-blur-sm border border-white/20">
                Explore Ingredients
              </Link>
            </div>
            <div className="flex flex-wrap gap-6 mt-8 text-sm text-gray-300">
              <span className="flex items-center gap-2"><Shield size={16} className="text-rose-400" /> Free Shipping</span>
              <span className="flex items-center gap-2"><Recycle size={16} className="text-rose-400" /> 30-Day Returns</span>
              <span className="flex items-center gap-2"><Leaf size={16} className="text-rose-400" /> Cruelty-Free</span>
            </div>
          </div>
        </div>
      </section>

      {/* FEATURED COLLECTIONS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">Find Your Daily Ritual</h2>
          <p className="text-gray-500 mt-3 max-w-lg mx-auto">Discover our curated collections or find the perfect present.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {(featuredCollections.length > 0 ? featuredCollections : [
            { handle: 'bestsellers', title: 'Bestsellers', description: 'Our most loved products', image_url: HERO_IMG },
            { handle: 'new-arrivals', title: 'New Arrivals', description: 'Fresh drops and seasonal favourites', image_url: LIFESTYLE_IMG },
            { handle: 'gift-sets', title: 'Gift Sets', description: 'Beautifully packaged sets for every occasion', image_url: SHEA_IMG },
          ]).map((col: any) => (
            <Link key={col.handle} to={`/collections/${col.handle}`}
              className="group relative rounded-2xl overflow-hidden aspect-[4/3] shadow-lg hover:shadow-xl transition-all">
              <img src={col.image_url || HERO_IMG} alt={col.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <h3 className="text-2xl font-serif font-bold text-white">{col.title}</h3>
                <p className="text-gray-200 text-sm mt-1">{col.description}</p>
                <span className="inline-flex items-center gap-1 mt-3 text-rose-300 font-medium text-sm group-hover:text-rose-200 transition">
                  Shop Now <ArrowRight size={14} />
                </span>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* BRAND PROMISE */}
      <section className="bg-gradient-to-b from-rose-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">Why LushPoppy</h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { icon: Leaf, title: 'Clean Ingredients', desc: 'Plant-forward formulas, Leaping Bunny approved. No parabens, sulfates, or synthetic fragrances.' },
              { icon: Shield, title: 'Gentle & Effective', desc: 'Dermatologist-tested formulas that deliver real results without irritation.' },
              { icon: Recycle, title: 'Sustainable Packaging', desc: 'Recyclable materials, minimal waste, and refill options. Beauty that respects the planet.' },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="text-center p-8 bg-white rounded-2xl shadow-sm hover:shadow-md transition border border-gray-100">
                <div className="w-16 h-16 mx-auto bg-rose-100 rounded-2xl flex items-center justify-center mb-5">
                  <Icon size={28} className="text-rose-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
                <p className="text-gray-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
          <p className="text-center text-gray-600 mt-10 max-w-2xl mx-auto leading-relaxed">
            At LushPoppy we pair time-honored botanical extracts with modern skincare science to create products that feel luxurious and perform beautifully.
          </p>
        </div>
      </section>

      {/* TOP PRODUCTS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">Top Products</h2>
            <p className="text-gray-500 mt-2">Handpicked favourites loved by our community</p>
          </div>
          <Link to="/collections/bestsellers" className="hidden sm:inline-flex items-center gap-2 text-rose-500 font-medium hover:text-rose-600 transition">
            View All <ArrowRight size={16} />
          </Link>
        </div>
        {loading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="bg-gray-100 rounded-2xl aspect-[4/5] animate-pulse" />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {products.slice(0, 8).map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
        <div className="text-center mt-8 sm:hidden">
          <Link to="/collections/bestsellers" className="inline-flex items-center gap-2 px-6 py-3 bg-rose-500 text-white rounded-xl font-medium hover:bg-rose-600 transition">
            View All Products <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">Your Daily Ritual</h2>
            <p className="text-gray-500 mt-3">Three simple steps to glowing skin</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { step: '01', icon: Droplets, title: 'Choose Your Scent & Texture', desc: 'Explore our range of lotions, oils, and soaps. Find your perfect match.' },
              { step: '02', icon: Sun, title: 'Use Daily', desc: 'Gentle cleanse, hydrate, and protect. Build a routine that fits your lifestyle.' },
              { step: '03', icon: Sparkles, title: 'Glow Naturally', desc: 'See and feel the results. Radiant, healthy skin that speaks for itself.' },
            ].map(({ step, icon: Icon, title, desc }) => (
              <div key={step} className="relative text-center p-8">
                <span className="text-6xl font-serif font-bold text-rose-100">{step}</span>
                <div className="w-14 h-14 mx-auto bg-rose-500 rounded-2xl flex items-center justify-center -mt-4 mb-5 shadow-lg shadow-rose-500/20">
                  <Icon size={24} className="text-white" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
                <p className="text-gray-500">{desc}</p>
              </div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link to="/collections/bestsellers" className="inline-flex items-center gap-2 px-6 py-3 bg-rose-500 text-white rounded-xl font-semibold hover:bg-rose-600 transition">
              Build Your Routine <ArrowRight size={16} />
            </Link>
          </div>
        </div>
      </section>

      {/* INGREDIENT SPOTLIGHT */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">Ingredient Spotlight</h2>
          <p className="text-gray-500 mt-3">The botanicals behind the glow</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { name: 'Poppy Seed Oil', benefit: 'Rich in linoleic acid for deep hydration and skin radiance', faq: 'Sustainably sourced from organic poppy farms', image: POPPY_OIL_IMG },
            { name: 'Shea Butter', benefit: 'Intense moisture and protection with vitamins A, E & F', faq: 'Fair-trade, unrefined for maximum potency', image: SHEA_IMG },
            { name: 'Calendula Extract', benefit: 'Soothes inflammation and promotes skin healing', faq: 'Gentle enough for the most sensitive skin', image: CALENDULA_IMG },
          ].map(ing => (
            <div key={ing.name} className="group rounded-2xl overflow-hidden bg-white shadow-sm hover:shadow-lg transition border border-gray-100">
              <div className="aspect-square overflow-hidden">
                <img src={ing.image} alt={ing.name} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold text-gray-900 mb-2">{ing.name}</h3>
                <p className="text-gray-600 mb-2">{ing.benefit}</p>
                <p className="text-sm text-rose-500 italic">{ing.faq}</p>
              </div>
            </div>
          ))}
        </div>
        <div className="text-center mt-10">
          <Link to="/ingredients" className="inline-flex items-center gap-2 text-rose-500 font-medium hover:text-rose-600 transition">
            Learn About All Ingredients <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* REVIEWS / SOCIAL PROOF */}
      <section className="bg-gradient-to-b from-amber-50 to-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">What Our Customers Say</h2>
            <div className="flex items-center justify-center gap-1 mt-3">
              {[...Array(5)].map((_, i) => <Star key={i} size={20} className="fill-amber-400 text-amber-400" />)}
              <span className="ml-2 text-gray-600 font-medium">4.8 / 5 from 500+ reviews</span>
            </div>
          </div>
          <div className="relative">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {reviews.slice(reviewIndex, reviewIndex + 3).map((review, i) => (
                <div key={i} className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100">
                  <div className="flex items-center gap-1 mb-3">
                    {[...Array(5)].map((_, j) => (
                      <Star key={j} size={14} className={j < review.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-200'} />
                    ))}
                  </div>
                  <p className="text-gray-700 leading-relaxed mb-4">"{review.text}"</p>
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-rose-500 font-bold text-sm">
                      {review.name.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900 text-sm">{review.name}</p>
                      <p className="text-xs text-gray-400">Verified Buyer — {review.product}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
            <div className="flex justify-center gap-3 mt-8">
              <button onClick={() => setReviewIndex(Math.max(0, reviewIndex - 3))} disabled={reviewIndex === 0}
                className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:bg-rose-50 hover:border-rose-300 transition disabled:opacity-30">
                <ChevronLeft size={18} />
              </button>
              <button onClick={() => setReviewIndex(Math.min(reviews.length - 3, reviewIndex + 3))} disabled={reviewIndex >= reviews.length - 3}
                className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:bg-rose-50 hover:border-rose-300 transition disabled:opacity-30">
                <ChevronRight size={18} />
              </button>
            </div>
          </div>
          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-6 mt-12">
            {['Cruelty-Free', 'Vegan Options', 'Made in Kenya', 'Secure Checkout', 'Free Shipping'].map(badge => (
              <span key={badge} className="flex items-center gap-2 px-4 py-2 bg-white rounded-full shadow-sm border border-gray-100 text-sm text-gray-600">
                <Shield size={14} className="text-rose-400" /> {badge}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* PROMO / EMAIL CAPTURE */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0">
          <img src={LIFESTYLE_IMG} alt="" className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-rose-900/80 backdrop-blur-sm" />
        </div>
        <div className="relative max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center">
          <h2 className="text-3xl sm:text-4xl font-serif font-bold text-white">Join the Poppy Circle</h2>
          <p className="text-rose-200 mt-4 text-lg">15% off your first order, exclusive early drops, skincare tips, and members-only bundles.</p>
          <form onSubmit={handlePromoSubmit} className="flex flex-col sm:flex-row gap-3 mt-8 max-w-md mx-auto">
            <input type="email" value={promoEmail} onChange={e => setPromoEmail(e.target.value)} required
              placeholder="Enter your email" className="flex-1 px-5 py-3.5 rounded-xl bg-white/10 text-white placeholder-rose-200 border border-white/20 focus:outline-none focus:ring-2 focus:ring-white/40" />
            <button type="submit" className="px-6 py-3.5 bg-white text-rose-600 font-bold rounded-xl hover:bg-rose-50 transition shadow-lg">
              Get 15% Off
            </button>
          </form>
          <p className="text-rose-300 text-xs mt-4">We never spam. Unsubscribe anytime.</p>
        </div>
      </section>

      {/* BLOG TEASER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="flex items-end justify-between mb-10">
          <div>
            <h2 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">From Our Journal</h2>
            <p className="text-gray-500 mt-2">Tips, stories, and skincare wisdom</p>
          </div>
          <Link to="/blog" className="hidden sm:inline-flex items-center gap-2 text-rose-500 font-medium hover:text-rose-600 transition">
            Read All <ArrowRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {blogPosts.map(post => (
            <Link key={post.title} to="/blog" className="group rounded-2xl overflow-hidden bg-white shadow-sm hover:shadow-lg transition border border-gray-100">
              <div className="aspect-[16/10] overflow-hidden">
                <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-5">
                <p className="text-xs text-rose-400 font-medium mb-2">{post.date}</p>
                <h3 className="text-lg font-bold text-gray-900 group-hover:text-rose-500 transition">{post.title}</h3>
                <p className="text-gray-500 text-sm mt-2 line-clamp-2">{post.excerpt}</p>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* INSTAGRAM / UGC */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-8">
          <h2 className="text-2xl font-serif font-bold text-gray-900">@LushPoppy on Instagram</h2>
          <p className="text-gray-500 mt-2">Tag us to be featured</p>
        </div>
        <div className="grid grid-cols-3 md:grid-cols-6 gap-1 max-w-7xl mx-auto px-4">
          {[HERO_IMG, POPPY_OIL_IMG, SHEA_IMG, CALENDULA_IMG, LIFESTYLE_IMG, HERO_IMG].map((img, i) => (
            <a key={i} href="#" className="aspect-square overflow-hidden group">
              <img src={img} alt="Instagram" className="w-full h-full object-cover group-hover:scale-110 group-hover:opacity-80 transition-all duration-300" />
            </a>
          ))}
        </div>
        <div className="text-center mt-6">
          <a href="#" className="inline-flex items-center gap-2 text-rose-500 font-medium hover:text-rose-600 transition">
            Follow Us on Instagram <ArrowRight size={16} />
          </a>
        </div>
      </section>
    </div>
  );
};

export default HomePage;
