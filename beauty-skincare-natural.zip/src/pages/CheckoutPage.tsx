import React, { useState, useEffect } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { loadStripe } from '@stripe/stripe-js';
import { Elements, PaymentElement, useStripe, useElements } from '@stripe/react-stripe-js';
import { supabase } from '@/lib/supabase';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/lib/formatPrice';
import { ArrowLeft, Lock, Truck, Shield } from 'lucide-react';

const STRIPE_ACCOUNT_ID = 'STRIPE_ACCOUNT_ID';
const stripePromise = STRIPE_ACCOUNT_ID && STRIPE_ACCOUNT_ID !== 'STRIPE_ACCOUNT_ID'
  ? loadStripe('pk_live_51OJhJBHdGQpsHqInIzu7c6PzGPSH0yImD4xfpofvxvFZs0VFhPRXZCyEgYkkhOtBOXFWvssYASs851mflwQvjnrl00T6DbUwWZ', { stripeAccount: STRIPE_ACCOUNT_ID })
  : null;

const SHIPPING_RULES = "Free shipping on all orders";
const PROJECT_ID = window.location.hostname.split('.')[0];

function PaymentForm({ onSuccess }: { onSuccess: (pi: any) => void }) {
  const stripe = useStripe();
  const elements = useElements();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!stripe || !elements) return;
    setLoading(true);
    setError('');

    const { error: submitError, paymentIntent } = await stripe.confirmPayment({
      elements,
      redirect: 'if_required'
    });

    if (submitError) {
      setError(submitError.message || 'Payment failed');
      setLoading(false);
    } else if (paymentIntent?.status === 'succeeded') {
      onSuccess(paymentIntent);
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <PaymentElement />
      {error && <p className="text-red-500 mt-3 text-sm">{error}</p>}
      <button type="submit" disabled={!stripe || loading}
        className="w-full mt-6 py-4 bg-rose-500 text-white font-semibold rounded-xl hover:bg-rose-600 transition disabled:opacity-50 flex items-center justify-center gap-2">
        <Lock size={18} />
        {loading ? 'Processing Payment...' : 'Pay Now'}
      </button>
    </form>
  );
}

const CheckoutPage: React.FC = () => {
  const { cart, cartTotal, clearCart } = useCart();
  const navigate = useNavigate();
  const [step, setStep] = useState<'shipping' | 'payment'>('shipping');
  const [clientSecret, setClientSecret] = useState('');
  const [paymentError, setPaymentError] = useState('');
  const [shippingCost, setShippingCost] = useState(0);
  const [tax, setTax] = useState(0);
  const [calculatingTax, setCalculatingTax] = useState(false);
  const [address, setAddress] = useState({
    name: '', email: '', phone: '', address: '', city: '', state: '', zip: '', country: 'Kenya'
  });

  useEffect(() => {
    if (cart.length === 0) navigate('/cart');
  }, []);

  // Calculate shipping
  useEffect(() => {
    const calcShipping = async () => {
      const { data } = await supabase.functions.invoke('calculate-shipping', {
        body: {
          cartItems: cart.map(i => ({ name: i.name, quantity: i.quantity, price: i.price })),
          shippingRules: SHIPPING_RULES,
          subtotal: cartTotal
        }
      });
      if (data?.success) setShippingCost(data.shippingCents);
    };
    if (cart.length > 0) calcShipping();
  }, [cart, cartTotal]);

  const calculateTax = async (state: string) => {
    if (!state) return;
    setCalculatingTax(true);
    const { data } = await supabase.functions.invoke('calculate-tax', {
      body: { state, subtotal: cartTotal }
    });
    if (data?.success) setTax(data.taxCents);
    setCalculatingTax(false);
  };

  const total = cartTotal + shippingCost + tax;

  const handleShippingSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!address.name || !address.email || !address.address || !address.city) return;

    // Calculate tax based on state/region
    await calculateTax(address.state || address.city);

    // Create payment intent
    const { data, error } = await supabase.functions.invoke('create-payment-intent', {
      body: { amount: cartTotal + shippingCost + tax, currency: 'kes' }
    });

    if (error || !data?.clientSecret) {
      setPaymentError('Unable to initialize payment. Please try again.');
      setStep('payment');
      return;
    }

    setClientSecret(data.clientSecret);
    setStep('payment');
  };

  const handlePaymentSuccess = async (paymentIntent: any) => {
    try {
      // Create or find customer
      const { data: customer } = await supabase
        .from('ecom_customers')
        .upsert({ email: address.email, name: address.name, phone: address.phone }, { onConflict: 'email' })
        .select('id')
        .single();

      // Create order
      const { data: order } = await supabase
        .from('ecom_orders')
        .insert({
          customer_id: customer?.id,
          status: 'paid',
          subtotal: cartTotal,
          tax,
          shipping: shippingCost,
          total,
          shipping_address: address,
          stripe_payment_intent_id: paymentIntent.id,
        })
        .select('id')
        .single();

      if (order) {
        const orderItems = cart.map(item => ({
          order_id: order.id,
          product_id: item.product_id,
          variant_id: item.variant_id || null,
          product_name: item.name,
          variant_title: item.variant_title || null,
          sku: item.sku || null,
          quantity: item.quantity,
          unit_price: item.price,
          total: item.price * item.quantity,
        }));
        await supabase.from('ecom_order_items').insert(orderItems);

        // Send confirmation email
        try {
          const { data: orderItemsData } = await supabase.from('ecom_order_items').select('*').eq('order_id', order.id);
          await fetch(`https://famous.ai/api/ecommerce/${PROJECT_ID}/send-confirmation`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              orderId: order.id,
              customerEmail: address.email,
              customerName: address.name,
              orderItems: orderItemsData,
              subtotal: cartTotal,
              shipping: shippingCost,
              tax,
              total,
              shippingAddress: address
            })
          });
        } catch {}

        clearCart();
        navigate(`/order-confirmation?orderId=${order.id}`);
      }
    } catch (err) {
      console.error('Order creation error:', err);
      clearCart();
      navigate('/order-confirmation');
    }
  };

  if (cart.length === 0) return null;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/cart" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-rose-500 transition mb-6">
          <ArrowLeft size={16} /> Back to Cart
        </Link>

        <div className="grid lg:grid-cols-5 gap-8">
          {/* Form */}
          <div className="lg:col-span-3">
            {/* Steps */}
            <div className="flex items-center gap-4 mb-8">
              <button onClick={() => setStep('shipping')}
                className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium transition ${step === 'shipping' ? 'bg-rose-500 text-white' : 'bg-gray-200 text-gray-600'}`}>
                1. Shipping
              </button>
              <div className="h-px flex-1 bg-gray-200" />
              <span className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium ${step === 'payment' ? 'bg-rose-500 text-white' : 'bg-gray-200 text-gray-600'}`}>
                2. Payment
              </span>
            </div>

            {step === 'shipping' ? (
              <form onSubmit={handleShippingSubmit} className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-100">
                <h2 className="text-xl font-bold text-gray-900 mb-6">Shipping Information</h2>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                    <input type="text" required value={address.name} onChange={e => setAddress({ ...address, name: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                    <input type="email" required value={address.email} onChange={e => setAddress({ ...address, email: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Phone</label>
                    <input type="tel" value={address.phone} onChange={e => setAddress({ ...address, phone: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-medium text-gray-700 mb-1">Address *</label>
                    <input type="text" required value={address.address} onChange={e => setAddress({ ...address, address: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                    <input type="text" required value={address.city} onChange={e => setAddress({ ...address, city: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">County/State</label>
                    <input type="text" value={address.state} onChange={e => setAddress({ ...address, state: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Postal Code</label>
                    <input type="text" value={address.zip} onChange={e => setAddress({ ...address, zip: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Country</label>
                    <input type="text" value={address.country} onChange={e => setAddress({ ...address, country: e.target.value })}
                      className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                  </div>
                </div>
                <button type="submit"
                  className="w-full mt-6 py-4 bg-rose-500 text-white font-semibold rounded-xl hover:bg-rose-600 transition flex items-center justify-center gap-2">
                  Continue to Payment
                </button>
              </form>
            ) : (
              <div className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-gray-100">
                <h2 className="text-xl font-bold text-gray-900 mb-2">Payment</h2>
                <p className="text-sm text-gray-500 mb-6">Shipping to: {address.name}, {address.city}</p>

                {!stripePromise ? (
                  <div className="bg-amber-50 border border-amber-200 p-6 rounded-xl">
                    <p className="text-amber-800 font-medium">Payment processing is being set up.</p>
                    <p className="text-amber-600 text-sm mt-1">Please check back soon or contact us via WhatsApp at 0708 770 746.</p>
                  </div>
                ) : paymentError ? (
                  <div className="bg-red-50 border border-red-200 p-6 rounded-xl">
                    <p className="text-red-800">{paymentError}</p>
                    <button onClick={() => setStep('shipping')} className="mt-2 text-sm text-red-600 underline">Try again</button>
                  </div>
                ) : clientSecret ? (
                  <Elements stripe={stripePromise} options={{ clientSecret }}>
                    <PaymentForm onSuccess={handlePaymentSuccess} />
                  </Elements>
                ) : (
                  <div className="flex items-center justify-center py-12">
                    <div className="animate-spin w-8 h-8 border-2 border-rose-500 border-t-transparent rounded-full" />
                    <span className="ml-3 text-gray-500">Loading payment form...</span>
                  </div>
                )}

                <div className="flex items-center gap-2 mt-4 text-xs text-gray-400">
                  <Lock size={12} /> Your payment information is encrypted and secure
                </div>
              </div>
            )}
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 sticky top-24">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Order Summary</h2>
              <div className="space-y-3 max-h-60 overflow-y-auto">
                {cart.map(item => (
                  <div key={item.product_id + item.variant_id} className="flex gap-3">
                    {item.image && <img src={item.image} alt={item.name} className="w-14 h-14 rounded-lg object-cover flex-shrink-0" />}
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{item.name}</p>
                      {item.variant_title && <p className="text-xs text-gray-500">{item.variant_title}</p>}
                      <div className="flex justify-between mt-1">
                        <span className="text-xs text-gray-400">Qty: {item.quantity}</span>
                        <span className="text-sm font-medium">{formatPrice(item.price * item.quantity)}</span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="border-t border-gray-100 mt-4 pt-4 space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Subtotal</span>
                  <span className="font-medium">{formatPrice(cartTotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Shipping</span>
                  <span className="font-medium text-green-600">{shippingCost === 0 ? 'Free' : formatPrice(shippingCost)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Tax (VAT 16%)</span>
                  <span className="font-medium">{calculatingTax ? '...' : formatPrice(tax)}</span>
                </div>
                <div className="border-t border-gray-100 pt-2 flex justify-between">
                  <span className="font-bold text-gray-900">Total</span>
                  <span className="font-bold text-gray-900 text-lg">{formatPrice(total)}</span>
                </div>
              </div>

              <div className="flex items-center gap-3 mt-6 p-3 bg-green-50 rounded-xl">
                <Truck size={18} className="text-green-600 flex-shrink-0" />
                <p className="text-sm text-green-700">Free shipping on your order!</p>
              </div>

              <div className="flex items-center gap-2 mt-3">
                <Shield size={14} className="text-gray-400" />
                <span className="text-xs text-gray-400">Secure checkout powered by Stripe</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckoutPage;
