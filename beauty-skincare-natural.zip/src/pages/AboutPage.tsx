import React from 'react';
import { Link } from 'react-router-dom';
import { Leaf, Heart, FlaskConical, Users, ArrowRight } from 'lucide-react';

const HERO_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601711651_4319719d.jpg';
const LIFESTYLE_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601948858_085f0240.png';
const CALENDULA_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775602047701_f0a45298.jpg';

const AboutPage: React.FC = () => {
  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-r from-rose-50 to-amber-50 py-20 lg:py-28">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <span className="text-rose-500 font-medium text-sm uppercase tracking-wider">Our Story</span>
              <h1 className="text-4xl lg:text-5xl font-serif font-bold text-gray-900 mt-3 leading-tight">
                Born from a Love of Botanicals and Simple Rituals
              </h1>
              <p className="text-gray-600 mt-6 text-lg leading-relaxed">
                LushPoppy crafts small-batch body care inspired by fields of poppies and simple self-care rituals. We combine botanical extracts and modern formulation to deliver gentle, effective products for everyday glow.
              </p>
            </div>
            <div className="rounded-2xl overflow-hidden shadow-2xl">
              <img src={LIFESTYLE_IMG} alt="LushPoppy founder" className="w-full h-full object-cover" />
            </div>
          </div>
        </div>
      </section>

      {/* Founder Story */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="rounded-2xl overflow-hidden">
            <img src={CALENDULA_IMG} alt="Poppy fields" className="w-full aspect-[4/3] object-cover rounded-2xl" />
          </div>
          <div>
            <span className="text-rose-500 font-medium text-sm uppercase tracking-wider">The Beginning</span>
            <h2 className="text-3xl font-serif font-bold text-gray-900 mt-3">A Family Recipe, A Field of Poppies</h2>
            <p className="text-gray-600 mt-4 leading-relaxed">
              It started with a grandmother's recipe — a simple blend of poppy seed oil, shea butter, and calendula that kept skin soft through every season. Growing up surrounded by the vibrant poppy fields of the Kenyan highlands, our founder discovered that nature's most beautiful flowers also held powerful skincare secrets.
            </p>
            <p className="text-gray-600 mt-4 leading-relaxed">
              What began as a kitchen experiment became a passion. After years of studying botanical skincare science and perfecting formulations, LushPoppy was born — a brand that honours traditional wisdom while embracing modern innovation.
            </p>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="bg-gray-50 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-serif font-bold text-gray-900">Our Mission & Values</h2>
            <p className="text-gray-500 mt-3 max-w-2xl mx-auto">Every product we create is guided by three core principles</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Leaf, title: 'Sustainable Ingredients', desc: 'We source responsibly, choosing organic and fair-trade ingredients whenever possible. Our packaging is recyclable and minimal — because beautiful skin shouldn\'t cost the earth.' },
              { icon: Heart, title: 'Accessible Luxury', desc: 'We believe everyone deserves to feel pampered. Our products deliver luxury-grade results at prices that make daily self-care possible for all.' },
              { icon: Users, title: 'Community First', desc: 'We support local farmers, employ local artisans, and reinvest in our community. When you buy LushPoppy, you\'re supporting real people and real livelihoods.' },
            ].map(({ icon: Icon, title, desc }) => (
              <div key={title} className="bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                <div className="w-14 h-14 bg-rose-100 rounded-2xl flex items-center justify-center mb-5">
                  <Icon size={24} className="text-rose-500" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{title}</h3>
                <p className="text-gray-500 leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Process */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <span className="text-rose-500 font-medium text-sm uppercase tracking-wider">Our Process</span>
            <h2 className="text-3xl font-serif font-bold text-gray-900 mt-3">Small-Batch, Big Heart</h2>
            <div className="space-y-6 mt-6">
              {[
                { icon: FlaskConical, title: 'Formulated with Care', desc: 'Every product is developed in small batches, allowing us to maintain the highest quality standards and freshness.' },
                { icon: Leaf, title: 'Third-Party Tested', desc: 'All formulas are dermatologist-tested and independently verified for safety and efficacy.' },
                { icon: Heart, title: 'Cruelty-Free Always', desc: 'We never test on animals. Our Leaping Bunny certification guarantees ethical practices at every stage.' },
              ].map(({ icon: Icon, title, desc }) => (
                <div key={title} className="flex gap-4">
                  <div className="w-12 h-12 bg-rose-100 rounded-xl flex items-center justify-center flex-shrink-0">
                    <Icon size={20} className="text-rose-500" />
                  </div>
                  <div>
                    <h3 className="font-bold text-gray-900">{title}</h3>
                    <p className="text-gray-500 mt-1">{desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div className="rounded-2xl overflow-hidden">
            <img src={HERO_IMG} alt="Our process" className="w-full aspect-[4/3] object-cover rounded-2xl" />
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gradient-to-r from-rose-500 to-rose-400 py-16">
        <div className="max-w-4xl mx-auto px-4 text-center">
          <h2 className="text-3xl font-serif font-bold text-white">Ready to Experience LushPoppy?</h2>
          <p className="text-rose-100 mt-3 text-lg">Discover our handcrafted collection and find your perfect ritual.</p>
          <Link to="/collections/bestsellers"
            className="inline-flex items-center gap-2 mt-6 px-8 py-4 bg-white text-rose-500 font-bold rounded-xl hover:bg-rose-50 transition shadow-lg">
            Meet the Products <ArrowRight size={18} />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default AboutPage;
