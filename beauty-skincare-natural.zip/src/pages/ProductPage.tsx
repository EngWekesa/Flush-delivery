import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/lib/formatPrice';
import ProductCard from '@/components/ProductCard';
import { Star, Minus, Plus, ShoppingBag, Zap, Truck, RotateCcw, Shield, ChevronDown, ChevronUp, Leaf } from 'lucide-react';

const ProductPage: React.FC = () => {
  const { handle } = useParams<{ handle: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const [product, setProduct] = useState<any>(null);
  const [selectedVariant, setSelectedVariant] = useState<any>(null);
  const [selectedSize, setSelectedSize] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [loading, setLoading] = useState(true);
  const [showIngredients, setShowIngredients] = useState(false);
  const [relatedProducts, setRelatedProducts] = useState<any[]>([]);

  useEffect(() => {
    const fetchProduct = async () => {
      setSelectedVariant(null);
      setSelectedSize('');
      setQuantity(1);
      setLoading(true);

      const { data } = await supabase
        .from('ecom_products')
        .select('*, variants:ecom_product_variants(*)')
        .eq('handle', handle)
        .single();

      if (data) {
        let variants = data.variants || [];
        if (data.has_variants && variants.length === 0) {
          const { data: variantData } = await supabase
            .from('ecom_product_variants')
            .select('*')
            .eq('product_id', data.id)
            .order('position');
          variants = variantData || [];
          data.variants = variants;
        }

        setProduct(data);

        if (variants.length > 0) {
          const sorted = [...variants].sort((a: any, b: any) => (a.position || 0) - (b.position || 0));
          const firstInStock = sorted.find((v: any) => v.inventory_qty == null || v.inventory_qty > 0) || sorted[0];
          setSelectedVariant(firstInStock);
          setSelectedSize(firstInStock?.option1 || '');
        }

        // Fetch related products
        const { data: related } = await supabase
          .from('ecom_products')
          .select('*, variants:ecom_product_variants(*)')
          .eq('status', 'active')
          .eq('product_type', data.product_type)
          .neq('id', data.id)
          .limit(4);
        if (related) setRelatedProducts(related);
      }
      setLoading(false);
    };
    fetchProduct();
  }, [handle]);

  const handleSizeSelect = (size: string) => {
    setSelectedSize(size);
    const variant = product?.variants?.find((v: any) =>
      v.option1 === size || v.title?.toLowerCase().includes(size.toLowerCase())
    );
    if (variant) setSelectedVariant(variant);
  };

  const variantSizes = [...new Set(product?.variants?.map((v: any) => v.option1).filter(Boolean) || [])];
  const hasVariants = product?.has_variants && product?.variants?.length > 0;

  const getInStock = (): boolean => {
    if (selectedVariant) {
      if (selectedVariant.inventory_qty == null) return true;
      return selectedVariant.inventory_qty > 0;
    }
    if (product?.variants && product.variants.length > 0) {
      return product.variants.some((v: any) => v.inventory_qty == null || v.inventory_qty > 0);
    }
    if (product?.has_variants) return true;
    if (product?.inventory_qty == null) return true;
    return product.inventory_qty > 0;
  };
  const inStock = getInStock();

  const handleAddToCart = () => {
    if (!product) return;
    if (hasVariants && !selectedSize) return;
    if (!inStock) return;

    addToCart({
      product_id: product.id,
      variant_id: selectedVariant?.id || undefined,
      name: product.name,
      variant_title: selectedVariant?.title || selectedSize || undefined,
      sku: selectedVariant?.sku || product.sku || product.handle,
      price: selectedVariant?.price || product.price,
      image: product.images?.[0],
    }, quantity);
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/cart');
  };

  const currentPrice = selectedVariant?.price || product?.price || 0;
  const rating = 4.5;
  const reviewCount = 47;

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 gap-12">
          <div className="bg-gray-100 rounded-2xl aspect-square animate-pulse" />
          <div className="space-y-4">
            <div className="h-6 bg-gray-200 rounded w-1/3 animate-pulse" />
            <div className="h-10 bg-gray-200 rounded w-2/3 animate-pulse" />
            <div className="h-4 bg-gray-200 rounded w-1/2 animate-pulse" />
          </div>
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-20 text-center">
        <h1 className="text-2xl font-bold text-gray-900">Product not found</h1>
        <Link to="/collections/bestsellers" className="mt-4 inline-block text-rose-500 hover:text-rose-600">Browse products</Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Breadcrumb */}
        <nav className="flex items-center gap-2 text-sm text-gray-400 mb-8">
          <Link to="/" className="hover:text-rose-500 transition">Home</Link>
          <span>/</span>
          <Link to={`/collections/${product.product_type?.toLowerCase().replace(/\s+/g, '-').replace('&', '')}`} className="hover:text-rose-500 transition">
            {product.product_type}
          </Link>
          <span>/</span>
          <span className="text-gray-700 truncate">{product.name}</span>
        </nav>

        <div className="grid md:grid-cols-2 gap-8 lg:gap-12">
          {/* Product Image */}
          <div className="space-y-4">
            <div className="aspect-square rounded-2xl overflow-hidden bg-gray-50">
              <img src={product.images?.[0]} alt={product.name} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
            </div>
            {product.images?.length > 1 && (
              <div className="grid grid-cols-4 gap-2">
                {product.images.map((img: string, i: number) => (
                  <div key={i} className="aspect-square rounded-xl overflow-hidden bg-gray-50 cursor-pointer border-2 border-transparent hover:border-rose-300 transition">
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Product Info */}
          <div>
            <p className="text-sm text-rose-500 font-medium uppercase tracking-wider mb-2">{product.product_type}</p>
            <h1 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900">{product.name}</h1>
            {product.metadata?.scent && (
              <p className="text-gray-500 mt-2">Scent: {product.metadata.scent}</p>
            )}

            {/* Rating */}
            <div className="flex items-center gap-2 mt-3">
              <div className="flex items-center gap-0.5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} size={16} className={i < Math.floor(rating) ? 'fill-amber-400 text-amber-400' : 'text-gray-200'} />
                ))}
              </div>
              <span className="text-sm text-gray-500">{rating} ({reviewCount} reviews)</span>
            </div>

            {/* Price */}
            <div className="mt-6">
              <p className="text-3xl font-bold text-gray-900">{formatPrice(currentPrice)}</p>
              <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
                <Truck size={14} /> Free Shipping
              </p>
            </div>

            {/* Size Selector */}
            {(variantSizes.length > 0) && (
              <div className="mt-6">
                <label className="block font-semibold text-gray-900 mb-3">Select Size</label>
                <div className="flex flex-wrap gap-2">
                  {variantSizes.map((size: string) => {
                    const variant = product.variants?.find((v: any) => v.option1 === size);
                    const sizeInStock = variant ? (variant.inventory_qty == null || variant.inventory_qty > 0) : true;
                    return (
                      <button key={size} onClick={() => sizeInStock && handleSizeSelect(size)} disabled={!sizeInStock}
                        className={`px-5 py-2.5 border-2 rounded-xl font-medium transition-all ${
                          selectedSize === size
                            ? 'bg-rose-500 text-white border-rose-500'
                            : sizeInStock
                            ? 'border-gray-200 hover:border-rose-300 text-gray-700'
                            : 'border-gray-100 text-gray-300 cursor-not-allowed line-through'
                        }`}>
                        {size}
                        {variant && <span className="block text-xs mt-0.5 opacity-75">{formatPrice(variant.price)}</span>}
                      </button>
                    );
                  })}
                </div>
              </div>
            )}

            {/* Quantity */}
            <div className="mt-6">
              <label className="block font-semibold text-gray-900 mb-3">Quantity</label>
              <div className="inline-flex items-center border-2 border-gray-200 rounded-xl overflow-hidden">
                <button onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="px-4 py-3 hover:bg-gray-50 transition"><Minus size={16} /></button>
                <span className="px-6 py-3 font-semibold text-gray-900 min-w-[3rem] text-center">{quantity}</span>
                <button onClick={() => setQuantity(quantity + 1)}
                  className="px-4 py-3 hover:bg-gray-50 transition"><Plus size={16} /></button>
              </div>
            </div>

            {/* Add to Cart & Buy Now */}
            <div className="flex flex-col sm:flex-row gap-3 mt-8">
              <button onClick={handleAddToCart}
                disabled={(hasVariants && !selectedSize) || !inStock}
                className="flex-1 flex items-center justify-center gap-2 py-4 bg-rose-500 text-white font-semibold rounded-xl hover:bg-rose-600 transition disabled:opacity-50 disabled:cursor-not-allowed shadow-lg shadow-rose-500/20">
                <ShoppingBag size={20} />
                {!inStock ? 'Out of Stock' : hasVariants && !selectedSize ? 'Select a Size' : 'Add to Cart'}
              </button>
              <button onClick={handleBuyNow}
                disabled={(hasVariants && !selectedSize) || !inStock}
                className="flex-1 flex items-center justify-center gap-2 py-4 bg-gray-900 text-white font-semibold rounded-xl hover:bg-gray-800 transition disabled:opacity-50 disabled:cursor-not-allowed">
                <Zap size={20} /> Buy Now
              </button>
            </div>

            {/* Trust badges */}
            <div className="grid grid-cols-3 gap-3 mt-6">
              {[
                { icon: Truck, text: 'Free Shipping' },
                { icon: RotateCcw, text: '30-Day Returns' },
                { icon: Shield, text: 'Secure Checkout' },
              ].map(({ icon: Icon, text }) => (
                <div key={text} className="flex flex-col items-center gap-1 p-3 bg-gray-50 rounded-xl text-center">
                  <Icon size={18} className="text-rose-400" />
                  <span className="text-xs text-gray-600">{text}</span>
                </div>
              ))}
            </div>

            {/* Description */}
            <div className="mt-8 border-t border-gray-100 pt-8">
              <h3 className="font-semibold text-gray-900 mb-3">About This Product</h3>
              <p className="text-gray-600 leading-relaxed">{product.description}</p>
            </div>

            {/* Key Benefits */}
            {product.metadata?.key_ingredients && (
              <div className="mt-6">
                <h3 className="font-semibold text-gray-900 mb-3">Key Benefits</h3>
                <ul className="space-y-2">
                  {['Deep hydration without greasiness', 'Plant-based oils that soothe and restore', 'Subtle, natural fragrance from essential oils', 'Sustainable packaging, small-batch care'].map(b => (
                    <li key={b} className="flex items-start gap-2 text-gray-600">
                      <Leaf size={16} className="text-rose-400 flex-shrink-0 mt-0.5" /> {b}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            {/* Ingredients */}
            <div className="mt-6">
              <button onClick={() => setShowIngredients(!showIngredients)}
                className="flex items-center justify-between w-full py-3 border-t border-gray-100 text-gray-900 font-semibold">
                Ingredients
                {showIngredients ? <ChevronUp size={18} /> : <ChevronDown size={18} />}
              </button>
              {showIngredients && (
                <div className="pb-4 text-sm text-gray-500 leading-relaxed">
                  <p className="mb-2"><strong>Key Ingredients:</strong> {product.metadata?.key_ingredients}</p>
                  <p>Aqua, Helianthus Annuus Seed Oil, Butyrospermum Parkii Butter, Papaver Somniferum Seed Oil, Glycerin, Cetearyl Alcohol, Tocopherol (Vitamin E), Calendula Officinalis Extract, Aloe Barbadensis Leaf Juice, Citrus Aurantium Dulcis Oil, Phenoxyethanol.</p>
                  <Link to="/ingredients" className="text-rose-500 hover:text-rose-600 mt-2 inline-block">View full ingredient policy</Link>
                </div>
              )}
            </div>

            {/* How to Use */}
            <div className="mt-2 border-t border-gray-100 pt-4">
              <h3 className="font-semibold text-gray-900 mb-3">How to Use</h3>
              <ol className="space-y-2 text-gray-600 text-sm">
                <li className="flex gap-2"><span className="font-bold text-rose-500">1.</span> Apply to damp skin after shower for best absorption</li>
                <li className="flex gap-2"><span className="font-bold text-rose-500">2.</span> Massage gently in circular motions until fully absorbed</li>
                <li className="flex gap-2"><span className="font-bold text-rose-500">3.</span> Reapply as needed throughout the day for extra hydration</li>
              </ol>
            </div>

            {/* Skin Type */}
            {product.metadata?.skin_type && (
              <div className="mt-4 p-4 bg-rose-50 rounded-xl">
                <p className="text-sm"><strong className="text-gray-900">Best for:</strong> <span className="text-gray-600">{product.metadata.skin_type}</span></p>
              </div>
            )}
          </div>
        </div>

        {/* Related Products */}
        {relatedProducts.length > 0 && (
          <div className="mt-20 border-t border-gray-100 pt-16">
            <h2 className="text-2xl font-serif font-bold text-gray-900 mb-8">Complete the Ritual</h2>
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              {relatedProducts.map(p => <ProductCard key={p.id} product={p} compact />)}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ProductPage;
