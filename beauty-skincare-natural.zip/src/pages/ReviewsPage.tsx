import React, { useState } from 'react';
import { Star, Shield, Award, ThumbsUp, MessageSquare, Leaf } from 'lucide-react';

import { toast } from 'sonner';

const allReviews = [
  { name: 'Sarah M.', rating: 5, text: 'The Hydrating Poppy Lotion is absolutely divine! My skin has never felt softer. The scent is subtle and beautiful — not overpowering at all.', product: 'Hydrating Poppy Body Lotion', date: 'Mar 2026', verified: true },
  { name: 'Amina K.', rating: 5, text: 'I bought the gift set for my mum and she loved it! The packaging is gorgeous and the products are top quality. Will definitely buy again.', product: 'Poppy Essentials Gift Set', date: 'Mar 2026', verified: true },
  { name: 'Grace W.', rating: 4, text: 'The Golden Poppy Body Oil is my new holy grail. It absorbs so fast and leaves my skin glowing all day. Only wish the bottle was bigger!', product: 'Golden Poppy Body Oil', date: 'Feb 2026', verified: true },
  { name: 'Diana L.', rating: 5, text: 'Finally found a soap that doesn\'t dry out my sensitive skin. The Lavender & Oat bar is perfect for bedtime. So calming.', product: 'Lavender & Oat Calming Bar', date: 'Feb 2026', verified: true },
  { name: 'Joy N.', rating: 5, text: 'The Calendula lotion saved my skin during the dry season. So soothing and gentle. Will definitely repurchase!', product: 'Calendula Soothing Lotion', date: 'Jan 2026', verified: true },
  { name: 'Faith O.', rating: 4, text: 'Love the Mini Discovery Set — perfect for trying everything before committing. The Jasmine Night Oil is my favourite!', product: 'Mini Discovery Set', date: 'Jan 2026', verified: true },
  { name: 'Lucy A.', rating: 5, text: 'I\'ve tried so many body lotions and nothing compares to LushPoppy. The Rose & Poppy cream is incredibly rich without being heavy.', product: 'Rose & Poppy Nourishing Cream', date: 'Dec 2025', verified: true },
  { name: 'Mercy T.', rating: 5, text: 'The Charcoal Detox bar has transformed my skin! My pores look smaller and my skin feels so clean. Amazing product.', product: 'Charcoal Detox Cleansing Bar', date: 'Dec 2025', verified: true },
  { name: 'Wanjiku P.', rating: 4, text: 'Great products, fast delivery, and beautiful packaging. The Coconut & Vanilla oil spray smells heavenly!', product: 'Coconut & Vanilla Dry Oil Spray', date: 'Nov 2025', verified: true },
  { name: 'Njeri M.', rating: 5, text: 'Bought the Luxury Spa Night Set for myself as a treat. Worth every shilling! The muslin cloth is a lovely touch.', product: 'Luxury Spa Night Set', date: 'Nov 2025', verified: true },
];

const ReviewsPage: React.FC = () => {
  const [filterRating, setFilterRating] = useState(0);
  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewForm, setReviewForm] = useState({ name: '', product: '', rating: 5, text: '' });

  const filtered = filterRating > 0 ? allReviews.filter(r => r.rating === filterRating) : allReviews;
  const avgRating = (allReviews.reduce((s, r) => s + r.rating, 0) / allReviews.length).toFixed(1);

  const handleSubmitReview = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success('Thank you for your review! It will be published after verification.');
    setShowReviewForm(false);
    setReviewForm({ name: '', product: '', rating: 5, text: '' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-gradient-to-r from-amber-50 to-rose-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-serif font-bold text-gray-900">Customer Reviews</h1>
          <div className="flex items-center justify-center gap-2 mt-4">
            <div className="flex gap-0.5">
              {[...Array(5)].map((_, i) => <Star key={i} size={24} className="fill-amber-400 text-amber-400" />)}
            </div>
            <span className="text-2xl font-bold text-gray-900">{avgRating}</span>
            <span className="text-gray-500">from {allReviews.length} reviews</span>
          </div>
          <button onClick={() => setShowReviewForm(!showReviewForm)}
            className="mt-6 inline-flex items-center gap-2 px-6 py-3 bg-rose-500 text-white rounded-xl font-semibold hover:bg-rose-600 transition">
            <MessageSquare size={18} /> Write a Review
          </button>
        </div>
      </section>

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Review Form */}
        {showReviewForm && (
          <form onSubmit={handleSubmitReview} className="bg-rose-50 rounded-2xl p-6 mb-8 border border-rose-100">
            <h3 className="font-bold text-gray-900 mb-4">Share Your Experience</h3>
            <div className="grid sm:grid-cols-2 gap-4">
              <input type="text" required placeholder="Your name" value={reviewForm.name}
                onChange={e => setReviewForm({ ...reviewForm, name: e.target.value })}
                className="px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 outline-none" />
              <input type="text" required placeholder="Product name" value={reviewForm.product}
                onChange={e => setReviewForm({ ...reviewForm, product: e.target.value })}
                className="px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 outline-none" />
            </div>
            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Rating</label>
              <div className="flex gap-1">
                {[1, 2, 3, 4, 5].map(r => (
                  <button key={r} type="button" onClick={() => setReviewForm({ ...reviewForm, rating: r })}>
                    <Star size={24} className={r <= reviewForm.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-300'} />
                  </button>
                ))}
              </div>
            </div>
            <textarea required placeholder="Tell us about your experience..." rows={4} value={reviewForm.text}
              onChange={e => setReviewForm({ ...reviewForm, text: e.target.value })}
              className="w-full mt-4 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 outline-none resize-none" />
            <div className="flex gap-3 mt-4">
              <button type="submit" className="px-6 py-2.5 bg-rose-500 text-white rounded-xl font-medium hover:bg-rose-600 transition">
                Submit Review
              </button>
              <button type="button" onClick={() => setShowReviewForm(false)} className="px-6 py-2.5 border border-gray-200 rounded-xl text-gray-600 hover:bg-gray-50 transition">
                Cancel
              </button>
            </div>
          </form>
        )}

        {/* Rating Filter */}
        <div className="flex flex-wrap gap-2 mb-8">
          <button onClick={() => setFilterRating(0)}
            className={`px-4 py-2 rounded-full text-sm font-medium transition ${filterRating === 0 ? 'bg-rose-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
            All ({allReviews.length})
          </button>
          {[5, 4, 3].map(r => {
            const count = allReviews.filter(rev => rev.rating === r).length;
            return (
              <button key={r} onClick={() => setFilterRating(r)}
                className={`px-4 py-2 rounded-full text-sm font-medium transition flex items-center gap-1 ${filterRating === r ? 'bg-rose-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}>
                {r} <Star size={12} className={filterRating === r ? 'fill-white' : 'fill-amber-400 text-amber-400'} /> ({count})
              </button>
            );
          })}
        </div>

        {/* Reviews List */}
        <div className="space-y-4">
          {filtered.map((review, i) => (
            <div key={i} className="bg-white rounded-xl p-6 border border-gray-100 hover:border-rose-100 transition">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-rose-100 flex items-center justify-center text-rose-500 font-bold">
                    {review.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-gray-900">{review.name}</p>
                    <div className="flex items-center gap-2">
                      <div className="flex gap-0.5">
                        {[...Array(5)].map((_, j) => (
                          <Star key={j} size={12} className={j < review.rating ? 'fill-amber-400 text-amber-400' : 'text-gray-200'} />
                        ))}
                      </div>
                      {review.verified && (
                        <span className="text-xs text-green-600 font-medium flex items-center gap-0.5">
                          <Shield size={10} /> Verified
                        </span>
                      )}
                    </div>
                  </div>
                </div>
                <span className="text-xs text-gray-400">{review.date}</span>
              </div>
              <p className="text-gray-700 mt-3 leading-relaxed">"{review.text}"</p>
              <p className="text-sm text-rose-500 mt-2 font-medium">{review.product}</p>
            </div>
          ))}
        </div>

        {/* Trust Badges */}
        <div className="mt-16 text-center">
          <h2 className="text-2xl font-serif font-bold text-gray-900 mb-8">Trusted & Certified</h2>
          <div className="flex flex-wrap justify-center gap-6">
            {[
              { icon: Shield, label: 'Cruelty-Free Certified' },
              { icon: Leaf, label: 'Vegan Options Available' },
              { icon: Award, label: 'Dermatologist Tested' },
              { icon: ThumbsUp, label: '500+ Happy Customers' },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex flex-col items-center gap-2 p-4">
                <div className="w-14 h-14 bg-rose-100 rounded-full flex items-center justify-center">
                  <Icon size={24} className="text-rose-500" />
                </div>
                <span className="text-sm font-medium text-gray-700">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ReviewsPage;
