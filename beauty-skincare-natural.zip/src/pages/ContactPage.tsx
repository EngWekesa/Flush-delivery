import React, { useState } from 'react';
import { Phone, Mail, MapPin, Clock, MessageCircle, Send } from 'lucide-react';
import { toast } from 'sonner';

const PROJECT_ID = window.location.hostname.split('.')[0];

const faqs = [
  { q: 'How long does shipping take?', a: 'We offer free shipping on all orders. Standard delivery within Nairobi takes 1-2 business days. Upcountry delivery takes 3-5 business days.' },
  { q: 'What is your return policy?', a: 'We offer a 30-day return policy on all unopened products. If you\'re not satisfied, contact us for a full refund or exchange.' },
  { q: 'How should I store my products?', a: 'Store in a cool, dry place away from direct sunlight. Our products have a shelf life of 12 months after opening.' },
  { q: 'Do you offer samples?', a: 'Yes! Our Mini Discovery Set includes travel sizes of our top 5 products. We also include free samples with every order.' },
  { q: 'Do you offer wholesale pricing?', a: 'Yes, we work with spas, hotels, and retailers. Contact us at wholesale@lushpoppy.com for pricing and minimum orders.' },
  { q: 'Are your products safe for pregnant women?', a: 'Most of our products are safe during pregnancy. However, we recommend consulting your doctor before using products with essential oils.' },
];

const ContactPage: React.FC = () => {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [sending, setSending] = useState(false);
  const [expandedFaq, setExpandedFaq] = useState<number | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSending(true);
    try {
      await fetch(`https://famous.ai/api/crm/${PROJECT_ID}/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          email: form.email,
          name: form.name,
          source: 'contact-form',
          tags: ['contact', form.subject.toLowerCase().replace(/\s+/g, '-')]
        })
      });
    } catch {}
    toast.success('Message sent! We\'ll get back to you within 24 hours.');
    setForm({ name: '', email: '', subject: '', message: '' });
    setSending(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-gradient-to-r from-rose-50 to-amber-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl font-serif font-bold text-gray-900">Get in Touch</h1>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto text-lg">
            We'd love to hear from you. Whether it's a question, feedback, or just to say hello — we're here for you.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Info */}
          <div className="space-y-6">
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-4">Contact Information</h2>
              <div className="space-y-4">
                {[
                  { icon: Phone, label: 'Phone', value: '0708 770 746', href: 'tel:0708770746' },
                  { icon: Mail, label: 'Email', value: 'hello@lushpoppy.com', href: 'mailto:hello@lushpoppy.com' },
                  { icon: MapPin, label: 'Location', value: 'Nairobi, Kenya', href: '#' },
                  { icon: Clock, label: 'Hours', value: 'Mon-Fri 9am-6pm EAT', href: '#' },
                ].map(({ icon: Icon, label, value, href }) => (
                  <a key={label} href={href} className="flex items-start gap-3 p-3 rounded-xl hover:bg-rose-50 transition group">
                    <div className="w-10 h-10 bg-rose-100 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:bg-rose-200 transition">
                      <Icon size={18} className="text-rose-500" />
                    </div>
                    <div>
                      <p className="text-xs text-gray-400 uppercase tracking-wider">{label}</p>
                      <p className="font-medium text-gray-900">{value}</p>
                    </div>
                  </a>
                ))}
              </div>
            </div>

            {/* WhatsApp CTA */}
            <a href="https://wa.me/254708770746" target="_blank" rel="noopener noreferrer"
              className="flex items-center gap-3 p-4 bg-green-50 border border-green-200 rounded-xl hover:bg-green-100 transition">
              <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center">
                <MessageCircle size={22} className="text-white" />
              </div>
              <div>
                <p className="font-semibold text-gray-900">Chat on WhatsApp</p>
                <p className="text-sm text-gray-500">Quick responses, Mon-Sat</p>
              </div>
            </a>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <form onSubmit={handleSubmit} className="bg-white rounded-2xl p-6 sm:p-8 border border-gray-100 shadow-sm">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Send Us a Message</h2>
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Name *</label>
                  <input type="text" required value={form.name} onChange={e => setForm({ ...form, name: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Email *</label>
                  <input type="email" required value={form.email} onChange={e => setForm({ ...form, email: e.target.value })}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
                </div>
              </div>
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Subject *</label>
                <select required value={form.subject} onChange={e => setForm({ ...form, subject: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none">
                  <option value="">Select a topic</option>
                  <option value="Order Inquiry">Order Inquiry</option>
                  <option value="Product Question">Product Question</option>
                  <option value="Shipping & Returns">Shipping & Returns</option>
                  <option value="Wholesale">Wholesale Inquiry</option>
                  <option value="Feedback">Feedback</option>
                  <option value="Other">Other</option>
                </select>
              </div>
              <div className="mt-4">
                <label className="block text-sm font-medium text-gray-700 mb-1">Message *</label>
                <textarea required rows={5} value={form.message} onChange={e => setForm({ ...form, message: e.target.value })}
                  className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none resize-none" />
              </div>
              <button type="submit" disabled={sending}
                className="mt-6 flex items-center justify-center gap-2 px-8 py-3.5 bg-rose-500 text-white font-semibold rounded-xl hover:bg-rose-600 transition disabled:opacity-50">
                <Send size={18} /> {sending ? 'Sending...' : 'Send Message'}
              </button>
            </form>
          </div>
        </div>

        {/* FAQ */}
        <section className="mt-20">
          <h2 className="text-2xl font-serif font-bold text-gray-900 mb-8 text-center">Frequently Asked Questions</h2>
          <div className="max-w-3xl mx-auto space-y-3">
            {faqs.map((faq, i) => (
              <div key={i} className="border border-gray-100 rounded-xl overflow-hidden">
                <button onClick={() => setExpandedFaq(expandedFaq === i ? null : i)}
                  className="w-full flex items-center justify-between p-5 text-left hover:bg-gray-50 transition">
                  <span className="font-semibold text-gray-900 pr-4">{faq.q}</span>
                  <span className="text-rose-400 flex-shrink-0">{expandedFaq === i ? '−' : '+'}</span>
                </button>
                {expandedFaq === i && (
                  <div className="px-5 pb-5 text-gray-500 leading-relaxed animate-in slide-in-from-top-1">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default ContactPage;
