import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/lib/formatPrice';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight, ArrowLeft, Truck, Shield, RotateCcw } from 'lucide-react';

const CartPage: React.FC = () => {
  const { cart, cartTotal, cartCount, updateQuantity, removeFromCart, clearCart } = useCart();
  const navigate = useNavigate();

  if (cart.length === 0) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
        <div className="w-20 h-20 bg-rose-100 rounded-full flex items-center justify-center mb-6">
          <ShoppingBag size={32} className="text-rose-400" />
        </div>
        <h1 className="text-2xl font-serif font-bold text-gray-900 mb-2">Your Cart is Empty</h1>
        <p className="text-gray-500 mb-6">Looks like you haven't added anything yet.</p>
        <Link to="/collections/bestsellers"
          className="inline-flex items-center gap-2 px-6 py-3 bg-rose-500 text-white rounded-xl font-semibold hover:bg-rose-600 transition">
          Start Shopping <ArrowRight size={16} />
        </Link>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-12">
        <div className="flex items-center justify-between mb-8">
          <h1 className="text-3xl font-serif font-bold text-gray-900">Shopping Cart ({cartCount})</h1>
          <button onClick={clearCart} className="text-sm text-gray-400 hover:text-rose-500 transition">Clear Cart</button>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2 space-y-4">
            {cart.map(item => (
              <div key={item.product_id + item.variant_id} className="bg-white rounded-2xl p-4 sm:p-6 shadow-sm border border-gray-100 flex gap-4">
                {item.image && (
                  <img src={item.image} alt={item.name} className="w-20 h-20 sm:w-24 sm:h-24 rounded-xl object-cover flex-shrink-0" />
                )}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h3 className="font-semibold text-gray-900">{item.name}</h3>
                      {item.variant_title && <p className="text-sm text-gray-500 mt-0.5">{item.variant_title}</p>}
                    </div>
                    <button onClick={() => removeFromCart(item.product_id, item.variant_id)}
                      className="text-gray-300 hover:text-rose-500 transition flex-shrink-0">
                      <Trash2 size={18} />
                    </button>
                  </div>
                  <div className="flex items-end justify-between mt-4">
                    <div className="flex items-center border border-gray-200 rounded-lg overflow-hidden">
                      <button onClick={() => updateQuantity(item.product_id, item.variant_id, item.quantity - 1)}
                        className="px-3 py-2 hover:bg-gray-50 transition"><Minus size={14} /></button>
                      <span className="px-4 py-2 font-medium text-sm min-w-[2.5rem] text-center">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.product_id, item.variant_id, item.quantity + 1)}
                        className="px-3 py-2 hover:bg-gray-50 transition"><Plus size={14} /></button>
                    </div>
                    <p className="font-bold text-gray-900">{formatPrice(item.price * item.quantity)}</p>
                  </div>
                </div>
              </div>
            ))}
            <Link to="/collections/bestsellers" className="inline-flex items-center gap-2 text-sm text-gray-500 hover:text-rose-500 transition mt-4">
              <ArrowLeft size={16} /> Continue Shopping
            </Link>
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl p-6 shadow-sm border border-gray-100 sticky top-24">
              <h2 className="text-lg font-bold text-gray-900 mb-4">Order Summary</h2>
              <div className="space-y-3 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Subtotal ({cartCount} items)</span>
                  <span className="font-medium text-gray-900">{formatPrice(cartTotal)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Shipping</span>
                  <span className="font-medium text-green-600">Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Tax</span>
                  <span className="text-gray-400">Calculated at checkout</span>
                </div>
                <div className="border-t border-gray-100 pt-3 flex justify-between">
                  <span className="font-bold text-gray-900">Estimated Total</span>
                  <span className="font-bold text-gray-900 text-lg">{formatPrice(cartTotal)}</span>
                </div>
              </div>

              <button onClick={() => navigate('/checkout')}
                className="w-full mt-6 py-4 bg-rose-500 text-white font-semibold rounded-xl hover:bg-rose-600 transition shadow-lg shadow-rose-500/20 flex items-center justify-center gap-2">
                Proceed to Checkout <ArrowRight size={16} />
              </button>

              <div className="grid grid-cols-3 gap-2 mt-6">
                {[
                  { icon: Truck, text: 'Free Shipping' },
                  { icon: RotateCcw, text: '30-Day Returns' },
                  { icon: Shield, text: 'Secure Pay' },
                ].map(({ icon: Icon, text }) => (
                  <div key={text} className="flex flex-col items-center gap-1 p-2 text-center">
                    <Icon size={16} className="text-rose-400" />
                    <span className="text-xs text-gray-500">{text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CartPage;
