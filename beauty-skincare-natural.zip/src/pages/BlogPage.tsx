import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Clock, ArrowRight, Tag } from 'lucide-react';

const POPPY_OIL_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601982143_48f52fc6.png';
const LIFESTYLE_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601948858_085f0240.png';
const SHEA_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775602029812_3a54d901.png';
const CALENDULA_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775602047701_f0a45298.jpg';
const HERO_IMG = 'https://d64gsuwffb70l.cloudfront.net/69d587bdfb62fd755fc632cd_1775601711651_4319719d.jpg';

const posts = [
  { id: 1, title: 'How to Layer Body Oils for Maximum Glow', excerpt: 'Learn the art of layering body oils with lotions for all-day hydration and radiance. We break down the perfect routine for every skin type.', date: 'Mar 28, 2026', readTime: '5 min', category: 'Skincare Tips', image: POPPY_OIL_IMG, content: 'Body oils are the secret weapon in any skincare routine. The key is to apply them to slightly damp skin right after showering. Start with your lightest oil, then layer your lotion on top to lock in moisture. Our Golden Poppy Body Oil is perfect as a base layer — it absorbs quickly and creates a beautiful canvas for your moisturizer.\n\nFor extra glow, try mixing a few drops of body oil into your lotion before applying. This creates a custom blend that delivers both hydration and radiance. Finish with a light mist of our Coconut & Vanilla Dry Oil Spray for a subtle, all-day sheen.' },
  { id: 2, title: 'Benefits of Poppy Seed Oil for Your Skin', excerpt: 'Discover why poppy seed oil is our hero ingredient and how it transforms your skin from the inside out.', date: 'Mar 15, 2026', readTime: '4 min', category: 'Ingredients', image: LIFESTYLE_IMG, content: 'Poppy seed oil is rich in linoleic acid, an essential fatty acid that helps maintain the skin\'s natural barrier. Unlike heavier oils, it absorbs quickly without leaving a greasy residue.\n\nKey benefits include: deep hydration without clogging pores, natural radiance from essential fatty acids, soothing properties for irritated skin, and antioxidant protection from vitamin E. At LushPoppy, we source our poppy seed oil from sustainable farms to ensure the highest quality.' },
  { id: 3, title: 'Gift Ideas Under KSH 5,000', excerpt: 'Thoughtful, luxurious gifts that won\'t break the bank. Perfect for birthdays, anniversaries, or just because.', date: 'Mar 5, 2026', readTime: '3 min', category: 'Gift Guide', image: SHEA_IMG, content: 'Finding the perfect gift doesn\'t have to be stressful or expensive. Our curated selection of gift-worthy products under KSH 5,000 includes our Mini Discovery Set, individual soaps beautifully wrapped, and our bestselling body oils.\n\nFor a personal touch, pair any product with a handwritten note. We also offer gift wrapping on all orders — just select the option at checkout.' },
  { id: 4, title: 'Building Your Perfect Evening Skincare Ritual', excerpt: 'Wind down with a self-care routine that nourishes your skin while you sleep. Here\'s our step-by-step guide.', date: 'Feb 20, 2026', readTime: '6 min', category: 'Skincare Tips', image: CALENDULA_IMG, content: 'Your evening routine is when your skin does its most important repair work. Start with a gentle cleanse using our Lavender & Oat Calming Bar to remove the day\'s impurities.\n\nFollow with our Jasmine Night Repair Oil — the jasmine and rosehip blend works overnight to deeply nourish and restore. Finish with our Rose & Poppy Nourishing Cream for intense moisture that lasts until morning.' },
  { id: 5, title: 'The Story Behind Our Sustainable Packaging', excerpt: 'How we\'re reducing waste without compromising on the luxury experience you deserve.', date: 'Feb 10, 2026', readTime: '4 min', category: 'Sustainability', image: HERO_IMG, content: 'Sustainability isn\'t just a buzzword at LushPoppy — it\'s a core value. Our bottles are made from recycled glass, our labels use soy-based inks, and our shipping materials are 100% recyclable.\n\nWe\'re also working on a refill programme that will launch later this year, allowing you to return your empty bottles for a discount on your next purchase. Beautiful skin shouldn\'t cost the earth.' },
  { id: 6, title: 'Understanding Your Skin Type: A Complete Guide', excerpt: 'Not sure if you have oily, dry, combination, or sensitive skin? This guide will help you find out.', date: 'Jan 28, 2026', readTime: '7 min', category: 'Skincare Tips', image: POPPY_OIL_IMG, content: 'Knowing your skin type is the first step to building an effective skincare routine. Here\'s a simple test: wash your face with a gentle cleanser, pat dry, and wait 30 minutes without applying anything.\n\nIf your skin feels tight, you likely have dry skin. If it\'s shiny all over, you have oily skin. Shiny T-zone but dry cheeks? That\'s combination. If your skin reacts easily to new products, you have sensitive skin. Once you know your type, we can recommend the perfect LushPoppy products for you.' },
];

const categories = ['All', ...new Set(posts.map(p => p.category))];

const BlogPage: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [expandedPost, setExpandedPost] = useState<number | null>(null);

  const filtered = selectedCategory === 'All' ? posts : posts.filter(p => p.category === selectedCategory);

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-gradient-to-r from-rose-50 to-amber-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-rose-500 font-medium text-sm uppercase tracking-wider">The Journal</span>
          <h1 className="text-4xl lg:text-5xl font-serif font-bold text-gray-900 mt-3">LushPoppy Blog</h1>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto text-lg">
            Skincare tips, ingredient deep-dives, and stories from our botanical world.
          </p>
        </div>
      </section>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Category Filter */}
        <div className="flex flex-wrap gap-2 mb-10">
          {categories.map(cat => (
            <button key={cat} onClick={() => setSelectedCategory(cat)}
              className={`px-4 py-2 rounded-full text-sm font-medium transition ${
                selectedCategory === cat ? 'bg-rose-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}>
              {cat}
            </button>
          ))}
        </div>

        {/* Featured Post */}
        {filtered.length > 0 && !expandedPost && (
          <div className="mb-12">
            <div className="grid lg:grid-cols-2 gap-8 bg-white rounded-2xl overflow-hidden border border-gray-100 shadow-sm hover:shadow-lg transition cursor-pointer"
              onClick={() => setExpandedPost(filtered[0].id)}>
              <div className="aspect-[16/10] lg:aspect-auto overflow-hidden">
                <img src={filtered[0].image} alt={filtered[0].title} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
              </div>
              <div className="p-6 lg:p-8 flex flex-col justify-center">
                <div className="flex items-center gap-3 text-sm text-gray-400 mb-3">
                  <span className="px-2.5 py-0.5 bg-rose-100 text-rose-600 rounded-full text-xs font-medium">{filtered[0].category}</span>
                  <span>{filtered[0].date}</span>
                  <span className="flex items-center gap-1"><Clock size={12} /> {filtered[0].readTime}</span>
                </div>
                <h2 className="text-2xl lg:text-3xl font-serif font-bold text-gray-900 hover:text-rose-500 transition">{filtered[0].title}</h2>
                <p className="text-gray-500 mt-3 leading-relaxed">{filtered[0].excerpt}</p>
                <span className="inline-flex items-center gap-1 mt-4 text-rose-500 font-medium">
                  Read More <ArrowRight size={14} />
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Expanded Post */}
        {expandedPost && (
          <div className="mb-12">
            {(() => {
              const post = posts.find(p => p.id === expandedPost);
              if (!post) return null;
              return (
                <article className="max-w-3xl mx-auto">
                  <button onClick={() => setExpandedPost(null)} className="text-sm text-gray-400 hover:text-rose-500 transition mb-6">
                    &larr; Back to all posts
                  </button>
                  <div className="flex items-center gap-3 text-sm text-gray-400 mb-4">
                    <span className="px-2.5 py-0.5 bg-rose-100 text-rose-600 rounded-full text-xs font-medium">{post.category}</span>
                    <span>{post.date}</span>
                    <span className="flex items-center gap-1"><Clock size={12} /> {post.readTime}</span>
                  </div>
                  <h1 className="text-3xl lg:text-4xl font-serif font-bold text-gray-900 mb-6">{post.title}</h1>
                  <img src={post.image} alt={post.title} className="w-full aspect-[16/9] object-cover rounded-2xl mb-8" />
                  <div className="prose prose-lg max-w-none text-gray-600 leading-relaxed">
                    {post.content.split('\n\n').map((p, i) => <p key={i} className="mb-4">{p}</p>)}
                  </div>
                  <div className="mt-8 p-6 bg-rose-50 rounded-2xl text-center">
                    <p className="font-semibold text-gray-900">Ready to try these tips?</p>
                    <Link to="/collections/bestsellers" className="inline-flex items-center gap-2 mt-3 text-rose-500 font-medium hover:text-rose-600">
                      Shop Our Products <ArrowRight size={14} />
                    </Link>
                  </div>
                </article>
              );
            })()}
          </div>
        )}

        {/* Post Grid */}
        {!expandedPost && (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.slice(1).map(post => (
              <div key={post.id} onClick={() => setExpandedPost(post.id)}
                className="group rounded-2xl overflow-hidden bg-white border border-gray-100 shadow-sm hover:shadow-lg transition cursor-pointer">
                <div className="aspect-[16/10] overflow-hidden">
                  <img src={post.image} alt={post.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 text-xs text-gray-400 mb-2">
                    <span className="px-2 py-0.5 bg-rose-100 text-rose-600 rounded-full font-medium">{post.category}</span>
                    <span>{post.date}</span>
                  </div>
                  <h3 className="text-lg font-bold text-gray-900 group-hover:text-rose-500 transition line-clamp-2">{post.title}</h3>
                  <p className="text-gray-500 text-sm mt-2 line-clamp-2">{post.excerpt}</p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default BlogPage;
