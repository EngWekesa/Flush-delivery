import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Search, Shield, Leaf, ArrowRight } from 'lucide-react';

const ingredients = [
  { name: 'Aloe Vera', benefit: 'Soothes, hydrates, and calms irritated skin', why: 'A gentle moisturizer that helps heal and protect without clogging pores.', tested: true },
  { name: 'Argan Oil', benefit: 'Rich in vitamin E and fatty acids for deep nourishment', why: 'Absorbs quickly, leaving skin soft and radiant without greasiness.', tested: true },
  { name: 'Bergamot Essential Oil', benefit: 'Uplifting citrus scent with antibacterial properties', why: 'Natural fragrance that also helps balance oily skin.', tested: false },
  { name: 'Calendula Extract', benefit: 'Anti-inflammatory, promotes healing and soothes sensitive skin', why: 'One of nature\'s gentlest healers, perfect for reactive and delicate skin.', tested: true },
  { name: 'Coconut Oil', benefit: 'Deep moisturizing with antimicrobial properties', why: 'Creates a protective barrier while delivering intense hydration.', tested: true },
  { name: 'Colloidal Oatmeal', benefit: 'Relieves itching and irritation, locks in moisture', why: 'Clinically proven to soothe eczema-prone and sensitive skin.', tested: true },
  { name: 'Grapeseed Oil', benefit: 'Lightweight oil rich in antioxidants', why: 'Non-comedogenic and fast-absorbing, ideal for oily skin types.', tested: false },
  { name: 'Green Tea Extract', benefit: 'Powerful antioxidant that protects against environmental damage', why: 'Fights free radicals while soothing inflammation.', tested: true },
  { name: 'Honey (Raw)', benefit: 'Natural humectant with antibacterial properties', why: 'Draws moisture to the skin while gently cleansing.', tested: false },
  { name: 'Jasmine Extract', benefit: 'Aromatic with skin-conditioning properties', why: 'Promotes elasticity and helps even skin tone naturally.', tested: false },
  { name: 'Jojoba Oil', benefit: 'Mimics skin\'s natural sebum for balanced hydration', why: 'Regulates oil production while providing deep moisture.', tested: true },
  { name: 'Lavender Essential Oil', benefit: 'Calming, antiseptic, promotes relaxation', why: 'Soothes both skin and mind — perfect for evening routines.', tested: true },
  { name: 'Olive Oil', benefit: 'Rich in vitamins A, D, E, and K', why: 'Time-tested moisturizer that nourishes deeply.', tested: false },
  { name: 'Peppermint Oil', benefit: 'Cooling, invigorating, improves circulation', why: 'Energizes tired skin and provides a refreshing sensation.', tested: false },
  { name: 'Poppy Seed Oil', benefit: 'Rich in linoleic acid for deep hydration and radiance', why: 'Our hero ingredient — lightweight, fast-absorbing, and packed with essential fatty acids.', tested: true },
  { name: 'Rose Hip Oil', benefit: 'High in vitamin C and retinoids for skin renewal', why: 'Promotes cell turnover and helps fade scars and dark spots.', tested: true },
  { name: 'Shea Butter', benefit: 'Intense moisture with vitamins A, E, and F', why: 'Creates a protective moisture barrier that lasts all day.', tested: true },
  { name: 'Sweet Almond Oil', benefit: 'Gentle, nourishing oil suitable for all skin types', why: 'Softens and smooths while delivering essential nutrients.', tested: true },
  { name: 'Tea Tree Oil', benefit: 'Natural antiseptic and anti-inflammatory', why: 'Fights blemishes and purifies without harsh chemicals.', tested: true },
  { name: 'Tocopherol (Vitamin E)', benefit: 'Antioxidant that protects and repairs skin', why: 'Shields skin from environmental stress while promoting healing.', tested: true },
  { name: 'Turmeric', benefit: 'Brightening, anti-inflammatory, evens skin tone', why: 'Ancient remedy that brings natural radiance to all skin tones.', tested: false },
  { name: 'Vanilla Extract', benefit: 'Antioxidant-rich with a warm, comforting scent', why: 'Protects skin while providing a luxurious sensory experience.', tested: false },
];

const IngredientsPage: React.FC = () => {
  const [search, setSearch] = useState('');

  const filtered = ingredients.filter(i =>
    i.name.toLowerCase().includes(search.toLowerCase()) ||
    i.benefit.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-white">
      {/* Hero */}
      <section className="bg-gradient-to-r from-rose-50 to-amber-50 py-16 sm:py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <span className="text-rose-500 font-medium text-sm uppercase tracking-wider">Transparency</span>
          <h1 className="text-4xl lg:text-5xl font-serif font-bold text-gray-900 mt-3">Our Ingredients</h1>
          <p className="text-gray-600 mt-4 max-w-2xl mx-auto text-lg">
            We believe you should know exactly what goes on your skin. Every ingredient is chosen for a reason — here's why.
          </p>
          {/* Search */}
          <div className="max-w-md mx-auto mt-8 relative">
            <Search size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400" />
            <input type="text" value={search} onChange={e => setSearch(e.target.value)}
              placeholder="Search ingredients..." 
              className="w-full pl-11 pr-4 py-3.5 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none bg-white" />
          </div>
        </div>
      </section>

      {/* Ingredient List */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <p className="text-sm text-gray-400 mb-6">{filtered.length} ingredient{filtered.length !== 1 ? 's' : ''} found</p>
        <div className="grid gap-4">
          {filtered.map(ing => (
            <div key={ing.name} className="bg-white rounded-xl p-5 sm:p-6 border border-gray-100 hover:border-rose-200 hover:shadow-sm transition">
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3">
                <div className="flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <h3 className="text-lg font-bold text-gray-900">{ing.name}</h3>
                    {ing.tested && (
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                        <Shield size={10} /> Clinically Tested
                      </span>
                    )}
                  </div>
                  <p className="text-gray-600 mt-1">{ing.benefit}</p>
                  <p className="text-sm text-gray-400 mt-2 flex items-start gap-1">
                    <Leaf size={14} className="text-rose-400 flex-shrink-0 mt-0.5" />
                    <span><strong>Why we use it:</strong> {ing.why}</span>
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl font-serif font-bold text-gray-900 mb-8 text-center">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {[
              { q: 'Are your products suitable for people with allergies?', a: 'We list all ingredients clearly on every product. If you have specific allergies, please review the full ingredient list or contact us before purchasing. We offer fragrance-free options for sensitive skin.' },
              { q: 'Do you use any synthetic preservatives?', a: 'We use minimal, gentle preservatives like phenoxyethanol to ensure product safety and shelf life. All our preservatives are approved for use in natural cosmetics.' },
              { q: 'Are your products truly natural?', a: 'We use predominantly natural and plant-derived ingredients. Some products contain minimal safe synthetics for stability and preservation. We\'re always transparent about what\'s inside.' },
              { q: 'Are your products vegan?', a: 'Most of our products are vegan. Products containing honey or beeswax are clearly labelled. Check individual product pages for vegan status.' },
            ].map(({ q, a }) => (
              <div key={q} className="bg-white rounded-xl p-5 border border-gray-100">
                <h3 className="font-semibold text-gray-900">{q}</h3>
                <p className="text-gray-500 mt-2 text-sm leading-relaxed">{a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-7xl mx-auto px-4 py-16 text-center">
        <h2 className="text-2xl font-serif font-bold text-gray-900">Shop by Ingredient</h2>
        <p className="text-gray-500 mt-2">Find products featuring your favourite botanicals</p>
        <Link to="/collections/bestsellers"
          className="inline-flex items-center gap-2 mt-6 px-6 py-3 bg-rose-500 text-white rounded-xl font-semibold hover:bg-rose-600 transition">
          Browse Products <ArrowRight size={16} />
        </Link>
      </section>
    </div>
  );
};

export default IngredientsPage;
