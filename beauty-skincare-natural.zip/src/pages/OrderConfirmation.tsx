import React from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { CheckCircle, ArrowRight, Package } from 'lucide-react';

const OrderConfirmation: React.FC = () => {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');

  return (
    <div className="min-h-[70vh] flex items-center justify-center px-4">
      <div className="max-w-lg w-full text-center">
        <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <CheckCircle size={40} className="text-green-500" />
        </div>
        <h1 className="text-3xl font-serif font-bold text-gray-900 mb-3">Thank You!</h1>
        <p className="text-gray-600 text-lg mb-2">Your order has been placed successfully.</p>
        {orderId && (
          <p className="text-sm text-gray-400 mb-6">Order ID: {orderId.slice(0, 8)}...</p>
        )}
        <div className="bg-rose-50 rounded-2xl p-6 mb-8">
          <div className="flex items-center justify-center gap-2 mb-3">
            <Package size={20} className="text-rose-500" />
            <h3 className="font-semibold text-gray-900">What's Next?</h3>
          </div>
          <ul className="text-sm text-gray-600 space-y-2 text-left max-w-xs mx-auto">
            <li className="flex items-start gap-2">
              <span className="text-rose-500 font-bold">1.</span>
              You'll receive an order confirmation email shortly
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 font-bold">2.</span>
              We'll prepare your handcrafted products with care
            </li>
            <li className="flex items-start gap-2">
              <span className="text-rose-500 font-bold">3.</span>
              You'll get a shipping notification with tracking info
            </li>
          </ul>
        </div>
        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link to="/collections/bestsellers"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 bg-rose-500 text-white rounded-xl font-semibold hover:bg-rose-600 transition">
            Continue Shopping <ArrowRight size={16} />
          </Link>
          <Link to="/"
            className="inline-flex items-center justify-center gap-2 px-6 py-3 border border-gray-200 text-gray-700 rounded-xl font-medium hover:bg-gray-50 transition">
            Back to Home
          </Link>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;
