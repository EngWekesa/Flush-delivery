import React, { useState, useEffect } from 'react';
import { useParams, Link, useSearchParams } from 'react-router-dom';
import { supabase } from '@/lib/supabase';
import ProductCard from '@/components/ProductCard';
import { SlidersHorizontal, ChevronDown, X } from 'lucide-react';

const CollectionPage: React.FC = () => {
  const { handle } = useParams<{ handle: string }>();
  const [searchParams] = useSearchParams();
  const searchQuery = searchParams.get('search') || '';
  const [collection, setCollection] = useState<any>(null);
  const [products, setProducts] = useState<any[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [sortBy, setSortBy] = useState('featured');
  const [showFilters, setShowFilters] = useState(false);
  const [selectedType, setSelectedType] = useState('');
  const [priceRange, setPriceRange] = useState('');

  useEffect(() => {
    const fetchCollectionProducts = async () => {
      if (!handle) return;
      setLoading(true);

      const { data: collectionData } = await supabase
        .from('ecom_collections')
        .select('*')
        .eq('handle', handle)
        .single();

      if (!collectionData) {
        // If no collection found, show all products
        const { data: allProducts } = await supabase
          .from('ecom_products')
          .select('*, variants:ecom_product_variants(*)')
          .eq('status', 'active');
        setProducts(allProducts || []);
        setCollection({ title: 'All Products', description: 'Browse our full range of botanical body care.' });
        setLoading(false);
        return;
      }
      setCollection(collectionData);

      const { data: productLinks } = await supabase
        .from('ecom_product_collections')
        .select('product_id, position')
        .eq('collection_id', collectionData.id)
        .order('position');

      if (!productLinks || productLinks.length === 0) {
        setProducts([]);
        setLoading(false);
        return;
      }

      const productIds = productLinks.map(pl => pl.product_id);
      const { data: productsData } = await supabase
        .from('ecom_products')
        .select('*, variants:ecom_product_variants(*)')
        .in('id', productIds)
        .eq('status', 'active');

      const sortedProducts = productIds
        .map(id => productsData?.find(p => p.id === id))
        .filter(Boolean);

      setProducts(sortedProducts as any[]);
      setLoading(false);
    };

    fetchCollectionProducts();
  }, [handle]);

  useEffect(() => {
    let result = [...products];

    // Search filter
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.description?.toLowerCase().includes(q) ||
        p.product_type?.toLowerCase().includes(q) ||
        p.tags?.some((t: string) => t.toLowerCase().includes(q))
      );
    }

    // Type filter
    if (selectedType) {
      result = result.filter(p => p.product_type === selectedType);
    }

    // Price filter
    if (priceRange) {
      const getEffectivePrice = (p: any) => {
        if (p.has_variants && p.variants?.length > 0) {
          return Math.min(...p.variants.map((v: any) => v.price));
        }
        return p.price;
      };
      switch (priceRange) {
        case 'under-1000':
          result = result.filter(p => getEffectivePrice(p) < 100000);
          break;
        case '1000-3000':
          result = result.filter(p => { const pr = getEffectivePrice(p); return pr >= 100000 && pr <= 300000; });
          break;
        case '3000-5000':
          result = result.filter(p => { const pr = getEffectivePrice(p); return pr >= 300000 && pr <= 500000; });
          break;
        case 'over-5000':
          result = result.filter(p => getEffectivePrice(p) > 500000);
          break;
      }
    }

    // Sort
    const getPrice = (p: any) => p.has_variants && p.variants?.length > 0 ? Math.min(...p.variants.map((v: any) => v.price)) : p.price;
    switch (sortBy) {
      case 'price-asc':
        result.sort((a, b) => getPrice(a) - getPrice(b));
        break;
      case 'price-desc':
        result.sort((a, b) => getPrice(b) - getPrice(a));
        break;
      case 'name-asc':
        result.sort((a, b) => a.name.localeCompare(b.name));
        break;
      case 'newest':
        result.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
        break;
    }

    setFilteredProducts(result);
  }, [products, sortBy, selectedType, priceRange, searchQuery]);

  const productTypes = [...new Set(products.map(p => p.product_type).filter(Boolean))];

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/3" />
          <div className="h-4 bg-gray-200 rounded w-1/2" />
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
            {[...Array(4)].map((_, i) => <div key={i} className="bg-gray-100 rounded-2xl aspect-[4/5]" />)}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      {/* Collection Header */}
      <div className="bg-gradient-to-r from-rose-50 to-amber-50 py-12 sm:py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <nav className="flex items-center gap-2 text-sm text-gray-400 mb-4">
            <Link to="/" className="hover:text-rose-500 transition">Home</Link>
            <span>/</span>
            <span className="text-gray-700">{collection?.title}</span>
          </nav>
          <h1 className="text-3xl sm:text-4xl font-serif font-bold text-gray-900">{collection?.title}</h1>
          <p className="text-gray-600 mt-2 max-w-2xl">{collection?.description}</p>
          <p className="text-sm text-gray-400 mt-2">{filteredProducts.length} product{filteredProducts.length !== 1 ? 's' : ''}</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Toolbar */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8">
          <button onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 px-4 py-2.5 border border-gray-200 rounded-xl hover:border-rose-300 transition text-sm font-medium">
            <SlidersHorizontal size={16} /> Filters
            {(selectedType || priceRange) && <span className="w-2 h-2 bg-rose-500 rounded-full" />}
          </button>
          <div className="flex items-center gap-2">
            <span className="text-sm text-gray-500">Sort by:</span>
            <select value={sortBy} onChange={e => setSortBy(e.target.value)}
              className="px-3 py-2 border border-gray-200 rounded-xl text-sm focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none">
              <option value="featured">Featured</option>
              <option value="newest">Newest</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="name-asc">Name: A-Z</option>
            </select>
          </div>
        </div>

        {/* Filters Panel */}
        {showFilters && (
          <div className="bg-gray-50 rounded-2xl p-6 mb-8 animate-in slide-in-from-top-2">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-gray-900">Filters</h3>
              <button onClick={() => { setSelectedType(''); setPriceRange(''); }} className="text-sm text-rose-500 hover:text-rose-600">
                Clear All
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {productTypes.length > 0 && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                  <select value={selectedType} onChange={e => setSelectedType(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm">
                    <option value="">All Categories</option>
                    {productTypes.map(t => <option key={t} value={t}>{t}</option>)}
                  </select>
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                <select value={priceRange} onChange={e => setPriceRange(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-200 rounded-xl text-sm">
                  <option value="">All Prices</option>
                  <option value="under-1000">Under KSH 1,000</option>
                  <option value="1000-3000">KSH 1,000 - 3,000</option>
                  <option value="3000-5000">KSH 3,000 - 5,000</option>
                  <option value="over-5000">Over KSH 5,000</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Active filters */}
        {(selectedType || priceRange || searchQuery) && (
          <div className="flex flex-wrap gap-2 mb-6">
            {searchQuery && (
              <span className="inline-flex items-center gap-1 px-3 py-1.5 bg-rose-50 text-rose-600 rounded-full text-sm">
                Search: "{searchQuery}"
              </span>
            )}
            {selectedType && (
              <button onClick={() => setSelectedType('')}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-rose-50 text-rose-600 rounded-full text-sm hover:bg-rose-100 transition">
                {selectedType} <X size={14} />
              </button>
            )}
            {priceRange && (
              <button onClick={() => setPriceRange('')}
                className="inline-flex items-center gap-1 px-3 py-1.5 bg-rose-50 text-rose-600 rounded-full text-sm hover:bg-rose-100 transition">
                {priceRange.replace(/-/g, ' ')} <X size={14} />
              </button>
            )}
          </div>
        )}

        {/* Product Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <p className="text-gray-500 text-lg">No products found matching your criteria.</p>
            <button onClick={() => { setSelectedType(''); setPriceRange(''); }}
              className="mt-4 text-rose-500 font-medium hover:text-rose-600 transition">
              Clear filters
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
            {filteredProducts.map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CollectionPage;
