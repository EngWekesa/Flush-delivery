import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://sjjdgxljtdyefdlnwafh.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjIzMWY1NTg0LTI5NDItNDY4Yi05MzQ4LTc0YzBmZDY2Yjg3YyJ9.eyJwcm9qZWN0SWQiOiJzampkZ3hsanRkeWVmZGxud2FmaCIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzc1NjAxNjE2LCJleHAiOjIwOTA5NjE2MTYsImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0._CN8LibXQWyh0tWYaa_98tkeO6mHXU9OyxVSz9wLKoc';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };