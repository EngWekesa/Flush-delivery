export const formatPrice = (cents: number): string => {
  const amount = cents / 100;
  return `KSH ${amount.toLocaleString('en-KE', { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`;
};
