import React from 'react';
import { Link } from 'react-router-dom';
import { ShoppingBag, Star, Eye } from 'lucide-react';
import { useCart } from '@/contexts/CartContext';
import { formatPrice } from '@/lib/formatPrice';

interface ProductCardProps {
  product: any;
  compact?: boolean;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, compact }) => {
  const { addToCart } = useCart();

  const getPrice = () => {
    if (product.has_variants && product.variants?.length > 0) {
      const sorted = [...product.variants].sort((a: any, b: any) => (a.price || 0) - (b.price || 0));
      return sorted[0].price;
    }
    return product.price;
  };

  const price = getPrice();
  const rating = 4 + Math.random() * 1;
  const reviewCount = Math.floor(20 + Math.random() * 80);

  const handleQuickAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const variant = product.variants?.[0];
    addToCart({
      product_id: product.id,
      variant_id: variant?.id || undefined,
      name: product.name,
      variant_title: variant?.title || undefined,
      sku: variant?.sku || product.sku || product.handle,
      price: variant?.price || product.price,
      image: product.images?.[0],
    });
  };

  return (
    <div className="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 border border-gray-100">
      <Link to={`/product/${product.handle}`}>
        <div className="relative aspect-[4/5] overflow-hidden bg-gray-50">
          <img
            src={product.images?.[0] || '/placeholder.svg'}
            alt={product.name}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
          {/* Tags */}
          <div className="absolute top-3 left-3 flex flex-col gap-1">
            {product.tags?.includes('bestseller') && (
              <span className="px-2.5 py-1 bg-rose-500 text-white text-xs font-semibold rounded-full">Bestseller</span>
            )}
            {product.tags?.includes('new-arrival') && (
              <span className="px-2.5 py-1 bg-amber-500 text-white text-xs font-semibold rounded-full">New</span>
            )}
          </div>
          {/* Quick actions overlay */}
          <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all duration-300 flex items-end justify-center pb-4 opacity-0 group-hover:opacity-100">
            <div className="flex gap-2">
              <button onClick={handleQuickAdd}
                className="flex items-center gap-2 px-4 py-2.5 bg-white text-gray-900 rounded-xl shadow-lg hover:bg-rose-500 hover:text-white transition font-medium text-sm">
                <ShoppingBag size={16} /> Add to Cart
              </button>
              <Link to={`/product/${product.handle}`}
                className="flex items-center gap-1 px-3 py-2.5 bg-white/90 text-gray-900 rounded-xl shadow-lg hover:bg-white transition text-sm">
                <Eye size={16} />
              </Link>
            </div>
          </div>
        </div>
      </Link>
      <div className="p-4">
        <p className="text-xs text-gray-400 uppercase tracking-wider mb-1">{product.product_type}</p>
        <Link to={`/product/${product.handle}`}>
          <h3 className="font-semibold text-gray-900 group-hover:text-rose-500 transition line-clamp-1">{product.name}</h3>
        </Link>
        {!compact && (
          <p className="text-sm text-gray-500 mt-1 line-clamp-1">{product.metadata?.scent || product.description?.slice(0, 60)}</p>
        )}
        <div className="flex items-center gap-1 mt-2">
          {[...Array(5)].map((_, i) => (
            <Star key={i} size={12} className={i < Math.floor(rating) ? 'fill-amber-400 text-amber-400' : 'text-gray-200'} />
          ))}
          <span className="text-xs text-gray-400 ml-1">({reviewCount})</span>
        </div>
        <div className="flex items-center justify-between mt-3">
          <p className="text-lg font-bold text-gray-900">
            {product.has_variants ? <span className="text-sm font-normal text-gray-500">from </span> : ''}
            {formatPrice(price)}
          </p>
          {product.tags?.includes('featured') && (
            <span className="text-xs text-rose-500 font-medium">Free Shipping</span>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
