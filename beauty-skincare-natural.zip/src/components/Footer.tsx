import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Facebook, Twitter, Mail, Phone, MapPin } from 'lucide-react';
import { toast } from 'sonner';

const PROJECT_ID = window.location.hostname.split('.')[0];

const Footer: React.FC = () => {
  const [email, setEmail] = useState('');
  const [subscribing, setSubscribing] = useState(false);

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;
    setSubscribing(true);
    try {
      await fetch(`https://famous.ai/api/crm/${PROJECT_ID}/subscribe`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, source: 'footer-signup', tags: ['newsletter', 'footer'] })
      });
      toast.success('Welcome to the Poppy Circle! Check your email for 15% off.');
      setEmail('');
    } catch {
      toast.success('Thanks for subscribing!');
      setEmail('');
    } finally {
      setSubscribing(false);
    }
  };

  return (
    <footer className="bg-gray-900 text-gray-300">
      {/* Newsletter Section */}
      <div className="bg-gradient-to-r from-rose-500 to-rose-400">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-2xl font-serif font-bold text-white">Join the Poppy Circle</h3>
              <p className="text-rose-100 mt-1">Get 15% off your first order, early access to new scents & weekly skincare tips.</p>
            </div>
            <form onSubmit={handleSubscribe} className="flex w-full md:w-auto gap-2">
              <input type="email" value={email} onChange={e => setEmail(e.target.value)} required
                placeholder="Enter your email" className="px-4 py-3 rounded-xl bg-white/20 text-white placeholder-rose-200 border border-white/30 focus:outline-none focus:ring-2 focus:ring-white/50 w-full md:w-72" />
              <button type="submit" disabled={subscribing}
                className="px-6 py-3 bg-white text-rose-500 font-semibold rounded-xl hover:bg-rose-50 transition whitespace-nowrap disabled:opacity-50">
                {subscribing ? '...' : 'Get 15% Off'}
              </button>
            </form>
          </div>
          <p className="text-rose-200 text-xs mt-3 text-center md:text-left">We never spam. Unsubscribe anytime.</p>
        </div>
      </div>

      {/* Main Footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-5 gap-8">
          {/* Brand */}
          <div className="col-span-2 md:col-span-4 lg:col-span-1">
            <Link to="/" className="text-2xl font-serif font-bold text-white">
              Lush<span className="text-rose-400">Poppy</span>
            </Link>
            <p className="mt-3 text-sm text-gray-400 leading-relaxed">
              Handcrafted body care inspired by fields of poppies and simple self-care rituals. Clean ingredients, conscious packaging.
            </p>
            <div className="flex gap-3 mt-4">
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-rose-500 transition">
                <Instagram size={16} />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-rose-500 transition">
                <Facebook size={16} />
              </a>
              <a href="#" className="w-9 h-9 rounded-full bg-gray-800 flex items-center justify-center hover:bg-rose-500 transition">
                <Twitter size={16} />
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Shop</h4>
            <ul className="space-y-2.5">
              <li><Link to="/collections/body-lotions" className="text-sm hover:text-rose-400 transition">Body Lotions</Link></li>
              <li><Link to="/collections/soaps-cleansers" className="text-sm hover:text-rose-400 transition">Soaps & Cleansers</Link></li>
              <li><Link to="/collections/body-oils" className="text-sm hover:text-rose-400 transition">Body Oils</Link></li>
              <li><Link to="/collections/gift-sets" className="text-sm hover:text-rose-400 transition">Gift Sets</Link></li>
              <li><Link to="/collections/bestsellers" className="text-sm hover:text-rose-400 transition">Bestsellers</Link></li>
              <li><Link to="/collections/new-arrivals" className="text-sm hover:text-rose-400 transition">New Arrivals</Link></li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Company</h4>
            <ul className="space-y-2.5">
              <li><Link to="/about" className="text-sm hover:text-rose-400 transition">About Us</Link></li>
              <li><Link to="/ingredients" className="text-sm hover:text-rose-400 transition">Ingredients</Link></li>
              <li><Link to="/blog" className="text-sm hover:text-rose-400 transition">Blog</Link></li>
              <li><Link to="/reviews" className="text-sm hover:text-rose-400 transition">Reviews</Link></li>
              <li><a href="#" className="text-sm hover:text-rose-400 transition">Careers</a></li>
              <li><a href="#" className="text-sm hover:text-rose-400 transition">Press</a></li>
              <li><a href="#" className="text-sm hover:text-rose-400 transition">Wholesale</a></li>
            </ul>
          </div>

          {/* Support */}
          <div>
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Support</h4>
            <ul className="space-y-2.5">
              <li><Link to="/contact" className="text-sm hover:text-rose-400 transition">Contact Us</Link></li>
              <li><a href="#" className="text-sm hover:text-rose-400 transition">Shipping & Returns</a></li>
              <li><a href="#" className="text-sm hover:text-rose-400 transition">Track Order</a></li>
              <li><a href="#" className="text-sm hover:text-rose-400 transition">FAQ</a></li>
              <li><a href="#" className="text-sm hover:text-rose-400 transition">Sample Policy</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div className="col-span-2 md:col-span-1">
            <h4 className="font-semibold text-white mb-4 text-sm uppercase tracking-wider">Contact</h4>
            <ul className="space-y-3">
              <li className="flex items-center gap-2 text-sm">
                <Phone size={14} className="text-rose-400 flex-shrink-0" />
                <a href="tel:0708770746" className="hover:text-rose-400 transition">0708 770 746</a>
              </li>
              <li className="flex items-center gap-2 text-sm">
                <Mail size={14} className="text-rose-400 flex-shrink-0" />
                <a href="mailto:hello@lushpoppy.com" className="hover:text-rose-400 transition">hello@lushpoppy.com</a>
              </li>
              <li className="flex items-start gap-2 text-sm">
                <MapPin size={14} className="text-rose-400 flex-shrink-0 mt-0.5" />
                <span>Nairobi, Kenya</span>
              </li>
            </ul>
            <a href="https://wa.me/254708770746" target="_blank" rel="noopener noreferrer"
              className="inline-flex items-center gap-2 mt-4 px-4 py-2 bg-green-600 text-white text-sm rounded-lg hover:bg-green-700 transition">
              <svg viewBox="0 0 24 24" className="w-4 h-4 fill-current"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
              WhatsApp Us
            </a>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-xs text-gray-500">&copy; {new Date().getFullYear()} LushPoppy. All rights reserved.</p>
            <div className="flex items-center gap-4 text-xs text-gray-500">
              <a href="#" className="hover:text-rose-400 transition">Terms of Service</a>
              <a href="#" className="hover:text-rose-400 transition">Privacy Policy</a>
              <a href="#" className="hover:text-rose-400 transition">Ingredient Policy</a>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500">Secure Payments</span>
              <div className="flex gap-1">
                {['Visa', 'MC', 'Mpesa'].map(p => (
                  <span key={p} className="px-2 py-1 bg-gray-800 rounded text-xs text-gray-400">{p}</span>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
