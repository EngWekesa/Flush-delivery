import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ShoppingBag, User, Menu, X, ChevronDown } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { useCart } from '@/contexts/CartContext';
import { supabase } from '@/lib/supabase';
import { formatPrice } from '@/lib/formatPrice';

const Header: React.FC = () => {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [shopDropdown, setShopDropdown] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [collections, setCollections] = useState<any[]>([]);
  const { user, setShowAuthModal, setAuthMode, signOut } = useAuth();
  const { cartCount, cart, cartTotal, showMiniCart, setShowMiniCart } = useCart();
  const navigate = useNavigate();
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    const fetchCollections = async () => {
      const { data } = await supabase
        .from('ecom_collections')
        .select('id, title, handle')
        .eq('is_visible', true);
      if (data) setCollections(data.filter(c => !['bestsellers', 'new-arrivals'].includes(c.handle)));
    };
    fetchCollections();
  }, []);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setShopDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/collections/bestsellers?search=${encodeURIComponent(searchQuery.trim())}`);
      setSearchOpen(false);
      setSearchQuery('');
    }
  };

  const shopCategories = collections.length > 0 ? collections : [
    { handle: 'body-lotions', title: 'Body Lotions' },
    { handle: 'soaps-cleansers', title: 'Soaps & Cleansers' },
    { handle: 'body-oils', title: 'Body Oils' },
    { handle: 'gift-sets', title: 'Gift Sets' },
  ];

  return (
    <>
      {/* Promo bar */}
      <div className="bg-rose-500 text-white text-center py-2 text-xs sm:text-sm font-medium tracking-wide">
        Free Shipping on All Orders | 30-Day Returns | Cruelty-Free
      </div>

      <header className={`sticky top-0 z-50 transition-all duration-300 ${scrolled ? 'bg-white/95 backdrop-blur-md shadow-md' : 'bg-white'}`}>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16 lg:h-20">
            {/* Mobile menu button */}
            <button onClick={() => setMobileMenuOpen(!mobileMenuOpen)} className="lg:hidden text-gray-700">
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>

            {/* Logo */}
            <Link to="/" className="flex items-center gap-2">
              <span className="text-2xl lg:text-3xl font-serif font-bold text-gray-900">
                Lush<span className="text-rose-500">Poppy</span>
              </span>
            </Link>

            {/* Desktop Nav */}
            <nav className="hidden lg:flex items-center gap-8">
              <div ref={dropdownRef} className="relative">
                <button onClick={() => setShopDropdown(!shopDropdown)}
                  className="flex items-center gap-1 text-gray-700 hover:text-rose-500 font-medium transition">
                  Shop <ChevronDown size={16} className={`transition-transform ${shopDropdown ? 'rotate-180' : ''}`} />
                </button>
                {shopDropdown && (
                  <div className="absolute top-full left-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-gray-100 py-2 animate-in fade-in slide-in-from-top-2">
                    {shopCategories.map(cat => (
                      <Link key={cat.handle} to={`/collections/${cat.handle}`}
                        onClick={() => setShopDropdown(false)}
                        className="block px-4 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 transition">
                        {cat.title}
                      </Link>
                    ))}
                    <div className="border-t border-gray-100 mt-1 pt-1">
                      <Link to="/collections/bestsellers" onClick={() => setShopDropdown(false)}
                        className="block px-4 py-2.5 text-rose-500 font-medium hover:bg-rose-50 transition">
                        View All Products
                      </Link>
                    </div>
                  </div>
                )}
              </div>
              <Link to="/about" className="text-gray-700 hover:text-rose-500 font-medium transition">About</Link>
              <Link to="/ingredients" className="text-gray-700 hover:text-rose-500 font-medium transition">Ingredients</Link>
              <Link to="/reviews" className="text-gray-700 hover:text-rose-500 font-medium transition">Reviews</Link>
              <Link to="/blog" className="text-gray-700 hover:text-rose-500 font-medium transition">Blog</Link>
              <Link to="/contact" className="text-gray-700 hover:text-rose-500 font-medium transition">Contact</Link>
            </nav>

            {/* Right icons */}
            <div className="flex items-center gap-3 sm:gap-4">
              <button onClick={() => setSearchOpen(!searchOpen)} className="text-gray-700 hover:text-rose-500 transition">
                <Search size={20} />
              </button>
              {user ? (
                <div className="relative group">
                  <button className="text-gray-700 hover:text-rose-500 transition">
                    <User size={20} />
                  </button>
                  <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 py-2 opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all">
                    <p className="px-4 py-2 text-sm text-gray-500 border-b border-gray-100">{user.email}</p>
                    <button onClick={signOut} className="w-full text-left px-4 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 transition text-sm">
                      Sign Out
                    </button>
                  </div>
                </div>
              ) : (
                <button onClick={() => { setAuthMode('login'); setShowAuthModal(true); }} className="text-gray-700 hover:text-rose-500 transition">
                  <User size={20} />
                </button>
              )}
              <button onClick={() => navigate('/cart')} className="relative text-gray-700 hover:text-rose-500 transition">
                <ShoppingBag size={20} />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-rose-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center font-bold">
                    {cartCount}
                  </span>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Search bar */}
        {searchOpen && (
          <div className="border-t border-gray-100 bg-white py-4 px-4 sm:px-6 lg:px-8 animate-in slide-in-from-top-2">
            <form onSubmit={handleSearch} className="max-w-2xl mx-auto flex gap-2">
              <input type="text" value={searchQuery} onChange={e => setSearchQuery(e.target.value)}
                placeholder="Search products..." autoFocus
                className="flex-1 px-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-300 focus:border-rose-300 outline-none" />
              <button type="submit" className="px-6 py-3 bg-rose-500 text-white rounded-xl hover:bg-rose-600 transition font-medium">
                Search
              </button>
            </form>
          </div>
        )}

        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-100 bg-white py-4 animate-in slide-in-from-top-2">
            <nav className="flex flex-col px-4 space-y-1">
              <p className="text-xs text-gray-400 uppercase tracking-wider px-3 py-2">Shop</p>
              {shopCategories.map(cat => (
                <Link key={cat.handle} to={`/collections/${cat.handle}`}
                  onClick={() => setMobileMenuOpen(false)}
                  className="px-3 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 rounded-lg transition">
                  {cat.title}
                </Link>
              ))}
              <div className="border-t border-gray-100 my-2" />
              <Link to="/about" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 rounded-lg transition">About</Link>
              <Link to="/ingredients" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 rounded-lg transition">Ingredients</Link>
              <Link to="/reviews" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 rounded-lg transition">Reviews</Link>
              <Link to="/blog" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 rounded-lg transition">Blog</Link>
              <Link to="/contact" onClick={() => setMobileMenuOpen(false)} className="px-3 py-2.5 text-gray-700 hover:bg-rose-50 hover:text-rose-500 rounded-lg transition">Contact</Link>
              {!user && (
                <>
                  <div className="border-t border-gray-100 my-2" />
                  <button onClick={() => { setMobileMenuOpen(false); setAuthMode('login'); setShowAuthModal(true); }}
                    className="px-3 py-2.5 text-rose-500 font-medium hover:bg-rose-50 rounded-lg transition text-left">
                    Sign In / Sign Up
                  </button>
                </>
              )}
            </nav>
          </div>
        )}

        {/* Mini Cart */}
        {showMiniCart && cart.length > 0 && (
          <div className="absolute right-4 top-full mt-2 w-80 bg-white rounded-xl shadow-2xl border border-gray-100 p-4 z-50 animate-in slide-in-from-top-2">
            <div className="flex justify-between items-center mb-3">
              <h3 className="font-semibold text-gray-900">Cart ({cartCount})</h3>
              <button onClick={() => setShowMiniCart(false)} className="text-gray-400 hover:text-gray-600"><X size={16} /></button>
            </div>
            <div className="space-y-3 max-h-60 overflow-y-auto">
              {cart.slice(-3).map(item => (
                <div key={item.product_id + item.variant_id} className="flex gap-3">
                  {item.image && <img src={item.image} alt={item.name} className="w-12 h-12 rounded-lg object-cover" />}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{item.name}</p>
                    {item.variant_title && <p className="text-xs text-gray-500">{item.variant_title}</p>}
                    <p className="text-sm text-rose-500 font-medium">{formatPrice(item.price)} x {item.quantity}</p>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 mt-3 pt-3">
              <div className="flex justify-between mb-3">
                <span className="font-medium text-gray-700">Total</span>
                <span className="font-bold text-gray-900">{formatPrice(cartTotal)}</span>
              </div>
              <button onClick={() => { navigate('/cart'); setShowMiniCart(false); }}
                className="w-full py-2.5 bg-rose-500 text-white rounded-xl hover:bg-rose-600 transition font-medium text-sm">
                View Cart
              </button>
            </div>
          </div>
        )}
      </header>
    </>
  );
};

export default Header;
