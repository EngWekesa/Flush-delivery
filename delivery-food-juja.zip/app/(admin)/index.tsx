import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, RefreshControl, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../lib/store';
import { supabase } from '../lib/supabase';

export default function AdminDashboard() {
  const { user, setUser } = useStore();
  const router = useRouter();
  const [stats, setStats] = useState({ riders: 0, pendingRiders: 0, customers: 0, orders: 0 });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = async () => {
    try {
      const [ridersRes, pendingRes, customersRes, ordersRes] = await Promise.all([
        supabase.functions.invoke('admin', { body: { action: 'get_all_riders' } }),
        supabase.functions.invoke('admin', { body: { action: 'get_pending_riders' } }),
        supabase.functions.invoke('admin', { body: { action: 'get_all_customers' } }),
        supabase.functions.invoke('orders', { body: { action: 'get_all_orders' } }),
      ]);
      setStats({
        riders: ridersRes.data?.riders?.length || 0,
        pendingRiders: pendingRes.data?.riders?.length || 0,
        customers: customersRes.data?.customers?.length || 0,
        orders: ordersRes.data?.orders?.length || 0,
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchStats(); }, []);

  const handleLogout = () => {
    setUser(null);
    router.replace('/');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Admin Panel</Text>
          <Text style={styles.userName}>{user?.name || 'Admin'}</Text>
        </View>
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchStats(); }} tintColor="#2ECC71" />}
        contentContainerStyle={{ padding: 16 }}
      >
        {loading ? (
          <ActivityIndicator size="large" color="#2ECC71" style={{ marginTop: 40 }} />
        ) : (
          <>
            <View style={styles.statsGrid}>
              <TouchableOpacity style={[styles.statCard, { backgroundColor: '#e8f5e9' }]} onPress={() => router.push('/(admin)/riders')}>
                <Ionicons name="bicycle" size={28} color="#2ECC71" />
                <Text style={styles.statValue}>{stats.riders}</Text>
                <Text style={styles.statLabel}>Total Riders</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.statCard, { backgroundColor: '#fff3e0' }]} onPress={() => router.push('/(admin)/riders')}>
                <Ionicons name="hourglass" size={28} color="#f39c12" />
                <Text style={styles.statValue}>{stats.pendingRiders}</Text>
                <Text style={styles.statLabel}>Pending Riders</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.statCard, { backgroundColor: '#e3f2fd' }]} onPress={() => router.push('/(admin)/customers')}>
                <Ionicons name="people" size={28} color="#3498db" />
                <Text style={styles.statValue}>{stats.customers}</Text>
                <Text style={styles.statLabel}>Customers</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.statCard, { backgroundColor: '#f3e5f5' }]} onPress={() => router.push('/(admin)/admin-orders')}>
                <Ionicons name="receipt" size={28} color="#9b59b6" />
                <Text style={styles.statValue}>{stats.orders}</Text>
                <Text style={styles.statLabel}>Total Orders</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.sectionTitle}>Quick Actions</Text>

            <TouchableOpacity style={styles.actionCard} onPress={() => router.push('/(admin)/riders')}>
              <View style={[styles.actionIcon, { backgroundColor: '#fff3e0' }]}>
                <Ionicons name="person-add" size={24} color="#f39c12" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.actionTitle}>Pending Rider Approvals</Text>
                <Text style={styles.actionDesc}>{stats.pendingRiders} riders waiting for approval</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#999" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionCard} onPress={() => router.push('/(admin)/admin-orders')}>
              <View style={[styles.actionIcon, { backgroundColor: '#e3f2fd' }]}>
                <Ionicons name="swap-horizontal" size={24} color="#3498db" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.actionTitle}>Manage Orders</Text>
                <Text style={styles.actionDesc}>Assign riders, fail orders, manage deliveries</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#999" />
            </TouchableOpacity>

            <TouchableOpacity style={styles.actionCard} onPress={() => router.push('/(admin)/customers')}>
              <View style={[styles.actionIcon, { backgroundColor: '#e8f5e9' }]}>
                <Ionicons name="people" size={24} color="#2ECC71" />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={styles.actionTitle}>Manage Customers</Text>
                <Text style={styles.actionDesc}>View and manage customer accounts</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#999" />
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: '#1a5c2e', paddingTop: 55, paddingBottom: 20, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  greeting: { color: '#8bc99b', fontSize: 14 },
  userName: { color: '#fff', fontSize: 22, fontWeight: '800' },
  logoutBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.2)', justifyContent: 'center', alignItems: 'center' },
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 20 },
  statCard: {
    width: '47%', borderRadius: 16, padding: 16, alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2,
  },
  statValue: { fontSize: 24, fontWeight: '800', color: '#1a1a1a', marginTop: 8 },
  statLabel: { fontSize: 12, color: '#666', marginTop: 2 },
  sectionTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a1a', marginBottom: 14 },
  actionCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 14, padding: 16, marginBottom: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  actionIcon: { width: 48, height: 48, borderRadius: 14, justifyContent: 'center', alignItems: 'center', marginRight: 14 },
  actionTitle: { fontSize: 15, fontWeight: '700', color: '#1a1a1a' },
  actionDesc: { fontSize: 12, color: '#888', marginTop: 2 },
});
