import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator, Alert, RefreshControl } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabase';

interface Rider {
  id: string;
  name: string;
  email: string;
  phone: string;
  delivery_method: string;
  is_approved: boolean;
  created_at: string;
}

export default function RidersScreen() {
  const [riders, setRiders] = useState<Rider[]>([]);
  const [pendingRiders, setPendingRiders] = useState<Rider[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [tab, setTab] = useState<'pending' | 'all'>('pending');

  const fetchData = async () => {
    try {
      const [allRes, pendingRes] = await Promise.all([
        supabase.functions.invoke('admin', { body: { action: 'get_all_riders' } }),
        supabase.functions.invoke('admin', { body: { action: 'get_pending_riders' } }),
      ]);
      setRiders(allRes.data?.riders || []);
      setPendingRiders(pendingRes.data?.riders || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const approveRider = async (riderId: string) => {
    try {
      await supabase.functions.invoke('admin', { body: { action: 'approve_rider', rider_id: riderId } });
      Alert.alert('Success', 'Rider approved successfully!');
      fetchData();
    } catch (err: any) {
      Alert.alert('Error', err.message);
    }
  };

  const rejectRider = async (riderId: string) => {
    Alert.alert('Reject Rider', 'Are you sure you want to reject this rider?', [
      { text: 'Cancel' },
      {
        text: 'Reject', style: 'destructive',
        onPress: async () => {
          try {
            await supabase.functions.invoke('admin', { body: { action: 'reject_rider', rider_id: riderId } });
            Alert.alert('Done', 'Rider rejected');
            fetchData();
          } catch (err: any) {
            Alert.alert('Error', err.message);
          }
        },
      },
    ]);
  };

  const currentData = tab === 'pending' ? pendingRiders : riders;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Manage Riders</Text>
        <Text style={styles.headerSub}>{pendingRiders.length} pending approvals</Text>
      </View>

      <View style={styles.tabs}>
        <TouchableOpacity style={[styles.tab, tab === 'pending' && styles.tabActive]} onPress={() => setTab('pending')}>
          <Text style={[styles.tabText, tab === 'pending' && styles.tabTextActive]}>Pending ({pendingRiders.length})</Text>
        </TouchableOpacity>
        <TouchableOpacity style={[styles.tab, tab === 'all' && styles.tabActive]} onPress={() => setTab('all')}>
          <Text style={[styles.tabText, tab === 'all' && styles.tabTextActive]}>All Riders ({riders.length})</Text>
        </TouchableOpacity>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#2ECC71" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={currentData}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor="#2ECC71" />}
          contentContainerStyle={{ padding: 16 }}
          renderItem={({ item }) => (
            <View style={styles.riderCard}>
              <View style={styles.riderInfo}>
                <View style={styles.avatar}>
                  <Ionicons name="person" size={24} color="#fff" />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={styles.riderName}>{item.name}</Text>
                  <Text style={styles.riderEmail}>{item.email}</Text>
                  <Text style={styles.riderPhone}>{item.phone}</Text>
                  <View style={styles.methodRow}>
                    <Ionicons name={item.delivery_method === 'bicycle' ? 'bicycle' : 'car-sport'} size={14} color="#2ECC71" />
                    <Text style={styles.methodText}>{item.delivery_method || 'N/A'}</Text>
                    <View style={[styles.approvalBadge, { backgroundColor: item.is_approved ? '#e8f5e9' : '#fff3e0' }]}>
                      <Text style={[styles.approvalText, { color: item.is_approved ? '#2ECC71' : '#f39c12' }]}>
                        {item.is_approved ? 'Approved' : 'Pending'}
                      </Text>
                    </View>
                  </View>
                </View>
              </View>
              {!item.is_approved && (
                <View style={styles.actions}>
                  <TouchableOpacity style={styles.approveBtn} onPress={() => approveRider(item.id)}>
                    <Ionicons name="checkmark" size={16} color="#fff" />
                    <Text style={styles.approveBtnText}>Approve</Text>
                  </TouchableOpacity>
                  <TouchableOpacity style={styles.rejectBtn} onPress={() => rejectRider(item.id)}>
                    <Ionicons name="close" size={16} color="#fff" />
                    <Text style={styles.rejectBtnText}>Reject</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}
          keyExtractor={(item) => item.id}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="bicycle-outline" size={48} color="#ccc" />
              <Text style={styles.emptyText}>{tab === 'pending' ? 'No pending riders' : 'No riders yet'}</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    backgroundColor: '#1a5c2e', paddingTop: 55, paddingBottom: 16, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800' },
  headerSub: { color: '#8bc99b', fontSize: 13, marginTop: 2 },
  tabs: { flexDirection: 'row', marginHorizontal: 16, marginTop: 14, backgroundColor: '#e8f5e9', borderRadius: 12, padding: 4 },
  tab: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 10 },
  tabActive: { backgroundColor: '#2ECC71' },
  tabText: { fontSize: 14, fontWeight: '600', color: '#666' },
  tabTextActive: { color: '#fff' },
  riderCard: {
    backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  riderInfo: { flexDirection: 'row', alignItems: 'flex-start' },
  avatar: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#2ECC71', justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  riderName: { fontSize: 16, fontWeight: '700', color: '#333' },
  riderEmail: { fontSize: 13, color: '#888' },
  riderPhone: { fontSize: 13, color: '#555' },
  methodRow: { flexDirection: 'row', alignItems: 'center', marginTop: 4 },
  methodText: { fontSize: 12, color: '#2ECC71', fontWeight: '600', marginLeft: 4, marginRight: 8 },
  approvalBadge: { paddingHorizontal: 8, paddingVertical: 2, borderRadius: 8 },
  approvalText: { fontSize: 11, fontWeight: '700' },
  actions: { flexDirection: 'row', gap: 10, marginTop: 12 },
  approveBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#2ECC71', borderRadius: 10, padding: 10 },
  approveBtnText: { color: '#fff', fontWeight: '700', marginLeft: 4 },
  rejectBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e74c3c', borderRadius: 10, padding: 10 },
  rejectBtnText: { color: '#fff', fontWeight: '700', marginLeft: 4 },
  empty: { alignItems: 'center', marginTop: 60 },
  emptyText: { fontSize: 16, color: '#999', marginTop: 12 },
});
