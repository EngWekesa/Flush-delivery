import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator, Alert, RefreshControl, Modal, TextInput } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from '../lib/supabase';

interface Order {
  id: string;
  customer_name: string;
  customer_phone: string;
  rider_name?: string;
  rider_id?: string;
  status: string;
  total_amount: number;
  delivery_fee: number;
  location_address: string;
  created_at: string;
  order_items: { item_name: string; restaurant_name: string; quantity: number; price: number }[];
}

interface Rider {
  id: string;
  name: string;
  delivery_method: string;
}

const statusColors: { [key: string]: string } = {
  pending: '#f39c12',
  processing: '#3498db',
  in_transit: '#9b59b6',
  completed: '#2ECC71',
  failed: '#e74c3c',
};

export default function AdminOrdersScreen() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [riders, setRiders] = useState<Rider[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [assignModal, setAssignModal] = useState<Order | null>(null);
  const [filterStatus, setFilterStatus] = useState('all');

  const fetchData = async () => {
    try {
      const [ordersRes, ridersRes] = await Promise.all([
        supabase.functions.invoke('orders', { body: { action: 'get_all_orders' } }),
        supabase.functions.invoke('admin', { body: { action: 'get_all_riders' } }),
      ]);
      setOrders(ordersRes.data?.orders || []);
      setRiders((ridersRes.data?.riders || []).filter((r: Rider & { is_approved: boolean }) => r.is_approved));
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  const assignRider = async (orderId: string, riderId: string) => {
    try {
      await supabase.functions.invoke('orders', {
        body: { action: 'assign_rider', order_id: orderId, rider_id: riderId },
      });
      Alert.alert('Success', 'Rider assigned successfully!');
      setAssignModal(null);
      fetchData();
    } catch (err: any) {
      Alert.alert('Error', err.message);
    }
  };

  const failOrder = (orderId: string) => {
    Alert.alert('Fail Order', 'Are you sure?', [
      { text: 'Cancel' },
      {
        text: 'Fail', style: 'destructive',
        onPress: async () => {
          try {
            await supabase.functions.invoke('orders', {
              body: { action: 'update_order_status', order_id: orderId, status: 'failed' },
            });
            Alert.alert('Done', 'Order marked as failed');
            fetchData();
          } catch (err: any) {
            Alert.alert('Error', err.message);
          }
        },
      },
    ]);
  };

  const removeRider = async (orderId: string) => {
    try {
      await supabase.functions.invoke('orders', {
        body: { action: 'update_order_status', order_id: orderId, status: 'pending', rider_id: null },
      });
      Alert.alert('Done', 'Rider removed from order');
      fetchData();
    } catch (err: any) {
      Alert.alert('Error', err.message);
    }
  };

  const statuses = ['all', 'pending', 'processing', 'in_transit', 'completed', 'failed'];
  const filtered = filterStatus === 'all' ? orders : orders.filter(o => o.status === filterStatus);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>All Orders</Text>
        <Text style={styles.headerSub}>{orders.length} total orders</Text>
      </View>

      <FlatList
        horizontal
        data={statuses}
        showsHorizontalScrollIndicator={false}
        style={styles.filterList}
        contentContainerStyle={{ paddingHorizontal: 16 }}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={[styles.filterChip, filterStatus === item && styles.filterChipActive]}
            onPress={() => setFilterStatus(item)}
          >
            <Text style={[styles.filterText, filterStatus === item && styles.filterTextActive]}>
              {item === 'all' ? 'All' : item === 'in_transit' ? 'In Transit' : item.charAt(0).toUpperCase() + item.slice(1)}
            </Text>
          </TouchableOpacity>
        )}
        keyExtractor={(item) => item}
      />

      {loading ? (
        <ActivityIndicator size="large" color="#2ECC71" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={filtered}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchData(); }} tintColor="#2ECC71" />}
          contentContainerStyle={{ padding: 16, paddingBottom: 30 }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={styles.orderCard}>
              <View style={styles.orderHeader}>
                <Text style={styles.orderId}>#{item.id.slice(0, 8)}</Text>
                <View style={[styles.statusBadge, { backgroundColor: (statusColors[item.status] || '#999') + '20' }]}>
                  <Text style={[styles.statusText, { color: statusColors[item.status] || '#999' }]}>
                    {item.status === 'in_transit' ? 'In Transit' : item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                  </Text>
                </View>
              </View>

              <Text style={styles.customerText}>Customer: {item.customer_name} ({item.customer_phone})</Text>
              {item.rider_name && <Text style={styles.riderText}>Rider: {item.rider_name}</Text>}
              <Text style={styles.locationText}>{item.location_address || 'Juja'}</Text>

              <View style={styles.itemsList}>
                {item.order_items?.slice(0, 3).map((oi, idx) => (
                  <Text key={idx} style={styles.itemText}>{oi.quantity}x {oi.item_name} - {oi.restaurant_name}</Text>
                ))}
                {(item.order_items?.length || 0) > 3 && <Text style={styles.moreText}>+{(item.order_items?.length || 0) - 3} more</Text>}
              </View>

              <View style={styles.orderFooter}>
                <Text style={styles.totalText}>KSh {item.total_amount}</Text>
                <Text style={styles.dateText}>{new Date(item.created_at).toLocaleDateString()}</Text>
              </View>

              {item.status !== 'completed' && item.status !== 'failed' && (
                <View style={styles.actions}>
                  <TouchableOpacity style={styles.assignBtn} onPress={() => setAssignModal(item)}>
                    <Ionicons name="person-add" size={14} color="#fff" />
                    <Text style={styles.actionText}>{item.rider_id ? 'Reassign' : 'Assign'} Rider</Text>
                  </TouchableOpacity>
                  {item.rider_id && (
                    <TouchableOpacity style={styles.removeRiderBtn} onPress={() => removeRider(item.id)}>
                      <Ionicons name="person-remove" size={14} color="#fff" />
                      <Text style={styles.actionText}>Remove</Text>
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity style={styles.failBtn} onPress={() => failOrder(item.id)}>
                    <Ionicons name="close-circle" size={14} color="#fff" />
                    <Text style={styles.actionText}>Fail</Text>
                  </TouchableOpacity>
                </View>
              )}
            </View>
          )}
          keyExtractor={(item) => item.id}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="receipt-outline" size={48} color="#ccc" />
              <Text style={styles.emptyText}>No orders found</Text>
            </View>
          }
        />
      )}

      {/* Assign Rider Modal */}
      <Modal visible={!!assignModal} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Assign Rider</Text>
              <TouchableOpacity onPress={() => setAssignModal(null)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>
            <Text style={styles.modalSub}>Order #{assignModal?.id.slice(0, 8)}</Text>
            <FlatList
              data={riders}
              renderItem={({ item: rider }) => (
                <TouchableOpacity
                  style={styles.riderOption}
                  onPress={() => assignModal && assignRider(assignModal.id, rider.id)}
                >
                  <View style={styles.riderAvatar}>
                    <Ionicons name="person" size={20} color="#fff" />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.riderName}>{rider.name}</Text>
                    <Text style={styles.riderMethod}>{rider.delivery_method}</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={20} color="#999" />
                </TouchableOpacity>
              )}
              keyExtractor={(item) => item.id}
              ListEmptyComponent={<Text style={styles.noRiders}>No approved riders available</Text>}
            />
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    backgroundColor: '#1a5c2e', paddingTop: 55, paddingBottom: 16, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800' },
  headerSub: { color: '#8bc99b', fontSize: 13, marginTop: 2 },
  filterList: { maxHeight: 50, marginTop: 12 },
  filterChip: { paddingHorizontal: 14, paddingVertical: 8, borderRadius: 20, backgroundColor: '#fff', marginRight: 8, borderWidth: 1, borderColor: '#e0e0e0' },
  filterChipActive: { backgroundColor: '#1a5c2e', borderColor: '#1a5c2e' },
  filterText: { fontSize: 13, color: '#666', fontWeight: '600' },
  filterTextActive: { color: '#fff' },
  orderCard: {
    backgroundColor: '#fff', borderRadius: 14, padding: 14, marginBottom: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  orderId: { fontSize: 14, fontWeight: '700', color: '#333' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 3, borderRadius: 10 },
  statusText: { fontSize: 12, fontWeight: '700' },
  customerText: { fontSize: 13, color: '#555', marginBottom: 2 },
  riderText: { fontSize: 13, color: '#2ECC71', fontWeight: '600', marginBottom: 2 },
  locationText: { fontSize: 12, color: '#888', marginBottom: 8 },
  itemsList: { backgroundColor: '#f8f9fa', borderRadius: 8, padding: 8, marginBottom: 8 },
  itemText: { fontSize: 12, color: '#555', marginBottom: 2 },
  moreText: { fontSize: 11, color: '#999', fontStyle: 'italic' },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  totalText: { fontSize: 15, fontWeight: '800', color: '#2ECC71' },
  dateText: { fontSize: 12, color: '#999' },
  actions: { flexDirection: 'row', gap: 6 },
  assignBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#3498db', borderRadius: 8, padding: 8 },
  removeRiderBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#f39c12', borderRadius: 8, padding: 8, paddingHorizontal: 12 },
  failBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', backgroundColor: '#e74c3c', borderRadius: 8, padding: 8, paddingHorizontal: 12 },
  actionText: { color: '#fff', fontSize: 12, fontWeight: '700', marginLeft: 4 },
  empty: { alignItems: 'center', marginTop: 60 },
  emptyText: { fontSize: 16, color: '#999', marginTop: 12 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '70%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  modalTitle: { fontSize: 20, fontWeight: '800', color: '#1a1a1a' },
  modalSub: { fontSize: 14, color: '#888', marginBottom: 16 },
  riderOption: {
    flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: '#f0f0f0',
  },
  riderAvatar: { width: 40, height: 40, borderRadius: 20, backgroundColor: '#2ECC71', justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  riderName: { fontSize: 15, fontWeight: '600', color: '#333' },
  riderMethod: { fontSize: 12, color: '#888' },
  noRiders: { textAlign: 'center', color: '#999', marginTop: 20 },
});
