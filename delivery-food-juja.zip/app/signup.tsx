import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, ScrollView, Alert, ActivityIndicator } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';

export default function SignupScreen() {
  const router = useRouter();
  const { role } = useLocalSearchParams<{ role: string }>();
  const isRider = role === 'rider';

  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [deliveryMethod, setDeliveryMethod] = useState('motorbike');
  const [showMethodPicker, setShowMethodPicker] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSignup = async () => {
    if (!name || !email || !phone || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }
    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }
    if (password.length < 6) {
      Alert.alert('Error', 'Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        body: {
          action: 'signup',
          name,
          email: email.toLowerCase().trim(),
          phone,
          password,
          role: role || 'customer',
          delivery_method: isRider ? deliveryMethod : null,
        },
      });

      if (error) throw error;
      if (data?.error) {
        Alert.alert('Error', data.error);
        return;
      }

      if (data?.pending) {
        Alert.alert(
          'Registration Successful',
          'Your rider account is pending admin approval. You will be able to log in once approved.',
          [{ text: 'OK', onPress: () => router.replace('/') }]
        );
      } else {
        Alert.alert(
          'Welcome!',
          'Account created successfully! Please log in.',
          [{ text: 'OK', onPress: () => router.replace('/login') }]
        );
      }
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#1a5c2e" />
        </TouchableOpacity>

        <View style={styles.header}>
          <View style={[styles.iconWrap, isRider && { backgroundColor: '#27AE60' }]}>
            <Ionicons name={isRider ? 'bicycle' : 'person'} size={36} color="#fff" />
          </View>
          <Text style={styles.title}>Sign Up as {isRider ? 'Rider' : 'Customer'}</Text>
          {isRider && (
            <Text style={styles.notice}>
              Note: Rider accounts require admin approval before you can log in.
            </Text>
          )}
        </View>

        <View style={styles.form}>
          <Text style={styles.label}>Full Name</Text>
          <View style={styles.inputWrap}>
            <Ionicons name="person-outline" size={20} color="#999" />
            <TextInput style={styles.input} placeholder="Enter your full name" value={name} onChangeText={setName} />
          </View>

          <Text style={styles.label}>Email</Text>
          <View style={styles.inputWrap}>
            <Ionicons name="mail-outline" size={20} color="#999" />
            <TextInput style={styles.input} placeholder="Enter your email" value={email} onChangeText={setEmail} keyboardType="email-address" autoCapitalize="none" />
          </View>

          <Text style={styles.label}>Phone Number</Text>
          <View style={styles.inputWrap}>
            <Ionicons name="call-outline" size={20} color="#999" />
            <TextInput style={styles.input} placeholder="e.g. 0712345678" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
          </View>

          {isRider && (
            <>
              <Text style={styles.label}>Delivery Method</Text>
              <TouchableOpacity style={styles.inputWrap} onPress={() => setShowMethodPicker(!showMethodPicker)}>
                <Ionicons name={deliveryMethod === 'bicycle' ? 'bicycle' : 'car-sport-outline'} size={20} color="#999" />
                <Text style={[styles.input, { paddingVertical: 14 }]}>
                  {deliveryMethod === 'bicycle' ? 'Bicycle' : 'Motorbike'}
                </Text>
                <Ionicons name="chevron-down" size={20} color="#999" />
              </TouchableOpacity>
              {showMethodPicker && (
                <View style={styles.picker}>
                  <TouchableOpacity
                    style={[styles.pickerItem, deliveryMethod === 'motorbike' && styles.pickerItemActive]}
                    onPress={() => { setDeliveryMethod('motorbike'); setShowMethodPicker(false); }}
                  >
                    <Ionicons name="car-sport-outline" size={20} color={deliveryMethod === 'motorbike' ? '#2ECC71' : '#666'} />
                    <Text style={[styles.pickerText, deliveryMethod === 'motorbike' && { color: '#2ECC71' }]}>Motorbike</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.pickerItem, deliveryMethod === 'bicycle' && styles.pickerItemActive]}
                    onPress={() => { setDeliveryMethod('bicycle'); setShowMethodPicker(false); }}
                  >
                    <Ionicons name="bicycle" size={20} color={deliveryMethod === 'bicycle' ? '#2ECC71' : '#666'} />
                    <Text style={[styles.pickerText, deliveryMethod === 'bicycle' && { color: '#2ECC71' }]}>Bicycle</Text>
                  </TouchableOpacity>
                </View>
              )}
            </>
          )}

          <Text style={styles.label}>Password</Text>
          <View style={styles.inputWrap}>
            <Ionicons name="lock-closed-outline" size={20} color="#999" />
            <TextInput style={styles.input} placeholder="Create a password" value={password} onChangeText={setPassword} secureTextEntry />
          </View>

          <Text style={styles.label}>Confirm Password</Text>
          <View style={styles.inputWrap}>
            <Ionicons name="lock-closed-outline" size={20} color="#999" />
            <TextInput style={styles.input} placeholder="Confirm your password" value={confirmPassword} onChangeText={setConfirmPassword} secureTextEntry />
          </View>

          <TouchableOpacity style={styles.submitBtn} onPress={handleSignup} disabled={loading}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <Text style={styles.submitText}>{isRider ? 'Confirm Registration' : 'Create Account'}</Text>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={styles.loginLink} onPress={() => router.push('/login')}>
            <Text style={styles.loginLinkText}>Already have an account? <Text style={{ color: '#2ECC71', fontWeight: '700' }}>Log In</Text></Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  scroll: { padding: 20, paddingTop: 50 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#e8f5e9', justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  header: { alignItems: 'center', marginBottom: 24 },
  iconWrap: { width: 72, height: 72, borderRadius: 36, backgroundColor: '#2ECC71', justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  title: { fontSize: 24, fontWeight: '800', color: '#1a1a1a' },
  notice: { fontSize: 12, color: '#e67e22', textAlign: 'center', marginTop: 8, backgroundColor: '#fef9e7', padding: 10, borderRadius: 8 },
  form: {},
  label: { fontSize: 14, fontWeight: '600', color: '#444', marginBottom: 6, marginTop: 12 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 12, paddingHorizontal: 14, borderWidth: 1, borderColor: '#e0e0e0',
  },
  input: { flex: 1, fontSize: 15, color: '#333', paddingVertical: 14, marginLeft: 10 },
  picker: { backgroundColor: '#fff', borderRadius: 12, borderWidth: 1, borderColor: '#e0e0e0', marginTop: 4 },
  pickerItem: { flexDirection: 'row', alignItems: 'center', padding: 14, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  pickerItemActive: { backgroundColor: '#e8f5e9' },
  pickerText: { fontSize: 15, color: '#333', marginLeft: 10 },
  submitBtn: {
    backgroundColor: '#2ECC71', borderRadius: 14, padding: 16, alignItems: 'center', marginTop: 24,
  },
  submitText: { color: '#fff', fontSize: 17, fontWeight: '700' },
  loginLink: { alignItems: 'center', marginTop: 20, marginBottom: 40 },
  loginLinkText: { fontSize: 14, color: '#888' },
});
