import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, SafeAreaView, ScrollView } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { IMAGES } from './lib/images';

export default function LandingScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <View style={styles.logoSection}>
          <Image source={{ uri: IMAGES.logo }} style={styles.logo} />
          <Text style={styles.title}>FLUSH DELIVERY</Text>
          <Text style={styles.subtitle}>Juja's #1 Food Delivery Service</Text>
        </View>

        <Image source={{ uri: IMAGES.heroBanner }} style={styles.heroBanner} />

        <Text style={styles.sectionTitle}>Get Started</Text>
        <Text style={styles.sectionSubtitle}>Choose how you want to join us</Text>

        <TouchableOpacity
          style={styles.roleCard}
          onPress={() => router.push('/signup?role=customer')}
        >
          <View style={styles.roleIconWrap}>
            <Ionicons name="person" size={32} color="#fff" />
          </View>
          <View style={styles.roleInfo}>
            <Text style={styles.roleTitle}>Sign Up as Customer</Text>
            <Text style={styles.roleDesc}>Order food from your favorite Juja restaurants</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color="#2ECC71" />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.roleCard}
          onPress={() => router.push('/signup?role=rider')}
        >
          <View style={[styles.roleIconWrap, { backgroundColor: '#27AE60' }]}>
            <Ionicons name="bicycle" size={32} color="#fff" />
          </View>
          <View style={styles.roleInfo}>
            <Text style={styles.roleTitle}>Sign Up as Rider</Text>
            <Text style={styles.roleDesc}>Deliver food and earn money in Juja</Text>
          </View>
          <Ionicons name="chevron-forward" size={24} color="#2ECC71" />
        </TouchableOpacity>

        <View style={styles.divider}>
          <View style={styles.dividerLine} />
          <Text style={styles.dividerText}>Already have an account?</Text>
          <View style={styles.dividerLine} />
        </View>

        <TouchableOpacity
          style={styles.loginBtn}
          onPress={() => router.push('/login')}
        >
          <Ionicons name="log-in-outline" size={22} color="#fff" />
          <Text style={styles.loginBtnText}>Log In</Text>
        </TouchableOpacity>

        <View style={styles.contactBar}>
          <Ionicons name="call" size={18} color="#2ECC71" />
          <Text style={styles.contactText}>For queries call: 0708770746</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  scroll: { padding: 20, paddingTop: 50 },
  logoSection: { alignItems: 'center', marginBottom: 20 },
  logo: { width: 100, height: 100, borderRadius: 50, marginBottom: 12 },
  title: { fontSize: 28, fontWeight: '800', color: '#1a5c2e', letterSpacing: 1 },
  subtitle: { fontSize: 14, color: '#666', marginTop: 4 },
  heroBanner: { width: '100%', height: 180, borderRadius: 16, marginBottom: 24 },
  sectionTitle: { fontSize: 22, fontWeight: '700', color: '#1a1a1a', textAlign: 'center' },
  sectionSubtitle: { fontSize: 14, color: '#888', textAlign: 'center', marginBottom: 20 },
  roleCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 16, padding: 18, marginBottom: 14,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 3,
    borderWidth: 1, borderColor: '#e8f5e9',
  },
  roleIconWrap: {
    width: 56, height: 56, borderRadius: 28, backgroundColor: '#2ECC71',
    justifyContent: 'center', alignItems: 'center', marginRight: 14,
  },
  roleInfo: { flex: 1 },
  roleTitle: { fontSize: 17, fontWeight: '700', color: '#1a1a1a' },
  roleDesc: { fontSize: 13, color: '#888', marginTop: 2 },
  divider: { flexDirection: 'row', alignItems: 'center', marginVertical: 24 },
  dividerLine: { flex: 1, height: 1, backgroundColor: '#ddd' },
  dividerText: { marginHorizontal: 12, color: '#888', fontSize: 13 },
  loginBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#2ECC71', borderRadius: 14, padding: 16, marginBottom: 20,
  },
  loginBtnText: { color: '#fff', fontSize: 17, fontWeight: '700', marginLeft: 8 },
  contactBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#e8f5e9', borderRadius: 12, padding: 14, marginBottom: 30,
  },
  contactText: { color: '#1a5c2e', fontSize: 14, fontWeight: '600', marginLeft: 8 },
});
