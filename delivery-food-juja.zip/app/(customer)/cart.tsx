import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, ScrollView, TextInput, Alert, ActivityIndicator, Modal, Platform } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../lib/store';
import { supabase } from '../lib/supabase';

export default function CartScreen() {
  const router = useRouter();
  const { user, cart, removeFromCart, updateQuantity, clearCart, getCartTotal } = useStore();
  const [phone, setPhone] = useState(user?.phone || '');
  const [doorNumber, setDoorNumber] = useState('');
  const [description, setDescription] = useState('');
  const [location, setLocation] = useState('');
  const [locationLat, setLocationLat] = useState(0);
  const [locationLng, setLocationLng] = useState(0);
  const [loading, setLoading] = useState(false);
  const [fetchingLocation, setFetchingLocation] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);
  const [orderTotal, setOrderTotal] = useState(0);

  const subtotal = getCartTotal();
  // Delivery fee: KSh 70 for 800m or less, KSh 25 for each additional 1km
  const baseDeliveryFee = 70;
  const [deliveryFee, setDeliveryFee] = useState(baseDeliveryFee);
  const total = subtotal + deliveryFee;

  const fetchLocation = async () => {
    setFetchingLocation(true);
    try {
      // Use a default Juja location for demo
      // In production, use expo-location
      if (Platform.OS === 'web') {
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(
            (position) => {
              const lat = position.coords.latitude;
              const lng = position.coords.longitude;
              setLocationLat(lat);
              setLocationLng(lng);
              setLocation(`Juja, Kenya (${lat.toFixed(4)}, ${lng.toFixed(4)})`);
              // Calculate delivery fee based on distance (simplified)
              const distance = Math.random() * 3 + 0.5; // Simulated distance in km
              let fee = 70;
              if (distance > 0.8) {
                fee += Math.ceil(distance - 0.8) * 25;
              }
              setDeliveryFee(fee);
              setFetchingLocation(false);
            },
            () => {
              setLocation('Juja Town, Kenya');
              setLocationLat(-1.1005);
              setLocationLng(37.0144);
              setDeliveryFee(70);
              setFetchingLocation(false);
            }
          );
        } else {
          setLocation('Juja Town, Kenya');
          setLocationLat(-1.1005);
          setLocationLng(37.0144);
          setFetchingLocation(false);
        }
      } else {
        // For native, default to Juja coordinates
        setLocation('Juja Town, Kenya');
        setLocationLat(-1.1005);
        setLocationLng(37.0144);
        setDeliveryFee(70);
        setFetchingLocation(false);
      }
    } catch (err) {
      setLocation('Juja Town, Kenya');
      setLocationLat(-1.1005);
      setLocationLng(37.0144);
      setFetchingLocation(false);
    }
  };

  const handleConfirmOrder = async () => {
    if (!phone) {
      Alert.alert('Error', 'Please enter your phone number');
      return;
    }
    if (!location) {
      Alert.alert('Error', 'Please fetch your location first');
      return;
    }
    if (cart.length === 0) {
      Alert.alert('Error', 'Your cart is empty');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('orders', {
        body: {
          action: 'create_order',
          customer_id: user?.id,
          items: cart.map(item => ({
            restaurant_name: item.restaurant_name,
            item_name: item.item_name,
            price: item.price,
            quantity: item.quantity,
          })),
          phone,
          door_number: doorNumber,
          description,
          location_lat: locationLat,
          location_lng: locationLng,
          location_address: location,
          total_amount: total,
          delivery_fee: deliveryFee,
        },
      });

      if (error) throw error;
      if (data?.error) throw new Error(data.error);

      setOrderTotal(total);
      setShowSuccess(true);
      clearCart();
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Failed to place order');
    } finally {
      setLoading(false);
    }
  };

  // Group cart items by restaurant
  const grouped: { [key: string]: typeof cart } = {};
  cart.forEach(item => {
    if (!grouped[item.restaurant_name]) grouped[item.restaurant_name] = [];
    grouped[item.restaurant_name].push(item);
  });

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Your Cart</Text>
        <Text style={styles.headerSub}>{cart.length} items</Text>
      </View>

      <ScrollView contentContainerStyle={{ paddingBottom: 30 }} showsVerticalScrollIndicator={false}>
        {cart.length === 0 ? (
          <View style={styles.empty}>
            <Ionicons name="cart-outline" size={64} color="#ccc" />
            <Text style={styles.emptyTitle}>Your cart is empty</Text>
            <Text style={styles.emptyText}>Browse restaurants and add items</Text>
            <TouchableOpacity style={styles.browseBtn} onPress={() => router.push('/(customer)/restaurants')}>
              <Text style={styles.browseBtnText}>Browse Restaurants</Text>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            {Object.entries(grouped).map(([restaurant, items]) => (
              <View key={restaurant} style={styles.restaurantGroup}>
                <View style={styles.restaurantHeader}>
                  <Ionicons name="restaurant" size={16} color="#2ECC71" />
                  <Text style={styles.restaurantName}>{restaurant}</Text>
                </View>
                {items.map((item, idx) => {
                  const cartIndex = cart.findIndex(
                    c => c.item_name === item.item_name && c.restaurant_name === item.restaurant_name
                  );
                  return (
                    <View key={idx} style={styles.cartItem}>
                      <View style={styles.cartItemInfo}>
                        <Text style={styles.cartItemName}>{item.item_name}</Text>
                        <Text style={styles.cartItemPrice}>KSh {item.price} x {item.quantity} = KSh {item.price * item.quantity}</Text>
                      </View>
                      <View style={styles.cartItemActions}>
                        <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQuantity(cartIndex, item.quantity - 1)}>
                          <Ionicons name="remove" size={14} color="#e74c3c" />
                        </TouchableOpacity>
                        <Text style={styles.qtyText}>{item.quantity}</Text>
                        <TouchableOpacity style={styles.qtyBtn} onPress={() => updateQuantity(cartIndex, item.quantity + 1)}>
                          <Ionicons name="add" size={14} color="#2ECC71" />
                        </TouchableOpacity>
                        <TouchableOpacity onPress={() => removeFromCart(cartIndex)} style={styles.removeBtn}>
                          <Ionicons name="trash-outline" size={16} color="#e74c3c" />
                        </TouchableOpacity>
                      </View>
                    </View>
                  );
                })}
              </View>
            ))}

            {/* Delivery Details */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Delivery Details</Text>

              <Text style={styles.label}>Phone Number</Text>
              <View style={styles.inputWrap}>
                <Ionicons name="call-outline" size={18} color="#999" />
                <TextInput style={styles.input} placeholder="Your phone number" value={phone} onChangeText={setPhone} keyboardType="phone-pad" />
              </View>

              <Text style={styles.label}>Door Number</Text>
              <View style={styles.inputWrap}>
                <Ionicons name="home-outline" size={18} color="#999" />
                <TextInput style={styles.input} placeholder="e.g. House 12, Block A" value={doorNumber} onChangeText={setDoorNumber} />
              </View>

              <Text style={styles.label}>Additional Description (Optional)</Text>
              <View style={[styles.inputWrap, { alignItems: 'flex-start' }]}>
                <Ionicons name="document-text-outline" size={18} color="#999" style={{ marginTop: 12 }} />
                <TextInput
                  style={[styles.input, { minHeight: 60, textAlignVertical: 'top' }]}
                  placeholder="Any special instructions..."
                  value={description}
                  onChangeText={setDescription}
                  multiline
                />
              </View>

              <Text style={styles.label}>Location</Text>
              <View style={styles.locationRow}>
                <View style={[styles.inputWrap, { flex: 1 }]}>
                  <Ionicons name="location-outline" size={18} color="#999" />
                  <Text style={[styles.input, { paddingVertical: 14, color: location ? '#333' : '#999' }]}>
                    {location || 'Tap to fetch location'}
                  </Text>
                </View>
                <TouchableOpacity style={styles.locationBtn} onPress={fetchLocation} disabled={fetchingLocation}>
                  {fetchingLocation ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <Ionicons name="navigate" size={20} color="#fff" />
                  )}
                </TouchableOpacity>
              </View>
            </View>

            {/* Order Summary */}
            <View style={styles.summary}>
              <Text style={styles.summaryTitle}>Order Summary</Text>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Subtotal</Text>
                <Text style={styles.summaryValue}>KSh {subtotal}</Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Delivery Fee</Text>
                <Text style={styles.summaryValue}>KSh {deliveryFee}</Text>
              </View>
              <View style={[styles.summaryRow, styles.totalRow]}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>KSh {total}</Text>
              </View>
            </View>

            <TouchableOpacity
              style={[styles.confirmBtn, (!location || loading) && styles.confirmBtnDisabled]}
              onPress={handleConfirmOrder}
              disabled={!location || loading}
            >
              {loading ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <>
                  <Ionicons name="checkmark-circle" size={22} color="#fff" />
                  <Text style={styles.confirmBtnText}>Confirm Order - KSh {total}</Text>
                </>
              )}
            </TouchableOpacity>
          </>
        )}
      </ScrollView>

      {/* Success Modal */}
      <Modal visible={showSuccess} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.successIcon}>
              <Ionicons name="checkmark-circle" size={64} color="#2ECC71" />
            </View>
            <Text style={styles.successTitle}>Order Placed!</Text>
            <Text style={styles.successText}>
              {user?.name}, your order has been successfully placed! Please have{' '}
              <Text style={{ fontWeight: '800', color: '#2ECC71' }}>KSh {orderTotal}</Text>{' '}
              ready while your order arrives!
            </Text>
            <TouchableOpacity
              style={styles.successBtn}
              onPress={() => {
                setShowSuccess(false);
                router.push('/(customer)/orders');
              }}
            >
              <Text style={styles.successBtnText}>Track My Order</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.successBtnOutline}
              onPress={() => {
                setShowSuccess(false);
                router.push('/(customer)');
              }}
            >
              <Text style={styles.successBtnOutlineText}>Back to Home</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    backgroundColor: '#2ECC71', paddingTop: 55, paddingBottom: 16, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800' },
  headerSub: { color: '#c8f7dc', fontSize: 13, marginTop: 2 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#333', marginTop: 16 },
  emptyText: { fontSize: 14, color: '#888', marginTop: 4 },
  browseBtn: { backgroundColor: '#2ECC71', borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12, marginTop: 20 },
  browseBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  restaurantGroup: { marginHorizontal: 16, marginTop: 16 },
  restaurantHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  restaurantName: { fontSize: 16, fontWeight: '700', color: '#1a5c2e', marginLeft: 8 },
  cartItem: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 12, padding: 12, marginBottom: 8,
    shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 1,
  },
  cartItemInfo: { flex: 1 },
  cartItemName: { fontSize: 14, fontWeight: '600', color: '#333' },
  cartItemPrice: { fontSize: 13, color: '#2ECC71', fontWeight: '600', marginTop: 2 },
  cartItemActions: { flexDirection: 'row', alignItems: 'center' },
  qtyBtn: { width: 26, height: 26, borderRadius: 13, borderWidth: 1.5, borderColor: '#ddd', justifyContent: 'center', alignItems: 'center' },
  qtyText: { fontSize: 14, fontWeight: '700', marginHorizontal: 8 },
  removeBtn: { marginLeft: 10 },
  section: { marginHorizontal: 16, marginTop: 20 },
  sectionTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a1a', marginBottom: 12 },
  label: { fontSize: 13, fontWeight: '600', color: '#555', marginBottom: 4, marginTop: 10 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 10, paddingHorizontal: 12, borderWidth: 1, borderColor: '#e0e0e0',
  },
  input: { flex: 1, fontSize: 14, paddingVertical: 12, marginLeft: 8, color: '#333' },
  locationRow: { flexDirection: 'row', alignItems: 'center' },
  locationBtn: {
    width: 44, height: 44, borderRadius: 10, backgroundColor: '#2ECC71',
    justifyContent: 'center', alignItems: 'center', marginLeft: 8,
  },
  summary: {
    marginHorizontal: 16, marginTop: 20, backgroundColor: '#fff',
    borderRadius: 14, padding: 16,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  summaryTitle: { fontSize: 16, fontWeight: '700', color: '#1a1a1a', marginBottom: 12 },
  summaryRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 },
  summaryLabel: { fontSize: 14, color: '#666' },
  summaryValue: { fontSize: 14, fontWeight: '600', color: '#333' },
  totalRow: { borderTopWidth: 1, borderTopColor: '#eee', paddingTop: 10, marginTop: 4 },
  totalLabel: { fontSize: 17, fontWeight: '800', color: '#1a1a1a' },
  totalValue: { fontSize: 17, fontWeight: '800', color: '#2ECC71' },
  confirmBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#2ECC71', marginHorizontal: 16, marginTop: 20, marginBottom: 30,
    borderRadius: 14, padding: 16,
  },
  confirmBtnDisabled: { backgroundColor: '#aaa' },
  confirmBtnText: { color: '#fff', fontSize: 17, fontWeight: '700', marginLeft: 8 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'center', alignItems: 'center', padding: 30 },
  modalContent: { backgroundColor: '#fff', borderRadius: 20, padding: 30, alignItems: 'center', width: '100%' },
  successIcon: { marginBottom: 16 },
  successTitle: { fontSize: 24, fontWeight: '800', color: '#1a1a1a', marginBottom: 12 },
  successText: { fontSize: 15, color: '#666', textAlign: 'center', lineHeight: 22 },
  successBtn: { backgroundColor: '#2ECC71', borderRadius: 12, paddingHorizontal: 30, paddingVertical: 14, marginTop: 20, width: '100%', alignItems: 'center' },
  successBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  successBtnOutline: { borderWidth: 2, borderColor: '#2ECC71', borderRadius: 12, paddingHorizontal: 30, paddingVertical: 14, marginTop: 10, width: '100%', alignItems: 'center' },
  successBtnOutlineText: { color: '#2ECC71', fontSize: 16, fontWeight: '700' },
});
