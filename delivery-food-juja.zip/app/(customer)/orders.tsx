import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator, RefreshControl, Modal } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../lib/store';
import { supabase } from '../lib/supabase';

interface OrderItem {
  id: string;
  item_name: string;
  restaurant_name: string;
  price: number;
  quantity: number;
}

interface Order {
  id: string;
  status: string;
  total_amount: number;
  delivery_fee: number;
  phone: string;
  door_number: string;
  location_address: string;
  created_at: string;
  rider_name?: string;
  order_items: OrderItem[];
}

const statusColors: { [key: string]: string } = {
  pending: '#f39c12',
  processing: '#3498db',
  in_transit: '#9b59b6',
  completed: '#2ECC71',
  failed: '#e74c3c',
};

const statusLabels: { [key: string]: string } = {
  pending: 'Pending',
  processing: 'Processing',
  in_transit: 'In Transit',
  completed: 'Delivered',
  failed: 'Failed',
};

export default function OrdersScreen() {
  const { user } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [deliveredModal, setDeliveredModal] = useState<Order | null>(null);

  const fetchOrders = useCallback(async () => {
    try {
      const { data, error } = await supabase.functions.invoke('orders', {
        body: { action: 'get_customer_orders', customer_id: user?.id },
      });
      if (data?.orders) {
        // Check if any order just got completed
        const prevCompleted = orders.filter(o => o.status === 'completed').map(o => o.id);
        const newCompleted = data.orders.filter(
          (o: Order) => o.status === 'completed' && !prevCompleted.includes(o.id)
        );
        if (newCompleted.length > 0) {
          setDeliveredModal(newCompleted[0]);
        }
        setOrders(data.orders);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, orders]);

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 5000); // Poll every 5 seconds
    return () => clearInterval(interval);
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    fetchOrders();
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#2ECC71" />
        <Text style={styles.loadingText}>Loading orders...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Orders</Text>
        <Text style={styles.headerSub}>Track your order status</Text>
      </View>

      <FlatList
        data={orders}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor="#2ECC71" />}
        contentContainerStyle={{ padding: 16 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <TouchableOpacity style={styles.orderCard} onPress={() => setSelectedOrder(item)}>
            <View style={styles.orderHeader}>
              <Text style={styles.orderId}>Order #{item.id.slice(0, 8)}</Text>
              <View style={[styles.statusBadge, { backgroundColor: statusColors[item.status] + '20' }]}>
                <View style={[styles.statusDot, { backgroundColor: statusColors[item.status] }]} />
                <Text style={[styles.statusText, { color: statusColors[item.status] }]}>
                  {statusLabels[item.status]}
                </Text>
              </View>
            </View>
            <View style={styles.orderItems}>
              {item.order_items?.slice(0, 3).map((oi, idx) => (
                <Text key={idx} style={styles.orderItemText}>
                  {oi.quantity}x {oi.item_name} - {oi.restaurant_name}
                </Text>
              ))}
              {(item.order_items?.length || 0) > 3 && (
                <Text style={styles.moreItems}>+{(item.order_items?.length || 0) - 3} more items</Text>
              )}
            </View>
            <View style={styles.orderFooter}>
              <Text style={styles.orderTotal}>KSh {item.total_amount}</Text>
              <Text style={styles.orderDate}>{new Date(item.created_at).toLocaleDateString()}</Text>
            </View>
            {item.rider_name && (
              <View style={styles.riderInfo}>
                <Ionicons name="bicycle" size={14} color="#2ECC71" />
                <Text style={styles.riderText}>Rider: {item.rider_name}</Text>
              </View>
            )}
          </TouchableOpacity>
        )}
        keyExtractor={(item) => item.id}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="receipt-outline" size={64} color="#ccc" />
            <Text style={styles.emptyTitle}>No orders yet</Text>
            <Text style={styles.emptyText}>Your orders will appear here</Text>
          </View>
        }
      />

      {/* Order Detail Modal */}
      <Modal visible={!!selectedOrder} transparent animationType="slide">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Order Details</Text>
              <TouchableOpacity onPress={() => setSelectedOrder(null)}>
                <Ionicons name="close" size={24} color="#333" />
              </TouchableOpacity>
            </View>
            {selectedOrder && (
              <>
                <View style={[styles.statusBadgeLarge, { backgroundColor: statusColors[selectedOrder.status] + '20' }]}>
                  <Ionicons
                    name={selectedOrder.status === 'completed' ? 'checkmark-circle' : selectedOrder.status === 'in_transit' ? 'bicycle' : 'time'}
                    size={24}
                    color={statusColors[selectedOrder.status]}
                  />
                  <Text style={[styles.statusTextLarge, { color: statusColors[selectedOrder.status] }]}>
                    {statusLabels[selectedOrder.status]}
                  </Text>
                </View>
                <Text style={styles.detailLabel}>Items:</Text>
                {selectedOrder.order_items?.map((oi, idx) => (
                  <View key={idx} style={styles.detailItem}>
                    <Text style={styles.detailItemName}>{oi.quantity}x {oi.item_name}</Text>
                    <Text style={styles.detailItemRestaurant}>{oi.restaurant_name}</Text>
                    <Text style={styles.detailItemPrice}>KSh {oi.price * oi.quantity}</Text>
                  </View>
                ))}
                <View style={styles.detailSummary}>
                  <View style={styles.detailRow}><Text>Delivery Fee</Text><Text>KSh {selectedOrder.delivery_fee}</Text></View>
                  <View style={[styles.detailRow, { borderTopWidth: 1, borderTopColor: '#eee', paddingTop: 8 }]}>
                    <Text style={{ fontWeight: '800', fontSize: 16 }}>Total</Text>
                    <Text style={{ fontWeight: '800', fontSize: 16, color: '#2ECC71' }}>KSh {selectedOrder.total_amount}</Text>
                  </View>
                </View>
                {selectedOrder.rider_name && (
                  <View style={styles.riderDetail}>
                    <Ionicons name="bicycle" size={18} color="#2ECC71" />
                    <Text style={styles.riderDetailText}>Rider: {selectedOrder.rider_name}</Text>
                  </View>
                )}
              </>
            )}
          </View>
        </View>
      </Modal>

      {/* Delivered Popup */}
      <Modal visible={!!deliveredModal} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.deliveredContent}>
            <Ionicons name="checkmark-circle" size={72} color="#2ECC71" />
            <Text style={styles.deliveredTitle}>Order Delivered!</Text>
            <Text style={styles.deliveredText}>
              Your order has been delivered by{' '}
              <Text style={{ fontWeight: '800' }}>{deliveredModal?.rider_name || 'your rider'}</Text>.
              {'\n\n'}Thank you for shopping with us!
            </Text>
            <TouchableOpacity style={styles.deliveredBtn} onPress={() => setDeliveredModal(null)}>
              <Text style={styles.deliveredBtnText}>Great!</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#888', marginTop: 12 },
  header: {
    backgroundColor: '#2ECC71', paddingTop: 55, paddingBottom: 16, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800' },
  headerSub: { color: '#c8f7dc', fontSize: 13, marginTop: 2 },
  orderCard: {
    backgroundColor: '#fff', borderRadius: 14, padding: 16, marginBottom: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  orderId: { fontSize: 14, fontWeight: '700', color: '#333' },
  statusBadge: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 10, paddingVertical: 4, borderRadius: 12 },
  statusDot: { width: 8, height: 8, borderRadius: 4, marginRight: 6 },
  statusText: { fontSize: 12, fontWeight: '700' },
  orderItems: { marginBottom: 10 },
  orderItemText: { fontSize: 13, color: '#555', marginBottom: 2 },
  moreItems: { fontSize: 12, color: '#999', fontStyle: 'italic' },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  orderTotal: { fontSize: 16, fontWeight: '800', color: '#2ECC71' },
  orderDate: { fontSize: 12, color: '#999' },
  riderInfo: { flexDirection: 'row', alignItems: 'center', marginTop: 8, backgroundColor: '#e8f5e9', padding: 8, borderRadius: 8 },
  riderText: { fontSize: 13, color: '#1a5c2e', fontWeight: '600', marginLeft: 6 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#333', marginTop: 16 },
  emptyText: { fontSize: 14, color: '#888', marginTop: 4 },
  modalOverlay: { flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end' },
  modalContent: { backgroundColor: '#fff', borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: '80%' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  modalTitle: { fontSize: 20, fontWeight: '800', color: '#1a1a1a' },
  statusBadgeLarge: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', padding: 12, borderRadius: 12, marginBottom: 16 },
  statusTextLarge: { fontSize: 16, fontWeight: '700', marginLeft: 8 },
  detailLabel: { fontSize: 14, fontWeight: '700', color: '#333', marginBottom: 8 },
  detailItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: '#f0f0f0' },
  detailItemName: { flex: 1, fontSize: 14, color: '#333' },
  detailItemRestaurant: { fontSize: 12, color: '#888', marginRight: 8 },
  detailItemPrice: { fontSize: 14, fontWeight: '700', color: '#2ECC71' },
  detailSummary: { marginTop: 12 },
  detailRow: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 6 },
  riderDetail: { flexDirection: 'row', alignItems: 'center', marginTop: 12, backgroundColor: '#e8f5e9', padding: 12, borderRadius: 10 },
  riderDetailText: { fontSize: 14, fontWeight: '600', color: '#1a5c2e', marginLeft: 8 },
  deliveredContent: { backgroundColor: '#fff', borderRadius: 20, padding: 30, alignItems: 'center', margin: 30, marginTop: 'auto', marginBottom: 'auto' },
  deliveredTitle: { fontSize: 24, fontWeight: '800', color: '#1a1a1a', marginTop: 16 },
  deliveredText: { fontSize: 15, color: '#666', textAlign: 'center', marginTop: 12, lineHeight: 22 },
  deliveredBtn: { backgroundColor: '#2ECC71', borderRadius: 12, paddingHorizontal: 40, paddingVertical: 14, marginTop: 20 },
  deliveredBtnText: { color: '#fff', fontSize: 16, fontWeight: '700' },
});
