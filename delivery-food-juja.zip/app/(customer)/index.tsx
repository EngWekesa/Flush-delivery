import React, { useRef, useEffect, useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, ScrollView, Animated, Dimensions, FlatList } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../lib/store';
import { IMAGES } from '../lib/images';
import { RESTAURANTS } from '../lib/restaurants';

const { width } = Dimensions.get('window');

const marqueeItems = [
  { name: 'KINGS & QUEENS', img: IMAGES.restaurants[0] },
  { name: 'MORIAH CHICKEN GRILL', img: IMAGES.restaurants[1] },
  { name: 'HONEY BEE HOTEL', img: IMAGES.restaurants[2] },
  { name: 'JUNK JOINT', img: IMAGES.restaurants[3] },
  { name: 'SCOOPS & SPOONS', img: IMAGES.restaurants[4] },
  { name: 'SFC RESTAURANT', img: IMAGES.restaurants[5] },
];

const popularFoods = [
  { name: 'Chips + Chicken 1/4', price: 330, restaurant: 'KINGS & QUEENS', img: IMAGES.foods[0] },
  { name: 'Chicken Biriani', price: 480, restaurant: 'SCOOPS & SPOONS', img: IMAGES.foods[1] },
  { name: 'Pepperoni Pizza', price: 530, restaurant: 'JUNK JOINT', img: IMAGES.foods[2] },
  { name: 'Shawarma', price: 260, restaurant: 'HONEY BEE HOTEL', img: IMAGES.foods[3] },
  { name: 'Pilau + Dish', price: 320, restaurant: 'MORIAH CHICKEN GRILL', img: IMAGES.foods[4] },
  { name: 'Loaded Fries', price: 360, restaurant: 'QUEENS FRIES', img: IMAGES.foods[5] },
];

const featuredRestaurants = RESTAURANTS.slice(0, 3);

export default function CustomerDashboard() {
  const router = useRouter();
  const { user, cart } = useStore();
  const scrollRef = useRef<ScrollView>(null);
  const [marqueeOffset, setMarqueeOffset] = useState(0);

  useEffect(() => {
    const interval = setInterval(() => {
      setMarqueeOffset(prev => {
        const next = prev + 160;
        if (next >= marqueeItems.length * 160) return 0;
        return next;
      });
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    scrollRef.current?.scrollTo({ x: marqueeOffset, animated: true });
  }, [marqueeOffset]);

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Welcome back,</Text>
          <Text style={styles.userName}>{user?.name || 'Customer'}</Text>
        </View>
        <TouchableOpacity style={styles.cartBtn} onPress={() => router.push('/(customer)/cart')}>
          <Ionicons name="cart" size={24} color="#fff" />
          {cart.length > 0 && (
            <View style={styles.cartBadge}>
              <Text style={styles.cartBadgeText}>{cart.length}</Text>
            </View>
          )}
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 30 }}>
        {/* Contact Banner */}
        <View style={styles.contactBanner}>
          <Image source={{ uri: IMAGES.logo }} style={styles.contactLogo} />
          <View style={{ flex: 1, marginLeft: 12 }}>
            <Text style={styles.contactTitle}>FLUSH DELIVERY</Text>
            <Text style={styles.contactSub}>For queries call</Text>
          </View>
          <TouchableOpacity style={styles.phoneBtn}>
            <Ionicons name="call" size={16} color="#fff" />
            <Text style={styles.phoneBtnText}>0708770746</Text>
          </TouchableOpacity>
        </View>

        {/* Marquee - Popular Restaurants */}
        <Text style={styles.sectionTitle}>Popular Restaurants</Text>
        <ScrollView
          ref={scrollRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.marquee}
          contentContainerStyle={{ paddingHorizontal: 16 }}
        >
          {marqueeItems.map((item, i) => (
            <TouchableOpacity
              key={i}
              style={styles.marqueeCard}
              onPress={() => router.push(`/restaurant/${i + 1}`)}
            >
              <Image source={{ uri: item.img }} style={styles.marqueeImg} />
              <Text style={styles.marqueeName} numberOfLines={1}>{item.name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Popular Foods */}
        <Text style={styles.sectionTitle}>Popular Foods</Text>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 16 }}>
          {popularFoods.map((food, i) => (
            <View key={i} style={styles.foodCard}>
              <Image source={{ uri: food.img }} style={styles.foodImg} />
              <Text style={styles.foodName} numberOfLines={1}>{food.name}</Text>
              <Text style={styles.foodRestaurant} numberOfLines={1}>{food.restaurant}</Text>
              <Text style={styles.foodPrice}>KSh {food.price}</Text>
            </View>
          ))}
        </ScrollView>

        {/* Featured Restaurants */}
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Featured Restaurants</Text>
        </View>
        {featuredRestaurants.map((r) => (
          <TouchableOpacity
            key={r.id}
            style={styles.restaurantCard}
            onPress={() => router.push(`/restaurant/${r.id}`)}
          >
            <Image source={{ uri: IMAGES.restaurants[r.image] }} style={styles.restaurantImg} />
            <View style={styles.restaurantInfo}>
              <Text style={styles.restaurantName}>{r.name}</Text>
              <Text style={styles.restaurantCategory}>{r.category}</Text>
              <View style={styles.ratingRow}>
                <Ionicons name="star" size={14} color="#f1c40f" />
                <Text style={styles.ratingText}>{r.rating}</Text>
                <Text style={styles.menuCount}>{r.menu.length} items</Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}

        <TouchableOpacity
          style={styles.viewAllBtn}
          onPress={() => router.push('/(customer)/restaurants')}
        >
          <Text style={styles.viewAllText}>View All Restaurants</Text>
          <Ionicons name="arrow-forward" size={20} color="#fff" />
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    backgroundColor: '#2ECC71', paddingTop: 55, paddingBottom: 20, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  greeting: { color: '#c8f7dc', fontSize: 14 },
  userName: { color: '#fff', fontSize: 22, fontWeight: '800' },
  cartBtn: { width: 48, height: 48, borderRadius: 24, backgroundColor: 'rgba(255,255,255,0.25)', justifyContent: 'center', alignItems: 'center' },
  cartBadge: { position: 'absolute', top: -2, right: -2, backgroundColor: '#e74c3c', borderRadius: 10, width: 20, height: 20, justifyContent: 'center', alignItems: 'center' },
  cartBadgeText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  contactBanner: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#e8f5e9',
    margin: 16, padding: 14, borderRadius: 14,
  },
  contactLogo: { width: 44, height: 44, borderRadius: 22 },
  contactTitle: { fontSize: 14, fontWeight: '800', color: '#1a5c2e' },
  contactSub: { fontSize: 12, color: '#666' },
  phoneBtn: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#2ECC71', borderRadius: 20, paddingHorizontal: 12, paddingVertical: 8 },
  phoneBtnText: { color: '#fff', fontSize: 12, fontWeight: '700', marginLeft: 4 },
  sectionTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a1a', marginLeft: 16, marginTop: 20, marginBottom: 12 },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingRight: 16 },
  marquee: { marginBottom: 8 },
  marqueeCard: { width: 140, marginRight: 12, borderRadius: 12, overflow: 'hidden', backgroundColor: '#fff', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3 },
  marqueeImg: { width: 140, height: 90 },
  marqueeName: { fontSize: 12, fontWeight: '700', color: '#333', padding: 8 },
  foodCard: { width: 140, marginRight: 12, borderRadius: 12, overflow: 'hidden', backgroundColor: '#fff', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3 },
  foodImg: { width: 140, height: 100 },
  foodName: { fontSize: 13, fontWeight: '700', color: '#333', paddingHorizontal: 8, paddingTop: 8 },
  foodRestaurant: { fontSize: 11, color: '#888', paddingHorizontal: 8 },
  foodPrice: { fontSize: 14, fontWeight: '800', color: '#2ECC71', paddingHorizontal: 8, paddingBottom: 8, paddingTop: 2 },
  restaurantCard: {
    flexDirection: 'row', backgroundColor: '#fff', marginHorizontal: 16, marginBottom: 12,
    borderRadius: 14, overflow: 'hidden',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  restaurantImg: { width: 110, height: 100 },
  restaurantInfo: { flex: 1, padding: 12, justifyContent: 'center' },
  restaurantName: { fontSize: 16, fontWeight: '700', color: '#1a1a1a' },
  restaurantCategory: { fontSize: 12, color: '#888', marginTop: 2 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  ratingText: { fontSize: 13, fontWeight: '700', color: '#333', marginLeft: 4 },
  menuCount: { fontSize: 12, color: '#999', marginLeft: 12 },
  viewAllBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#2ECC71', marginHorizontal: 16, marginTop: 8,
    borderRadius: 14, padding: 16,
  },
  viewAllText: { color: '#fff', fontSize: 16, fontWeight: '700', marginRight: 8 },
});
