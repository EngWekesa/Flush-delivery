import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Image, FlatList, TextInput, Alert } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { IMAGES } from '../lib/images';
import { RESTAURANTS } from '../lib/restaurants';
import { useStore } from '../lib/store';

export default function RestaurantDetail() {
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id: string }>();
  const { addToCart, cart } = useStore();
  const [search, setSearch] = useState('');
  const [quantities, setQuantities] = useState<{ [key: string]: number }>({});

  const restaurant = RESTAURANTS.find(r => r.id === parseInt(id || '1'));
  if (!restaurant) return <View style={styles.container}><Text>Restaurant not found</Text></View>;

  const filteredMenu = restaurant.menu.filter(item =>
    item.name.toLowerCase().includes(search.toLowerCase())
  );

  const getQty = (name: string) => quantities[name] || 1;
  const setQty = (name: string, qty: number) => {
    if (qty < 1) qty = 1;
    setQuantities(prev => ({ ...prev, [name]: qty }));
  };

  const handleAddToCart = (itemName: string, price: number) => {
    const qty = getQty(itemName);
    addToCart({
      restaurant_name: restaurant.name,
      item_name: itemName,
      price,
      quantity: qty,
    });
    Alert.alert('Added to Cart', `${qty}x ${itemName} from ${restaurant.name} added to cart!`);
    setQuantities(prev => ({ ...prev, [itemName]: 1 }));
  };

  const cartTotal = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <View style={styles.container}>
      {/* Header */}
      <View style={styles.headerWrap}>
        <Image source={{ uri: IMAGES.restaurants[restaurant.image] }} style={styles.headerImg} />
        <View style={styles.headerOverlay} />
        <View style={styles.headerContent}>
          <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={24} color="#fff" />
          </TouchableOpacity>
          <View style={styles.headerInfo}>
            <Text style={styles.restaurantName}>{restaurant.name}</Text>
            <Text style={styles.restaurantCategory}>{restaurant.category}</Text>
            <View style={styles.ratingRow}>
              <Ionicons name="star" size={16} color="#f1c40f" />
              <Text style={styles.ratingText}>{restaurant.rating}</Text>
              <Text style={styles.menuCount}>{restaurant.menu.length} items available</Text>
            </View>
          </View>
        </View>
      </View>

      {/* Search */}
      <View style={styles.searchWrap}>
        <Ionicons name="search" size={18} color="#999" />
        <TextInput
          style={styles.searchInput}
          placeholder="Search menu items..."
          value={search}
          onChangeText={setSearch}
        />
        {search.length > 0 && (
          <TouchableOpacity onPress={() => setSearch('')}>
            <Ionicons name="close-circle" size={18} color="#999" />
          </TouchableOpacity>
        )}
      </View>

      {/* Menu */}
      <FlatList
        data={filteredMenu}
        contentContainerStyle={{ paddingHorizontal: 16, paddingBottom: 100 }}
        showsVerticalScrollIndicator={false}
        renderItem={({ item, index }) => (
          <View style={styles.menuItem}>
            <Image
              source={{ uri: IMAGES.foods[index % IMAGES.foods.length] }}
              style={styles.menuItemImg}
            />
            <View style={styles.menuItemInfo}>
              <Text style={styles.menuItemName} numberOfLines={2}>{item.name}</Text>
              <Text style={styles.menuItemPrice}>KSh {item.price}</Text>
              <View style={styles.qtyRow}>
                <TouchableOpacity
                  style={styles.qtyBtn}
                  onPress={() => setQty(item.name, getQty(item.name) - 1)}
                >
                  <Ionicons name="remove" size={16} color="#2ECC71" />
                </TouchableOpacity>
                <Text style={styles.qtyText}>{getQty(item.name)}</Text>
                <TouchableOpacity
                  style={styles.qtyBtn}
                  onPress={() => setQty(item.name, getQty(item.name) + 1)}
                >
                  <Ionicons name="add" size={16} color="#2ECC71" />
                </TouchableOpacity>
                <TouchableOpacity
                  style={styles.addBtn}
                  onPress={() => handleAddToCart(item.name, item.price)}
                >
                  <Ionicons name="cart-outline" size={14} color="#fff" />
                  <Text style={styles.addBtnText}>Add</Text>
                </TouchableOpacity>
              </View>
            </View>
          </View>
        )}
        keyExtractor={(item, index) => `${item.name}-${index}`}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons name="search" size={40} color="#ccc" />
            <Text style={styles.emptyText}>No items found</Text>
          </View>
        }
      />

      {/* Cart Floating Button */}
      {cartTotal > 0 && (
        <TouchableOpacity
          style={styles.floatingCart}
          onPress={() => router.push('/(customer)/cart')}
        >
          <Ionicons name="cart" size={22} color="#fff" />
          <Text style={styles.floatingCartText}>Checkout Your Cart ({cartTotal} items)</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  headerWrap: { height: 200, position: 'relative' },
  headerImg: { width: '100%', height: 200 },
  headerOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.45)' },
  headerContent: { ...StyleSheet.absoluteFillObject, padding: 16, paddingTop: 50, justifyContent: 'space-between' },
  backBtn: { width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(255,255,255,0.25)', justifyContent: 'center', alignItems: 'center' },
  headerInfo: {},
  restaurantName: { color: '#fff', fontSize: 24, fontWeight: '800' },
  restaurantCategory: { color: '#ddd', fontSize: 14, marginTop: 2 },
  ratingRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  ratingText: { color: '#fff', fontSize: 14, fontWeight: '700', marginLeft: 4 },
  menuCount: { color: '#ccc', fontSize: 12, marginLeft: 12 },
  searchWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    marginHorizontal: 16, marginTop: 12, marginBottom: 8, borderRadius: 12,
    paddingHorizontal: 12, borderWidth: 1, borderColor: '#e0e0e0',
  },
  searchInput: { flex: 1, fontSize: 14, paddingVertical: 10, marginLeft: 8, color: '#333' },
  menuItem: {
    flexDirection: 'row', backgroundColor: '#fff', borderRadius: 12, marginBottom: 10,
    overflow: 'hidden', shadowColor: '#000', shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2,
  },
  menuItemImg: { width: 80, height: 90 },
  menuItemInfo: { flex: 1, padding: 10 },
  menuItemName: { fontSize: 14, fontWeight: '600', color: '#333' },
  menuItemPrice: { fontSize: 15, fontWeight: '800', color: '#2ECC71', marginTop: 2 },
  qtyRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
  qtyBtn: {
    width: 28, height: 28, borderRadius: 14, borderWidth: 1.5, borderColor: '#2ECC71',
    justifyContent: 'center', alignItems: 'center',
  },
  qtyText: { fontSize: 14, fontWeight: '700', color: '#333', marginHorizontal: 10 },
  addBtn: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#2ECC71',
    borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6, marginLeft: 'auto',
  },
  addBtnText: { color: '#fff', fontSize: 13, fontWeight: '700', marginLeft: 4 },
  empty: { alignItems: 'center', marginTop: 40 },
  emptyText: { fontSize: 14, color: '#999', marginTop: 8 },
  floatingCart: {
    position: 'absolute', bottom: 20, left: 16, right: 16,
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#2ECC71', borderRadius: 16, padding: 16,
    shadowColor: '#000', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.2, shadowRadius: 8, elevation: 6,
  },
  floatingCartText: { color: '#fff', fontSize: 16, fontWeight: '700', marginLeft: 8 },
});
