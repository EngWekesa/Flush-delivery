export interface MenuItem {
  name: string;
  price: number;
}

export interface Restaurant {
  id: number;
  name: string;
  rating: number;
  category: string;
  image: number;
  menu: MenuItem[];
}

export const RESTAURANTS: Restaurant[] = [
  {
    id: 1, name: 'KINGS & QUEENS', rating: 4.8, category: 'African Cuisine', image: 0,
    menu: [
      {name:'Samosa waru',price:10},{name:'Rice njahi + Dish',price:180},{name:'Chapo beans+Beef + Dish',price:330},{name:'Chips+chicken 1/4',price:330},{name:'1/4 chicken wet fry + dish',price:210},{name:'Nduma',price:55},{name:'Chapo kamande beef + dish',price:350},{name:'Pilau ndengu + dish',price:205},{name:'Plain liver + dish',price:230},{name:'French toast',price:85},{name:'Omelette',price:85},{name:'Matoke + dish',price:240},{name:'Chapo + greens + dish',price:90},{name:'Chapo + cabbage + dish',price:90},{name:'Rice beans + dish',price:150},{name:'1/4 chicken wet fry ugali + dish',price:290},{name:'Mukimo beef + dish',price:340},{name:'Ugali ndengu + dish',price:130},{name:'Chicken wet fry',price:860},{name:'Bhajia',price:140},{name:'Matumbo rice + dish',price:185},{name:'2 scrambled eggs',price:80},{name:'Ugali beef + dish',price:310},{name:'Liver rice + dish',price:340},{name:'Pilau plain + dish',price:210},{name:'Kebab',price:70},{name:'Chapo kamande',price:160},{name:'Maryland chicken piece',price:100},{name:'1/4 chicken deep fry ugali + dish',price:270},{name:'Matumbo chapati',price:170},{name:'Rice Minji beef + dish',price:390},{name:'Sausages',price:50},{name:'Pilau njahi + dish',price:135},{name:'Ugali kamande + dish',price:180},{name:'Beef plain wet fry + dish',price:270},{name:'Sweet potatoes',price:50},{name:'Chapati',price:20},{name:'Chapati njahi + dish',price:170},{name:'Chapati Minji + dish',price:170},{name:'Ugali greens',price:100},{name:'Ugali cabbage',price:100},{name:'Boiled egg',price:30},{name:'Ndengu plain',price:80},{name:'Rice kamande beef + dish',price:410},{name:'Smokie',price:35},{name:'1/4 chicken wet fry rice + dish',price:340},{name:'Pilau beans + dish',price:125},{name:'Soda 1L',price:120},{name:'Soda 2L',price:200},{name:'Soda 1.25L',price:140},{name:'Rice plain + dish',price:130},{name:'Beef plain dry fry + dish',price:270},{name:'Chapo ndengu beef + dish',price:350},{name:'Predator',price:70},{name:'Pilau Minji + dish',price:235},{name:'1/4 chicken deep fry',price:190},{name:'Rice Minji + dish',price:180},{name:'Matumbo + dish',price:125},{name:'Rice ndengu + dish',price:155},{name:'Ugali matumbo + dish',price:175},{name:'Chapo ndengu + dish',price:125},{name:'Mukimo + dish',price:130},{name:'Beans plain + dish',price:80},{name:'Chips masala',price:170},{name:'Liver pilau + dish',price:370},{name:'Samosa beef',price:390},{name:'Pilau beef + dish',price:390},{name:'Pilau Minji beef + dish',price:430},{name:'Ugali plain',price:55},{name:'Chapo beef + dish',price:310},{name:'Minji plain + dish',price:125},{name:'Chapo Minji beef + dish',price:350},{name:'Rice kamande + dish',price:180},{name:'Rice beef + dish',price:340},{name:'Pilau mix',price:250},{name:'Chips plain',price:125},{name:'Chicken deep fry rice + dish',price:300},{name:'Chips beef mix',price:370},{name:'Beef Minji + dish',price:340},{name:'Kamande plain + dish',price:120}
    ]
  },
  {
    id: 2, name: 'MORIAH CHICKEN GRILL', rating: 4.7, category: 'Chicken & Grill', image: 1,
    menu: [
      {name:'Beef burger',price:185},{name:'2 fried eggs',price:90},{name:'Kebab',price:125},{name:'Ugali chicken stew + dish',price:580},{name:'1/4 chicken',price:210},{name:'Spanish omelette',price:100},{name:'1/2 chicken',price:430},{name:'Andazi',price:30},{name:'Meat pie',price:115},{name:'Full chicken',price:870},{name:'Pilau + chicken stew',price:590},{name:'Fish fillet',price:410},{name:'Toast mayai',price:80},{name:'Chicken wings',price:320},{name:'Bhajia',price:210},{name:'Chips',price:155},{name:'Pancakes',price:100},{name:'Chapati',price:40},{name:'Rice + chicken stew + dish',price:580},{name:'Beef chapo',price:460},{name:'Pilau',price:320},{name:'Rice beef stew',price:480},{name:'Chips masala',price:210},{name:'Chicken burger',price:180},{name:'Rice chicken stew',price:560},{name:'Plain omelette',price:85},{name:'Pilau beef stew',price:530},{name:'Smokie',price:40},{name:'Soda 500ml',price:100},{name:'Chapo(2) chicken stew',price:510},{name:'Hot dog',price:100},{name:'Samosa',price:60},{name:'Ugali beef stew',price:480},{name:'Bacon',price:320},{name:'Sausage',price:60},{name:'Chips beef',price:430},{name:'Chicken pie',price:140}
    ]
  },
  {
    id: 3, name: 'HONEY BEE HOTEL', rating: 4.6, category: 'Hotel & Restaurant', image: 2,
    menu: [
      {name:'Nduma',price:75},{name:'Toasted toast',price:80},{name:'Andazi',price:20},{name:'Fry chicken spaghetti',price:540},{name:'Vanilla shake',price:180},{name:'Sausage',price:50},{name:'Orange juice',price:210},{name:'Njahi stew',price:180},{name:'Milk',price:85},{name:'Biriani chicken + dish',price:490},{name:'Family platter',price:1990},{name:'Arosto 1/4',price:470},{name:'Biriani gizzard + dish',price:280},{name:'English breakfast',price:300},{name:'Chocolate shake',price:190},{name:'Mango juice',price:130},{name:'Minji stew + dish',price:170},{name:'Beef dry + dish',price:260},{name:'Chicken kienyeji + dish',price:320},{name:'Chicken masala 1/2 + dish',price:490},{name:'Grilled chicken',price:280},{name:'Chips masala',price:180},{name:'Chicken curry + dish',price:450},{name:'Omelette',price:65},{name:'Shawarma',price:260},{name:'Rolex chapati and eggs',price:105},{name:'Pilau + dish',price:210},{name:'Chicken wetfry + dish',price:250},{name:'Rice + dish',price:120},{name:'Boiled eggs',price:30},{name:'Biriani',price:230},{name:'Pancakes',price:100},{name:'Platter for 2',price:1290},{name:'Strawberry shake',price:180},{name:'Chips',price:130},{name:'Chicken loaded fries',price:340},{name:'Coconut rice',price:210},{name:'Chicken kienyeji dry fry',price:320},{name:'Chapati',price:30},{name:'Melon juice',price:100},{name:'Mango shake',price:180},{name:'Samosa',price:50},{name:'Mukimo + dish',price:125},{name:'Tilapia wet fry large',price:730},{name:'Spinach omelette',price:105},{name:'Tumeric rice + dish',price:210},{name:'Ugali plain',price:50},{name:'Coconut fish + dish',price:720},{name:'Liver + dish',price:390},{name:'Beef wet fry + dish',price:250},{name:'Allesto',price:430},{name:'Chicken kienyeji wet fry',price:260},{name:'Spaghetti + dish',price:180},{name:'Passion juice',price:150},{name:'Chicken dry fry + dish',price:250},{name:'Fish masala large',price:780},{name:'Scrambled eggs',price:120},{name:'Fish finger + dish',price:400},{name:'Pineapple juice',price:130}
    ]
  },
  {
    id: 4, name: 'JUNK JOINT', rating: 4.5, category: 'Fast Food & Pizza', image: 3,
    menu: [
      {name:'Chips masala',price:130},{name:'Fried vegetable rice mix',price:210},{name:'Pepperoni pizza',price:530},{name:'Shawarma normal',price:150},{name:'Biriani pizza',price:530},{name:'Loaded fries with cheese',price:260},{name:'Loaded fries normal',price:155},{name:'Loaded fries large',price:210},{name:'Noodle special',price:320},{name:'Pilau loaded mix',price:210},{name:'Pilau plain + dish',price:210},{name:'Chicken burger big',price:210},{name:'Chips masala loaded',price:210},{name:'Chips plain',price:105},{name:'Burritos normal',price:200},{name:'Pilau mix loaded with cheese',price:260},{name:'Smokie',price:50},{name:'Burrito large',price:200},{name:'Supreme pizza',price:530},{name:'Chicken pizza',price:530},{name:'Shawarma with cheese',price:260},{name:'Chips masala with cheese',price:260},{name:'Rice veges plain',price:210},{name:'Hawaiian pizza normal',price:530},{name:'Pilau mix',price:210},{name:'Chicken burger small',price:160},{name:'Shawarma large',price:210},{name:'Chicken burger with cheese',price:260},{name:'Chips masala loaded',price:210},{name:'Fried vegetable loaded rice',price:260}
    ]
  },
  {
    id: 5, name: 'SUPERMARKET', rating: 4.3, category: 'Groceries & Supplies', image: 4,
    menu: [
      {name:'Snickers twin pack 80g',price:260},{name:'Delamere vanilla yoghurt',price:180},{name:'Stoney zero 500ml',price:75},{name:'Dairyland salted caramel chocolate',price:260},{name:'KCC vanilla yoghurt 500ml',price:100},{name:'Noodles chicken flavor 120g',price:40},{name:'Exe all purpose flour 2kg',price:185},{name:'Sunlight lavender 3.5kg',price:1200},{name:'Pick n peel mango juice 250ml',price:80},{name:'Tiara serviettes',price:120},{name:'Fresh strawberry yoghurt 500ml',price:110},{name:'Golden family tea biscuit 200g',price:110},{name:'Dove bar soap 135g',price:330},{name:'Delmonte mixed berry 250ml',price:75},{name:'Brookside coffee 250ml 6pack',price:420},{name:'Vaseline dry skin lotion 100ml',price:185},{name:'Cadbury dairy milk bubbly 87g',price:300},{name:'Ilara vanilla yoghurt 500ml',price:130},{name:'Vaseline men body lotion 400ml',price:570},{name:'Excel cocopine juice 2L',price:360},{name:'Peptang peanut butter 250g',price:240},{name:'Brookside milk 1L',price:220},{name:'Tropical heat crisps tomato 200g',price:210},{name:'Cadbury cocoa 200g',price:500},{name:'Rina vegetable oil 5L',price:1150},{name:'Soko maize flour 10kg',price:800},{name:'Elianto corn oil 500ml',price:360},{name:'Dasani 500ml',price:70},{name:'Colgate triple action 140g',price:200},{name:'Supa loaf bread 600g',price:100},{name:'Nescafe classic jar 100g',price:800},{name:'Fanta orange 500ml',price:80},{name:'Coca Cola 1.25L',price:130},{name:'Sprite 1.25L',price:130},{name:'Red Bull 250ml',price:230},{name:'Nutella 750g',price:2080},{name:'Blue band margarine 100g',price:65},{name:'Ariel detergent 2kg',price:940},{name:'Soko maize meal 5kg',price:400},{name:'Kensalt table salt 1kg',price:50}
    ]
  },
  {
    id: 6, name: 'FLUSH LIQUOR', rating: 4.4, category: 'Wines & Spirits', image: 5,
    menu: [
      {name:'Jameson Irish Whiskey 1L',price:2900},{name:'Balozi Beer',price:190},{name:'Crazy Cock Whisky 750ml',price:750},{name:'Gordon Lemon 1L',price:2500},{name:'Balozi Lager 500ml',price:170},{name:'Namaqua Sweet Red 5L',price:4000},{name:'Jack Daniel Fire 700ml',price:3900},{name:'Johnnie Walker Red Label 1L',price:2200},{name:'Cellar Cask Red Wine 750ml',price:900},{name:'8pm 750ml whiskey',price:850},{name:'Hunters Choice Whiskey 750ml',price:800},{name:'4th Street Sweet Red 750ml',price:850},{name:'Baileys Strawberry',price:1800},{name:'Bacardi Negra 3/4',price:1900},{name:'Black and White 750ml',price:1000},{name:'Chivas 12yrs 750ml',price:4500},{name:'Camino Gold Tequila 750ml',price:2200},{name:'Grants 750ml',price:1550},{name:'Guarana 440ml',price:220},{name:'Amarula 1L',price:2600},{name:'John Walker White 1L',price:6500},{name:'#7 Gin Passion 750ml',price:1300},{name:'Breezer Pineapple',price:250},{name:'8PM 1L',price:1500},{name:'Monster',price:200},{name:'Arcadia Rum 750ml',price:900},{name:'Heineken Can 500ml',price:350},{name:'Konyagi 750ml',price:600},{name:'Jagermeister 1L',price:2800},{name:'Cellar Cask White 750ml',price:850},{name:'Kenya Cane Coconut 750ml',price:700},{name:'Tanqueray Dry Gin 750ml',price:2500},{name:'Allsops Beer',price:200},{name:'Captain Morgan Gold Rum 750ml',price:900},{name:'Caprice Sweet Red Wine',price:700},{name:'All Seasons 750ml',price:850},{name:'8PM Fire 750ml',price:1300},{name:'Blue Moon 750ml',price:600},{name:'White Cap Lager Can 500ml',price:200},{name:'Flirt Vodka 750ml',price:1400},{name:'Baileys Delight 750ml',price:1700},{name:'Gordons Dry Gin 750ml',price:1600},{name:'Gordons Pink Gin 700ml',price:1600},{name:'Glenfiddich 12yr 1L',price:4500},{name:'Amarula Cream 750ml',price:2000},{name:'Gilbeys Gin 750ml',price:1200},{name:'Martel VS 750ml',price:5500},{name:'Tusker Malt Can 500ml',price:220},{name:'Martel Blue Swift 700ml',price:10000},{name:'Kentucky Bucket',price:2100}
    ]
  },
  {
    id: 7, name: 'BUTCHERY', rating: 4.5, category: 'Fresh Meat', image: 0,
    menu: [
      {name:'Pork 1kg',price:690},{name:'Mbuzi 1/4kg',price:220},{name:'Fresh meat 1kg',price:680},{name:'Fresh meat 1/2kg',price:340},{name:'Fresh meat 1/4kg',price:190},{name:'Mbuzi 1kg',price:840},{name:'Pork 1/2kg',price:340},{name:'Minced meat 1/4kg',price:220},{name:'Pork 1/4kg',price:190},{name:'Mbuzi 1/2kg',price:440}
    ]
  },
  {
    id: 8, name: 'MAMA MBOGA', rating: 4.2, category: 'Fresh Produce', image: 1,
    menu: [
      {name:'Apple mango (small)',price:20},{name:'Mango medium',price:25},{name:'Bell pepper (big)',price:20},{name:'Lemon green',price:15},{name:'Tangerine big',price:20},{name:'Oranges small',price:10},{name:'Bell pepper (medium)',price:15},{name:'Spinach',price:25},{name:'Tomato 1',price:10},{name:'Yellow passion',price:15},{name:'Pineapple',price:150},{name:'Pineapple large',price:180},{name:'Cabbage',price:30},{name:'Ndengu (cooked)',price:40},{name:'French beans',price:35},{name:'Passion',price:15},{name:'Lentils/kamande (cooked)',price:60},{name:'Banana',price:5},{name:'Apple mango (medium)',price:25},{name:'Oranges',price:25},{name:'Mango big',price:40},{name:'Tomatoes',price:25},{name:'Onions (4)',price:20},{name:'Sukumawiki',price:20},{name:'Avocado',price:30},{name:'Medium avocado',price:40},{name:'Apple mango large',price:40},{name:'Paw paw',price:100},{name:'Cucumber small',price:30},{name:'Cucumber large',price:50},{name:'Managu',price:30},{name:'Banana bunch',price:100},{name:'Apple',price:45},{name:'Sukuma wiki',price:30},{name:'Peas',price:80}
    ]
  },
  {
    id: 9, name: 'LUNCH BOX', rating: 4.4, category: 'Budget Meals', image: 2,
    menu: [
      {name:'Chapati matumbo + dish',price:190},{name:'Plain rice + dish',price:75},{name:'Beef ugali + dish',price:220},{name:'Ugali kienyeji + dish',price:120},{name:'Ugali matumbo + dish',price:160},{name:'A fried egg',price:35},{name:'Ugali plain',price:35},{name:'Pilau + dish',price:160},{name:'Rice beans + dish',price:140},{name:'Chapati beef + dish',price:220},{name:'Rice ndengu + dish',price:140},{name:'Ugali mayai + dish',price:140},{name:'Ugali skuma + dish',price:100},{name:'Ugali cabbage + dish',price:100},{name:'Rice beef + dish',price:220},{name:'Chapati Minji + dish',price:140},{name:'Andazi',price:15},{name:'Chapati ndengu + dish',price:140},{name:'Chapati beans + dish',price:140},{name:'Chapati',price:20},{name:'Rice Minji + dish',price:140},{name:'Rice matumbo + dish',price:180}
    ]
  },
  {
    id: 10, name: 'QUEENS FRIES', rating: 4.3, category: 'Fries & Chicken', image: 3,
    menu: [
      {name:'Chips + sausage',price:185},{name:'1/4 chicken',price:180},{name:'Lemon juice large',price:100},{name:'Chicken loaded fries',price:360},{name:'Seasoned fries',price:150},{name:'White coffee',price:65},{name:'Pineapple juice large',price:100},{name:'Beef smokie',price:50},{name:'Classic fries',price:150},{name:'Pepsi 500ml',price:55},{name:'Ice cubes',price:20},{name:'Mango juice small',price:50},{name:'Beef loaded fries',price:360},{name:'Lemon juice small',price:50},{name:'Passion juice small',price:50},{name:'Mixed juice small',price:50},{name:'Mango juice large',price:100},{name:'Chips + samosa',price:185},{name:'Chips + smokie',price:175},{name:'Pilau chips + dish',price:200},{name:'Beef samosa',price:50},{name:'Minute maid tropical 1L',price:165},{name:'Pilau plain + dish',price:200},{name:'Chips + sausage',price:180},{name:'Black tea',price:50}
    ]
  },
  {
    id: 11, name: '404 FRIES', rating: 4.1, category: 'Fast Food', image: 4,
    menu: [
      {name:'Samosa',price:50},{name:'Chips sausage',price:170},{name:'Chips plain',price:130},{name:'Smokie',price:40},{name:'Chips + 1/4 chicken',price:310},{name:'Chips + smokie',price:170},{name:'Chips samosa',price:170},{name:'1/4 chicken',price:170},{name:'Sausage',price:60}
    ]
  },
  {
    id: 12, name: 'URBAN FRIES', rating: 4.2, category: 'Fast Food', image: 5,
    menu: [
      {name:'1/4 chicken',price:170},{name:'Chips + smokie',price:170},{name:'Chips + chicken 1/4',price:300},{name:'Samosa beef',price:50},{name:'Juice small',price:50},{name:'Beef sausage',price:50},{name:'Chips masala + dish',price:210},{name:'Pilau + dish',price:190},{name:'Plain chips',price:130},{name:'Beef smokie',price:40},{name:'Chips mayai + dish',price:210},{name:'Chips + sausage',price:170}
    ]
  },
  {
    id: 13, name: 'SFC RESTAURANT', rating: 4.5, category: 'Chicken & Fries', image: 0,
    menu: [
      {name:'Full chicken',price:750},{name:'Chapati + beef stew + dish',price:370},{name:'Pilau beef + dish',price:380},{name:'Chips',price:150},{name:'Bhajia',price:170},{name:'Ugali beef stew + dish',price:370},{name:'Chicken 1/2',price:370},{name:'Chapati',price:35},{name:'Pilau plain + dish',price:230},{name:'3/4 chicken',price:560},{name:'Samosa beef',price:50},{name:'1/4 chicken',price:180},{name:'Salad',price:45},{name:'Chips masala',price:200},{name:'Andazi',price:35}
    ]
  },
  {
    id: 14, name: 'CAKES.COM', rating: 4.6, category: 'Bakery & Cakes', image: 1,
    menu: [
      {name:'Choco ball',price:20},{name:'Chocolate cupcakes',price:40},{name:'Cookies',price:10},{name:'Tea scones',price:20},{name:'Cake slices all flavors',price:50},{name:'Yoghurt',price:50},{name:'Sugarcane juice small',price:50},{name:'Cupcakes',price:35},{name:'Cupcakes cream',price:40},{name:'Coconut bun',price:20}
    ]
  },
  {
    id: 15, name: 'MARPLE FRIES', rating: 4.0, category: 'Fast Food', image: 2,
    menu: [
      {name:'Chips plain',price:130},{name:'Chips + smokie',price:170},{name:'1/4 chicken',price:170},{name:'Smokie',price:50},{name:'Samosa',price:50},{name:'Chips + sausage',price:170},{name:'Sausage',price:55},{name:'Chips + 1/4 chicken',price:310}
    ]
  },
  {
    id: 16, name: 'MERILYN', rating: 4.3, category: 'African Cuisine', image: 3,
    menu: [
      {name:'Mukimo special',price:150},{name:'Ugali',price:40},{name:'Special rice',price:140},{name:'Pilau + dish',price:135},{name:'Pilau special + dish',price:170},{name:'Njahi stew',price:80},{name:'Mukimo special',price:125},{name:'Minji stew + dish',price:75},{name:'Beans stew + dish',price:75},{name:'Mandazi',price:15},{name:'Ugali mayai',price:120},{name:'Omelette',price:80},{name:'Githeri special',price:130},{name:'Mayai',price:80},{name:'Ndengu stew',price:75},{name:'Kamande + dish',price:75},{name:'Chapati',price:25},{name:'Rice special + dish',price:140}
    ]
  },
  {
    id: 17, name: '1ST CLASS GATE B', rating: 4.1, category: 'Budget Meals', image: 4,
    menu: [
      {name:'Andazi',price:10},{name:'Samosa beef',price:30},{name:'African stew + dish',price:105},{name:'Ugali',price:30},{name:'Rice soup + dish',price:60},{name:'Rice + dish',price:60},{name:'Mukimo',price:90},{name:'Potato stew + dish',price:70},{name:'Njahi + dish',price:60},{name:'Matumbo mix + dish',price:100},{name:'Samosa waru',price:10},{name:'Pilau + dish',price:100},{name:'Beans + dish',price:60},{name:'Boiled eggs',price:30},{name:'Beef plain',price:130},{name:'Samosa ndengu',price:10},{name:'Matumbo + dish',price:100},{name:'Chapati',price:20},{name:'Smokies',price:40},{name:'Fried eggs',price:40},{name:'Skuma',price:25},{name:'Ndengu + dish',price:60}
    ]
  },
  {
    id: 18, name: 'SEASONS RESTAURANT', rating: 4.4, category: 'African Cuisine', image: 5,
    menu: [
      {name:'Chapati + matumbo and cabbage + dish',price:175},{name:'Chapati',price:15},{name:'Samosa',price:35},{name:'Rice Minji + dish',price:120},{name:'Mukimo cabbage + dish',price:175},{name:'Mukimo beef + dish',price:190},{name:'Ugali beef mboga kienyeji + dish',price:190},{name:'Rice cabbage + dish',price:100},{name:'Chapo matumbo skuma + dish',price:170},{name:'Chapo ndengu + dish',price:100},{name:'Four mandazi + 1 samosa',price:120},{name:'Rice matumbo cabbage + dish',price:175},{name:'Rice matumbo kienyeji + dish',price:180},{name:'Chapo 2 minji + dish',price:85},{name:'Mukimo matumbo + skuma',price:135},{name:'Mukimo matumbo kienyeji + dish',price:145},{name:'Chapo beef kienyeji + dish',price:170},{name:'Ugali matumbo kienyeji + dish',price:175},{name:'Chips',price:140},{name:'3 samosa',price:120},{name:'Rice beef cabbage + dish',price:180},{name:'Chips + smokie',price:150},{name:'4 mandazi + smokie',price:90},{name:'Chapo 2 beef skuma + dish',price:180},{name:'Smokie',price:40},{name:'Rice matumbo skuma + dish',price:175},{name:'Ugali beef mboga mix + dish',price:190},{name:'Mukimo beef skuma + dish',price:190},{name:'Rice beef skuma + dish',price:175}
    ]
  },
  {
    id: 19, name: 'ARROW PORK CENTER', rating: 4.3, category: 'Pork', image: 0,
    menu: [
      {name:'1/2 pork + ugali + dish',price:580},{name:'1kg pork + ugali + dish',price:1180},{name:'1/4 pork ugali + dish',price:280},{name:'Ugali',price:55},{name:'3/4 pork + ugali + dish',price:780}
    ]
  },
  {
    id: 20, name: 'JIKONI RESTAURANT', rating: 4.5, category: 'Coastal Cuisine', image: 1,
    menu: [
      {name:'Doughnuts',price:10},{name:'Mahamri',price:10},{name:'Biryani',price:390},{name:'Pilau + dish',price:185},{name:'Coconut rice + beef stew + dish',price:220},{name:'Kaimati',price:25},{name:'Beef stew + dish',price:140},{name:'Coconut beans stew + dish',price:110},{name:'Chapo + coconut stew + dish',price:170},{name:'Viazi karai',price:25},{name:'Chapati',price:25},{name:'Achari',price:75},{name:'2 chapati beef stew + dish',price:190},{name:'Coconut rice + dish',price:100}
    ]
  },
  {
    id: 21, name: 'ATICAS CAFE', rating: 4.4, category: 'Cafe & Restaurant', image: 2,
    menu: [
      {name:'Pineapple juice small',price:50},{name:'Pineapple juice large',price:100},{name:'Pilau beef Minji + dish',price:390},{name:'Lemon juice small',price:50},{name:'Lemon juice large',price:100},{name:'Chips + 1/4 chicken',price:290},{name:'Sausage',price:60},{name:'Omelette',price:130},{name:'2 fried eggs',price:100},{name:'Ugali fish + dish',price:490},{name:'Chapo beef plain + dish',price:290},{name:'Beans plain + dish',price:100},{name:'Milk',price:100},{name:'Chapo 2 beans + dish',price:155},{name:'Ugali chicken wet',price:290},{name:'1/4 chicken wet fry',price:210},{name:'Pilau mix + dish',price:270},{name:'Mango juice small',price:50},{name:'Mango juice large',price:100},{name:'Rice ndengu + dish',price:150},{name:'Porridge big',price:145},{name:'Ugali beef + dish',price:235},{name:'Chips',price:110},{name:'Kamande plain + dish',price:160},{name:'Passion juice small',price:50},{name:'Passion juice large',price:100},{name:'Sugarcane juice small',price:50},{name:'Sugarcane juice large',price:100},{name:'Smokie',price:45},{name:'Ugali mayai + dish',price:210},{name:'Andazi',price:10},{name:'Pilau salad + dish',price:200},{name:'Tea mug',price:55},{name:'Chapati',price:30},{name:'Rice beans + dish',price:170},{name:'Rice beef mix + dish',price:170},{name:'Chips beef plain',price:340},{name:'Tea',price:30},{name:'Porridge small',price:70},{name:'Pilau beef + dish',price:390},{name:'Kamande + 2 chapatis + dish',price:210},{name:'Rice Minji beef plain + dish',price:230},{name:'Rice beef plain + dish',price:290},{name:'Kebab',price:70},{name:'Chapo beef Minji + dish',price:230},{name:'Kamande rice + dish',price:210},{name:'Samosa',price:40},{name:'Rice chicken wet + dish',price:340},{name:'1/4 chicken',price:180}
    ]
  },
  {
    id: 22, name: 'KWETU CAFE', rating: 4.3, category: 'Cafe & Snacks', image: 3,
    menu: [
      {name:'Passion juice',price:105},{name:'Cutlets',price:55},{name:'Chips + kebab + sausage',price:240},{name:'Mahamri',price:15},{name:'Mango juice',price:60},{name:'Kebab',price:80},{name:'Chips plain + sauce',price:140},{name:'Chapati',price:25},{name:'Spring roll',price:60},{name:'1/4 chicken',price:210},{name:'Samosa',price:50},{name:'Chips smokie + sauce',price:180},{name:'Chips sausage + sauce',price:220},{name:'Chips samosa + sauce',price:170},{name:'Passion juice normal',price:60},{name:'Doughnut',price:25},{name:'Sausage',price:50},{name:'Pineapple juice large',price:110},{name:'Andazi',price:15},{name:'Pilau chips + dish',price:170},{name:'Smokie',price:40}
    ]
  },
  {
    id: 23, name: 'MISTA FRIES', rating: 4.2, category: 'Fries & Fast Food', image: 4,
    menu: [
      {name:'Samosa special',price:130},{name:'1/4 chicken',price:170},{name:'Chips mayai + dish',price:250},{name:'Chips masala sweet',price:190},{name:'Chips plain',price:130},{name:'Predator',price:70},{name:'Soda 2L',price:200},{name:'Chips beef + dish',price:320},{name:'Pilau beef + dish',price:250},{name:'Chips pilau + dish',price:170},{name:'Sausage',price:60},{name:'Spaghetti veggies + dish',price:190},{name:'Chapati',price:20},{name:'Chips salad',price:140},{name:'Spaghetti beef + dish',price:270},{name:'Minute maid 1L',price:165},{name:'Rice veggies + dish',price:170},{name:'Smokie special',price:125},{name:'Samosa',price:55},{name:'Pepsi 350ml',price:50},{name:'Chips masala hot',price:190},{name:'Smokie',price:40},{name:'Kebab special',price:100},{name:'1/2 chicken',price:350},{name:'Soda 1.25L',price:140},{name:'Pepsi 600ml',price:70}
    ]
  },
  {
    id: 24, name: 'KWA MATHE', rating: 4.3, category: 'African Cuisine', image: 5,
    menu: [
      {name:'Chapati',price:20},{name:'Ugali cabbage + dish',price:190},{name:'Ugali kienyeji + dish',price:120},{name:'Chapati 2 + stew',price:130},{name:'Pilau beans + dish',price:180},{name:'Rice ndengu + dish',price:110},{name:'2 chapati beans + dish',price:120},{name:'2 chapatis matumbo + dish',price:130},{name:'Ugali beef + dish',price:220},{name:'Pilau + dish',price:120},{name:'Ugali stew mix + dish',price:120},{name:'2 chapatis beef + dish',price:210},{name:'Ugali matumbo + dish',price:140},{name:'Pilau Minji + dish',price:170},{name:'2 chapatis potato stew + dish',price:110},{name:'2 chapati cabbage + dish',price:100},{name:'2 chapatis ndengu + dish',price:110},{name:'2 chapatis kienyeji + dish',price:120},{name:'Pilau stew mix + dish',price:190},{name:'Pilau ndengu + dish',price:170},{name:'Rice matumbo + dish',price:140},{name:'Viazi karai',price:20},{name:'Pilau matumbo + dish',price:190},{name:'Rice Minji + dish',price:120},{name:'Pilau potato stew',price:170},{name:'Rice potato stew + dish',price:120},{name:'Pilau beef + dish',price:280},{name:'Rice beans + dish',price:110}
    ]
  },
  {
    id: 25, name: 'MOHAZ GRILL', rating: 4.4, category: 'Grill & Snacks', image: 0,
    menu: [
      {name:'Samosa',price:40},{name:'Sausage',price:60},{name:'Smokie bun',price:80},{name:'Kebab',price:100},{name:'Beef burger',price:130},{name:'Chicken burger',price:130},{name:'Bhajia',price:70},{name:'Smocha',price:80},{name:'Chicken',price:75},{name:'Kebab roll',price:90},{name:'Smokie',price:40},{name:'Sausage chapo',price:90},{name:'Sausage bun',price:90}
    ]
  },
  {
    id: 26, name: 'PORK POINT', rating: 4.2, category: 'Pork', image: 1,
    menu: [
      {name:'Ugali pork choma',price:190},{name:'Ugali pork wet fry + dish',price:190},{name:'1/2 ugali pork choma + dish',price:390},{name:'1/2 ugali pork wet fry + dish',price:390}
    ]
  },
  {
    id: 27, name: '911 FAST FOODS', rating: 4.1, category: 'Fast Food', image: 2,
    menu: [
      {name:'Kuku chips',price:290},{name:'Chips smokie + kuku',price:370},{name:'1/4 chicken',price:170},{name:'Fries plain',price:125},{name:'Smokie',price:40},{name:'1/2 chicken',price:350},{name:'Sausage',price:55},{name:'Chips + sausage',price:170},{name:'Fries + smokie',price:150}
    ]
  },
  {
    id: 28, name: 'PILAU SPOT', rating: 4.5, category: 'Pilau & Biryani', image: 3,
    menu: [
      {name:'Pilau + dish',price:155},{name:'Pilau biryani + dish',price:300},{name:'Pilau platter 1',price:250},{name:'Pilau platter 2',price:290},{name:'Pakora',price:60},{name:'Chicken spring roll',price:40},{name:'Snack combo',price:160},{name:'Biryani platter',price:350},{name:'Bhajia',price:55},{name:'Chicken biryani + dish',price:260}
    ]
  },
  {
    id: 29, name: 'DAH PLACE', rating: 4.2, category: 'Budget Meals', image: 4,
    menu: [
      {name:'Andazi',price:15},{name:'Ugali matumbo veggie + dish',price:150},{name:'Ugali beef veggie + dish',price:150},{name:'Pilau + dish',price:150},{name:'Ndengu plain + dish',price:100},{name:'Rice plain + dish',price:100},{name:'Matumbo plain + dish',price:120},{name:'Rice Minji + dish',price:100},{name:'Fries',price:110},{name:'Donut',price:20},{name:'Chapo',price:20},{name:'Minji plain + dish',price:100},{name:'Samosa',price:40},{name:'Rice ndengu + dish',price:100},{name:'Beans ndengu + dish',price:90},{name:'Beans plain + dish',price:90},{name:'Pilau beef + dish',price:230},{name:'Rice beans + dish',price:90},{name:'Beef plain + dish',price:130},{name:'Smokie',price:30},{name:'2 samosa + 1 doughnut + 1 smokie',price:120},{name:'Rice beef + dish',price:150}
    ]
  },
  {
    id: 30, name: 'MORIAH DELI', rating: 4.7, category: 'Premium Dining', image: 5,
    menu: [
      {name:'Beef kebab',price:120},{name:'Pancake double',price:160},{name:'Kienyeji chicken + dish',price:620},{name:'Spanish omelette',price:120},{name:'Mbaazi coconut stew + dish',price:380},{name:'Chicken salad',price:440},{name:'Roast chicken plain',price:370},{name:'Avocado salad',price:320},{name:'Wet fry liver',price:480},{name:'Chapati brown',price:50},{name:'Pilau + dish',price:320},{name:'Marinated fish fingers + dish',price:530},{name:'Chapati white',price:50},{name:'Mini fish fingers',price:380},{name:'2 fried eggs',price:100},{name:'Chapati carrot',price:80},{name:'Steamed rice + dish',price:210},{name:'Samosa special',price:270},{name:'Honey glazed chicken wings + dish',price:490},{name:'Wet fry beef + dish',price:490},{name:'Wet fried chicken + dish',price:530},{name:'Chapati pumpkin',price:65},{name:'T-bone steak',price:680},{name:'Full breakfast + dishes',price:410},{name:'Beef burger',price:320},{name:'Sausage special',price:270},{name:'Sir loin steak',price:790},{name:'Roast chicken',price:490},{name:'Meat pie',price:160},{name:'Chicken pie',price:155},{name:'Beef dry fry',price:500},{name:'Dry fried chicken',price:490},{name:'Githeri special',price:320},{name:'Tasty breaded fish fillet + dish',price:540},{name:'Chicken burger',price:320},{name:'Fried goat + dish',price:590},{name:'Stewed matoke + dish',price:320},{name:'Fried mukimo + dish',price:320},{name:'Whole deep fried tilapia + dish',price:640},{name:'Spaghetti bolognese + dish',price:430},{name:'Andazi',price:40},{name:'Nduma',price:100},{name:'Minute steak',price:780},{name:'Meat balls + dish',price:380}
    ]
  },
  {
    id: 31, name: 'ALPHA PORK', rating: 4.1, category: 'Pork', image: 0,
    menu: [
      {name:'Pork fry + ugali + dish',price:130},{name:'Pork choma + dish + ugali',price:130},{name:'Pork choma 1/4 ugali + dish',price:210},{name:'Pork wet fry 1/4 ugali + dish',price:210},{name:'Raw pork 1kg',price:700}
    ]
  },
  {
    id: 32, name: 'JUJA ECOMATT BAKERY', rating: 4.3, category: 'Bakery', image: 1,
    menu: [
      {name:'Carrot cake',price:100},{name:'Cream slice',price:100},{name:'Andazi',price:20},{name:'Hot dog',price:130},{name:'Choco cookies',price:40},{name:'Bread 400g',price:65},{name:'Sweet cup',price:120},{name:'Cookies',price:15},{name:'Banana slice',price:100},{name:'Coco muffin',price:50},{name:'Scone',price:65},{name:'Long rolls',price:65},{name:'Meat pie',price:85},{name:'Vanilla muffins',price:65},{name:'Choco doughnut',price:40},{name:'Red velvet',price:180},{name:'White forest',price:180},{name:'Doughnut',price:40},{name:'Muffin',price:30},{name:'Kebab',price:75},{name:'Bread 600g',price:90},{name:'Sim sim buns',price:70},{name:'Raw chicken full',price:650},{name:'Black forest',price:180},{name:'Tea scones',price:40},{name:'Chapati',price:30},{name:'Bread 800g',price:130},{name:'Brown buns',price:15},{name:'Rockbun',price:75}
    ]
  },
  {
    id: 33, name: 'CITRUS GRILL', rating: 4.2, category: 'Grill & Snacks', image: 2,
    menu: [
      {name:'Hot dog',price:110},{name:'Beef burger',price:130},{name:'Smokie bun',price:90},{name:'Kebab',price:110},{name:'Smocha',price:90},{name:'Kebab roll',price:90},{name:'Sausage bun',price:90},{name:'Smokie',price:40},{name:'Sausage chapo',price:90},{name:'Samosa beef',price:30},{name:'Sausage',price:60},{name:'Viazi karai',price:40}
    ]
  },
  {
    id: 34, name: 'MC DELI', rating: 4.3, category: 'Chicken & Fries', image: 3,
    menu: [
      {name:'Kebab',price:75},{name:'Dasani 300ml',price:60},{name:'1/4 chicken',price:180},{name:'Bhajia masala',price:230},{name:'Full chicken',price:770},{name:'Chips',price:130},{name:'Chips masala',price:210},{name:'Smokie',price:45},{name:'1/2 chicken',price:380},{name:'Dasani 1L',price:100},{name:'Sausage',price:60},{name:'Soda 300ml',price:75},{name:'Chapati',price:20},{name:'Samosa',price:40}
    ]
  },
  {
    id: 35, name: 'WA JEFF', rating: 4.0, category: 'Budget Meals', image: 4,
    menu: [
      {name:'Matumbo plain + dish',price:100},{name:'Ugali omelette + dish',price:110},{name:'Fried eggs',price:20},{name:'Rice beans + dish',price:90},{name:'Ugali kienyeji + dish',price:100},{name:'Rice matoke beef + dish',price:110},{name:'Ugali African + dish',price:100},{name:'Githeri plain + dish',price:100},{name:'Chapati',price:20},{name:'Plain beef + dish',price:130},{name:'Smokies',price:40},{name:'Githeri beef + dish',price:110},{name:'Matoke beef + dish',price:110},{name:'Rice njahi beef + dish',price:160},{name:'Ugali matumbo + dish',price:110},{name:'Rice plain + dish',price:60},{name:'Ugali skuma + dish',price:85},{name:'Ugali cabbage + dish',price:85},{name:'Mukimo beef + dish',price:110},{name:'Ugali',price:25},{name:'Andazi',price:10}
    ]
  },
  {
    id: 36, name: 'GREEN SAVANNAH', rating: 4.5, category: 'Restaurant', image: 5,
    menu: [
      {name:'Chapati + beans + dish',price:250},{name:'Toast bandika',price:50},{name:'Sausage chips and salad + dish',price:290},{name:'Rice beef + dish',price:370},{name:'Rice kamande + dish',price:190},{name:'Chapati',price:45},{name:'Chapati beef + dish',price:370},{name:'Rice njahi + dish',price:190},{name:'Andazi',price:30},{name:'Chips chicken + dish',price:320},{name:'2 scrambled eggs + dish',price:150},{name:'Rice Minji + dish',price:350},{name:'Ugali beef + dish',price:370},{name:'2 eggs + dish',price:100},{name:'Chapati with Minji + dish',price:310},{name:'Chips beef + dish',price:440},{name:'Kebab',price:110},{name:'Rice with fish + dish',price:310},{name:'Ugali tilapia fish + dish',price:440},{name:'Rice veggie + dish',price:150},{name:'Samosa',price:60},{name:'Pilau veggies + dish',price:310},{name:'Pilau beef stew + dish',price:440},{name:'Spanish omelette + dish',price:140},{name:'Sausage',price:60},{name:'Chapati njahi + dish',price:310},{name:'Chapati with veggies + dish',price:210},{name:'Chips plain',price:170}
    ]
  },
  {
    id: 37, name: 'SCOOPS & SPOONS KITCHEN', rating: 4.8, category: 'Premium Fast Food', image: 0,
    menu: [
      {name:'Classic chicken crunch burger',price:350},{name:'Dark bliss coffee',price:50},{name:'Golden chicken pilau',price:430},{name:'Street king kebab',price:85},{name:'Kachumbari',price:50},{name:'Cheese crunchy chips',price:320},{name:'Local matumbo stew',price:280},{name:'Crispy cloud waffles',price:100},{name:'Chocolate moncha',price:210},{name:'Chips and egg special',price:210},{name:'Mango juice small',price:55},{name:'Signature beef stack burger',price:320},{name:'Tender beef dry/wet fry',price:320},{name:'Pure black tea',price:45},{name:'Bombay spiced fries',price:210},{name:'Mukimo beef',price:320},{name:'Beef pilau royal',price:380},{name:'Tax-beef crunch 3 piece',price:540},{name:'Beef fried rice bowl',price:430},{name:'Sugarcane juice large',price:110},{name:'Street classic fries',price:130},{name:'House special loaded fries',price:480},{name:'Sizzling beef wrap',price:320},{name:'Chicken biriani',price:480},{name:'Beef sausage',price:60},{name:'Asian veg egg stir fry',price:320},{name:'Spiced chicken dry/wet fry',price:380},{name:'Cocktail juice',price:120},{name:'Bazuu loaded fries',price:220},{name:'Cheesy chicken frenzy',price:320},{name:'Garlic fries',price:210},{name:'Creamy white coffee',price:100},{name:'Pineapple large',price:110},{name:'Wok-tossed beef delight',price:380},{name:'Beef supreme fryz',price:370},{name:'Green delight burger',price:270},{name:'Platter for 3',price:1890},{name:'Tilapia fish',price:490},{name:'Grilled chicken wrap',price:320},{name:'Passion juice large',price:110},{name:'Fresh garden wrap',price:270},{name:'Smokie delight',price:40},{name:'Velvet slice cake',price:190},{name:'Soft layered chapati',price:25},{name:'Sweet bliss cupcake',price:50},{name:'Desi masala chips',price:210},{name:'Platter for 5',price:2800},{name:'Chicken rice bowl',price:430},{name:'Mango juice jumbo',price:175},{name:'Classic chicken roll',price:170},{name:'Mukimo plain',price:130},{name:'Classic coastal pilau',price:210}
    ]
  }
];
