export const IMAGES = {
  logo: 'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155622069_a0f411c4.png',
  heroBanner: 'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155883796_e369fae4.jpg',
  foodBanner: 'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155647679_08142222.jpg',
  restaurants: [
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155665992_c8bcd77f.jpg',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155786686_793bab42.jpg',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155668101_dbee8207.jpg',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155669771_055e5ffd.jpg',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155686307_ecdfc1c7.png',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155671221_2ef7d3d1.jpg',
  ],
  foods: [
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155813115_e9f5b065.jpg',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155814962_fe0187c6.png',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155819034_a2da15d5.png',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155856177_5142691b.png',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155813965_c6f725bb.jpg',
    'https://d64gsuwffb70l.cloudfront.net/69ceb918daf316f7acb9994f_1775155815455_aa74ff6f.jpg',
  ],
};
