import { createClient } from '@supabase/supabase-js';


// Initialize database client
const supabaseUrl = 'https://vmnndyjnhegposykxttk.databasepad.com';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCIsImtpZCI6IjM4YTg4MzgwLWMwYjUtNDA5Ni04YjczLTMxYThkMDIxNDE2NyJ9.eyJwcm9qZWN0SWQiOiJ2bW5uZHlqbmhlZ3Bvc3lreHR0ayIsInJvbGUiOiJhbm9uIiwiaWF0IjoxNzc1MTU1NTA5LCJleHAiOjIwOTA1MTU1MDksImlzcyI6ImZhbW91cy5kYXRhYmFzZXBhZCIsImF1ZCI6ImZhbW91cy5jbGllbnRzIn0.9dpk_YALMNETLCPnZeQvfZv0_bqR8P-Q-jEuOFhAMzg';
const supabase = createClient(supabaseUrl, supabaseKey);


export { supabase };