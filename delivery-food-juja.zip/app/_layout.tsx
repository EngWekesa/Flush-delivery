import { Stack } from "expo-router";
import { StoreProvider } from "./lib/store";
import { StatusBar } from "expo-status-bar";

if (typeof globalThis.fetch === 'undefined') {
  // @ts-ignore
  globalThis.fetch = fetch;
}

export default function RootLayout() {
  return (
    <StoreProvider>
      <StatusBar style="light" />
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="index" />
        <Stack.Screen name="login" />
        <Stack.Screen name="signup" />
        <Stack.Screen name="(customer)" />
        <Stack.Screen name="(rider)" />
        <Stack.Screen name="(admin)" />
        <Stack.Screen name="restaurant/[id]" />
      </Stack>
    </StoreProvider>
  );
}
