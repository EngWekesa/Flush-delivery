import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, SafeAreaView, ScrollView, Alert, ActivityIndicator, Image } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { supabase } from './lib/supabase';
import { useStore } from './lib/store';
import { IMAGES } from './lib/images';

export default function LoginScreen() {
  const router = useRouter();
  const { setUser } = useStore();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please enter email and password');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('auth', {
        body: {
          action: 'login',
          email: email.toLowerCase().trim(),
          password,
        },
      });

      if (error) throw error;
      if (data?.error) {
        Alert.alert('Error', data.error);
        return;
      }

      if (data?.user) {
        setUser(data.user);
        if (data.user.role === 'admin') {
          router.replace('/(admin)');
        } else if (data.user.role === 'rider') {
          router.replace('/(rider)');
        } else {
          router.replace('/(customer)');
        }
      }
    } catch (err: any) {
      Alert.alert('Error', err.message || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView contentContainerStyle={styles.scroll}>
        <TouchableOpacity style={styles.backBtn} onPress={() => router.back()}>
          <Ionicons name="arrow-back" size={24} color="#1a5c2e" />
        </TouchableOpacity>

        <View style={styles.header}>
          <Image source={{ uri: IMAGES.logo }} style={styles.logo} />
          <Text style={styles.title}>Welcome Back!</Text>
          <Text style={styles.subtitle}>Log in to FLUSH DELIVERY</Text>
        </View>

        <View style={styles.form}>
          <Text style={styles.label}>Email</Text>
          <View style={styles.inputWrap}>
            <Ionicons name="mail-outline" size={20} color="#999" />
            <TextInput
              style={styles.input}
              placeholder="Enter your email"
              value={email}
              onChangeText={setEmail}
              keyboardType="email-address"
              autoCapitalize="none"
            />
          </View>

          <Text style={styles.label}>Password</Text>
          <View style={styles.inputWrap}>
            <Ionicons name="lock-closed-outline" size={20} color="#999" />
            <TextInput
              style={styles.input}
              placeholder="Enter your password"
              value={password}
              onChangeText={setPassword}
              secureTextEntry={!showPassword}
            />
            <TouchableOpacity onPress={() => setShowPassword(!showPassword)}>
              <Ionicons name={showPassword ? 'eye-off' : 'eye'} size={20} color="#999" />
            </TouchableOpacity>
          </View>

          <TouchableOpacity style={styles.submitBtn} onPress={handleLogin} disabled={loading}>
            {loading ? (
              <ActivityIndicator color="#fff" />
            ) : (
              <>
                <Ionicons name="log-in-outline" size={22} color="#fff" />
                <Text style={styles.submitText}>Log In</Text>
              </>
            )}
          </TouchableOpacity>

          <TouchableOpacity style={styles.signupLink} onPress={() => router.push('/')}>
            <Text style={styles.signupLinkText}>
              Don't have an account? <Text style={{ color: '#2ECC71', fontWeight: '700' }}>Sign Up</Text>
            </Text>
          </TouchableOpacity>
        </View>

        <View style={styles.contactBar}>
          <Ionicons name="call" size={18} color="#2ECC71" />
          <Text style={styles.contactText}>For queries call: 0708770746</Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  scroll: { padding: 20, paddingTop: 50 },
  backBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: '#e8f5e9', justifyContent: 'center', alignItems: 'center', marginBottom: 16 },
  header: { alignItems: 'center', marginBottom: 30 },
  logo: { width: 90, height: 90, borderRadius: 45, marginBottom: 16 },
  title: { fontSize: 26, fontWeight: '800', color: '#1a1a1a' },
  subtitle: { fontSize: 14, color: '#888', marginTop: 4 },
  form: {},
  label: { fontSize: 14, fontWeight: '600', color: '#444', marginBottom: 6, marginTop: 16 },
  inputWrap: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 12, paddingHorizontal: 14, borderWidth: 1, borderColor: '#e0e0e0',
  },
  input: { flex: 1, fontSize: 15, color: '#333', paddingVertical: 14, marginLeft: 10 },
  submitBtn: {
    flexDirection: 'row', backgroundColor: '#2ECC71', borderRadius: 14, padding: 16,
    alignItems: 'center', justifyContent: 'center', marginTop: 28,
  },
  submitText: { color: '#fff', fontSize: 17, fontWeight: '700', marginLeft: 8 },
  signupLink: { alignItems: 'center', marginTop: 20 },
  signupLinkText: { fontSize: 14, color: '#888' },
  contactBar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#e8f5e9', borderRadius: 12, padding: 14, marginTop: 40, marginBottom: 30,
  },
  contactText: { color: '#1a5c2e', fontSize: 14, fontWeight: '600', marginLeft: 8 },
});
