import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator, RefreshControl, Alert, Linking } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../lib/store';
import { supabase } from '../lib/supabase';

interface Order {
  id: string;
  customer_name: string;
  customer_phone: string;
  status: string;
  total_amount: number;
  delivery_fee: number;
  location_address: string;
  location_lat: number;
  location_lng: number;
  phone: string;
  door_number: string;
  description: string;
  created_at: string;
  order_items: { item_name: string; restaurant_name: string; quantity: number; price: number }[];
}

const statusColors: { [key: string]: string } = {
  processing: '#3498db',
  in_transit: '#9b59b6',
  completed: '#2ECC71',
  failed: '#e74c3c',
};

export default function MyOrders() {
  const { user } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [updating, setUpdating] = useState<string | null>(null);

  const fetchOrders = useCallback(async () => {
    try {
      const { data } = await supabase.functions.invoke('orders', {
        body: { action: 'get_rider_orders', rider_id: user?.id },
      });
      if (data?.orders) setOrders(data.orders);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 5000);
    return () => clearInterval(interval);
  }, [fetchOrders]);

  const updateStatus = async (orderId: string, status: string) => {
    setUpdating(orderId);
    try {
      const { data, error } = await supabase.functions.invoke('orders', {
        body: { action: 'update_order_status', order_id: orderId, status },
      });
      if (data?.error) throw new Error(data.error);
      if (status === 'completed') {
        Alert.alert('Order Completed!', 'The customer has been notified. Great job!');
      }
      fetchOrders();
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setUpdating(null);
    }
  };

  const openMaps = (lat: number, lng: number, address: string) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`;
    Linking.openURL(url);
  };

  const activeOrders = orders.filter(o => o.status !== 'completed' && o.status !== 'failed');
  const completedOrders = orders.filter(o => o.status === 'completed' || o.status === 'failed');

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>My Deliveries</Text>
        <Text style={styles.headerSub}>{activeOrders.length} active</Text>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#2ECC71" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={[...activeOrders, ...completedOrders]}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchOrders(); }} tintColor="#2ECC71" />}
          contentContainerStyle={{ padding: 16, paddingBottom: 30 }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => {
            const isActive = item.status !== 'completed' && item.status !== 'failed';
            return (
              <View style={[styles.orderCard, !isActive && styles.orderCardCompleted]}>
                <View style={styles.orderHeader}>
                  <Text style={styles.orderId}>#{item.id.slice(0, 8)}</Text>
                  <View style={[styles.statusBadge, { backgroundColor: (statusColors[item.status] || '#999') + '20' }]}>
                    <Text style={[styles.statusText, { color: statusColors[item.status] || '#999' }]}>
                      {item.status === 'in_transit' ? 'In Transit' : item.status.charAt(0).toUpperCase() + item.status.slice(1)}
                    </Text>
                  </View>
                </View>

                {/* Customer Info */}
                <View style={styles.customerInfo}>
                  <Ionicons name="person" size={16} color="#2ECC71" />
                  <Text style={styles.customerName}>{item.customer_name}</Text>
                  <TouchableOpacity onPress={() => Linking.openURL(`tel:${item.customer_phone || item.phone}`)}>
                    <Ionicons name="call" size={18} color="#2ECC71" />
                  </TouchableOpacity>
                </View>

                {/* Items List */}
                <View style={styles.itemsList}>
                  {item.order_items?.map((oi, idx) => (
                    <View key={idx} style={styles.itemRow}>
                      <Text style={styles.itemName}>{oi.quantity}x {oi.item_name}</Text>
                      <Text style={styles.itemRestaurant}>Pick: {oi.restaurant_name}</Text>
                    </View>
                  ))}
                </View>

                {/* Location */}
                {isActive && (
                  <TouchableOpacity
                    style={styles.locationBtn}
                    onPress={() => openMaps(item.location_lat, item.location_lng, item.location_address)}
                  >
                    <Ionicons name="navigate" size={18} color="#fff" />
                    <Text style={styles.locationBtnText}>Navigate to Customer</Text>
                  </TouchableOpacity>
                )}

                {item.door_number ? (
                  <Text style={styles.doorNumber}>Door: {item.door_number}</Text>
                ) : null}
                {item.description ? (
                  <Text style={styles.description}>Note: {item.description}</Text>
                ) : null}

                {/* Action Buttons */}
                {isActive && (
                  <View style={styles.actions}>
                    {item.status === 'processing' && (
                      <TouchableOpacity
                        style={[styles.actionBtn, { backgroundColor: '#9b59b6' }]}
                        onPress={() => updateStatus(item.id, 'in_transit')}
                        disabled={updating === item.id}
                      >
                        {updating === item.id ? <ActivityIndicator color="#fff" size="small" /> : (
                          <>
                            <Ionicons name="bicycle" size={16} color="#fff" />
                            <Text style={styles.actionBtnText}>In Transit</Text>
                          </>
                        )}
                      </TouchableOpacity>
                    )}
                    {item.status === 'in_transit' && (
                      <TouchableOpacity
                        style={[styles.actionBtn, { backgroundColor: '#2ECC71' }]}
                        onPress={() => updateStatus(item.id, 'completed')}
                        disabled={updating === item.id}
                      >
                        {updating === item.id ? <ActivityIndicator color="#fff" size="small" /> : (
                          <>
                            <Ionicons name="checkmark-circle" size={16} color="#fff" />
                            <Text style={styles.actionBtnText}>Complete</Text>
                          </>
                        )}
                      </TouchableOpacity>
                    )}
                    {(item.status === 'processing' || item.status === 'in_transit') && (
                      <TouchableOpacity
                        style={[styles.actionBtn, { backgroundColor: '#e74c3c' }]}
                        onPress={() => {
                          Alert.alert('Fail Order', 'Are you sure you want to fail this order?', [
                            { text: 'Cancel' },
                            { text: 'Yes, Fail', onPress: () => updateStatus(item.id, 'failed'), style: 'destructive' },
                          ]);
                        }}
                      >
                        <Ionicons name="close-circle" size={16} color="#fff" />
                        <Text style={styles.actionBtnText}>Fail</Text>
                      </TouchableOpacity>
                    )}
                  </View>
                )}

                <View style={styles.orderFooter}>
                  <Text style={styles.feeText}>Fee: KSh {item.delivery_fee}</Text>
                  <Text style={styles.totalText}>Total: KSh {item.total_amount}</Text>
                </View>
              </View>
            );
          }}
          keyExtractor={(item) => item.id}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="bicycle-outline" size={64} color="#ccc" />
              <Text style={styles.emptyTitle}>No deliveries yet</Text>
              <Text style={styles.emptyText}>Grab orders from Available tab</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    backgroundColor: '#2ECC71', paddingTop: 55, paddingBottom: 16, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800' },
  headerSub: { color: '#c8f7dc', fontSize: 13, marginTop: 2 },
  orderCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 14,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4,
  },
  orderCardCompleted: { opacity: 0.6 },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  orderId: { fontSize: 14, fontWeight: '700', color: '#333' },
  statusBadge: { paddingHorizontal: 10, paddingVertical: 4, borderRadius: 10 },
  statusText: { fontSize: 12, fontWeight: '700' },
  customerInfo: { flexDirection: 'row', alignItems: 'center', marginBottom: 10, backgroundColor: '#e8f5e9', padding: 10, borderRadius: 10 },
  customerName: { flex: 1, fontSize: 14, fontWeight: '600', color: '#333', marginLeft: 8 },
  itemsList: { backgroundColor: '#f8f9fa', borderRadius: 10, padding: 10, marginBottom: 10 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4, borderBottomWidth: 1, borderBottomColor: '#eee' },
  itemName: { fontSize: 13, color: '#333', flex: 1 },
  itemRestaurant: { fontSize: 11, color: '#e67e22', fontWeight: '600' },
  locationBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center',
    backgroundColor: '#3498db', borderRadius: 10, padding: 12, marginBottom: 8,
  },
  locationBtnText: { color: '#fff', fontSize: 14, fontWeight: '700', marginLeft: 6 },
  doorNumber: { fontSize: 13, color: '#555', marginBottom: 4 },
  description: { fontSize: 13, color: '#888', fontStyle: 'italic', marginBottom: 8 },
  actions: { flexDirection: 'row', gap: 8, marginBottom: 10 },
  actionBtn: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', borderRadius: 10, padding: 12 },
  actionBtnText: { color: '#fff', fontSize: 13, fontWeight: '700', marginLeft: 4 },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between' },
  feeText: { fontSize: 13, color: '#888' },
  totalText: { fontSize: 14, fontWeight: '700', color: '#2ECC71' },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#333', marginTop: 16 },
  emptyText: { fontSize: 14, color: '#888', marginTop: 4 },
});
