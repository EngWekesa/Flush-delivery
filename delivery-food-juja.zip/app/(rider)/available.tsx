import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, ActivityIndicator, RefreshControl, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../lib/store';
import { supabase } from '../lib/supabase';

interface Order {
  id: string;
  customer_name: string;
  customer_phone: string;
  total_amount: number;
  delivery_fee: number;
  location_address: string;
  location_lat: number;
  location_lng: number;
  phone: string;
  door_number: string;
  description: string;
  created_at: string;
  order_items: { item_name: string; restaurant_name: string; quantity: number; price: number }[];
}

export default function AvailableOrders() {
  const { user } = useStore();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [grabbing, setGrabbing] = useState<string | null>(null);

  const fetchOrders = useCallback(async () => {
    try {
      const { data } = await supabase.functions.invoke('orders', {
        body: { action: 'get_available_orders' },
      });
      if (data?.orders) setOrders(data.orders);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    fetchOrders();
    const interval = setInterval(fetchOrders, 5000);
    return () => clearInterval(interval);
  }, [fetchOrders]);

  const handleGrab = async (orderId: string) => {
    setGrabbing(orderId);
    try {
      const { data, error } = await supabase.functions.invoke('orders', {
        body: { action: 'grab_order', order_id: orderId, rider_id: user?.id },
      });
      if (data?.error) {
        Alert.alert('Oops', data.error);
      } else {
        Alert.alert('Order Grabbed!', 'You have successfully grabbed this order. Check My Deliveries.');
        fetchOrders();
      }
    } catch (err: any) {
      Alert.alert('Error', err.message);
    } finally {
      setGrabbing(null);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Available Orders</Text>
        <Text style={styles.headerSub}>Grab orders to deliver</Text>
      </View>

      {loading ? (
        <ActivityIndicator size="large" color="#2ECC71" style={{ marginTop: 40 }} />
      ) : (
        <FlatList
          data={orders}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchOrders(); }} tintColor="#2ECC71" />}
          contentContainerStyle={{ padding: 16 }}
          showsVerticalScrollIndicator={false}
          renderItem={({ item }) => (
            <View style={styles.orderCard}>
              <View style={styles.orderHeader}>
                <View style={styles.newBadge}>
                  <Ionicons name="flash" size={12} color="#fff" />
                  <Text style={styles.newBadgeText}>NEW</Text>
                </View>
                <Text style={styles.orderTime}>{new Date(item.created_at).toLocaleTimeString()}</Text>
              </View>

              <Text style={styles.customerName}>Customer: {item.customer_name}</Text>
              <Text style={styles.orderLocation}>
                <Ionicons name="location" size={13} color="#e74c3c" /> {item.location_address || 'Juja'}
              </Text>

              <View style={styles.itemsList}>
                <Text style={styles.itemsTitle}>Items to pick up:</Text>
                {item.order_items?.map((oi, idx) => (
                  <View key={idx} style={styles.itemRow}>
                    <Text style={styles.itemName}>{oi.quantity}x {oi.item_name}</Text>
                    <Text style={styles.itemRestaurant}>{oi.restaurant_name}</Text>
                  </View>
                ))}
              </View>

              <View style={styles.orderFooter}>
                <View>
                  <Text style={styles.feeLabel}>Delivery Fee</Text>
                  <Text style={styles.feeAmount}>KSh {item.delivery_fee}</Text>
                  <Text style={styles.yourEarning}>Your earning: KSh {(Number(item.delivery_fee) * 0.65).toFixed(0)}</Text>
                </View>
                <TouchableOpacity
                  style={styles.grabBtn}
                  onPress={() => handleGrab(item.id)}
                  disabled={grabbing === item.id}
                >
                  {grabbing === item.id ? (
                    <ActivityIndicator color="#fff" size="small" />
                  ) : (
                    <>
                      <Ionicons name="hand-left" size={18} color="#fff" />
                      <Text style={styles.grabBtnText}>Grab Order</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
            </View>
          )}
          keyExtractor={(item) => item.id}
          ListEmptyComponent={
            <View style={styles.empty}>
              <Ionicons name="hourglass-outline" size={64} color="#ccc" />
              <Text style={styles.emptyTitle}>No available orders</Text>
              <Text style={styles.emptyText}>New orders will appear here automatically</Text>
            </View>
          }
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    backgroundColor: '#2ECC71', paddingTop: 55, paddingBottom: 16, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800' },
  headerSub: { color: '#c8f7dc', fontSize: 13, marginTop: 2 },
  orderCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 16, marginBottom: 14,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.1, shadowRadius: 8, elevation: 4,
    borderLeftWidth: 4, borderLeftColor: '#f39c12',
  },
  orderHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 },
  newBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#f39c12', borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 },
  newBadgeText: { color: '#fff', fontSize: 11, fontWeight: '800', marginLeft: 3 },
  orderTime: { fontSize: 12, color: '#999' },
  customerName: { fontSize: 15, fontWeight: '700', color: '#333', marginBottom: 4 },
  orderLocation: { fontSize: 13, color: '#666', marginBottom: 10 },
  itemsList: { backgroundColor: '#f8f9fa', borderRadius: 10, padding: 12, marginBottom: 12 },
  itemsTitle: { fontSize: 13, fontWeight: '700', color: '#555', marginBottom: 6 },
  itemRow: { flexDirection: 'row', justifyContent: 'space-between', paddingVertical: 4, borderBottomWidth: 1, borderBottomColor: '#eee' },
  itemName: { fontSize: 13, color: '#333', flex: 1 },
  itemRestaurant: { fontSize: 12, color: '#2ECC71', fontWeight: '600' },
  orderFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  feeLabel: { fontSize: 12, color: '#888' },
  feeAmount: { fontSize: 18, fontWeight: '800', color: '#1a1a1a' },
  yourEarning: { fontSize: 12, color: '#2ECC71', fontWeight: '600' },
  grabBtn: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#2ECC71',
    borderRadius: 12, paddingHorizontal: 20, paddingVertical: 12,
  },
  grabBtnText: { color: '#fff', fontSize: 15, fontWeight: '700', marginLeft: 6 },
  empty: { alignItems: 'center', marginTop: 80 },
  emptyTitle: { fontSize: 20, fontWeight: '700', color: '#333', marginTop: 16 },
  emptyText: { fontSize: 14, color: '#888', marginTop: 4 },
});
