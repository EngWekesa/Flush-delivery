import React, { useState, useEffect, useCallback } from 'react';
import { View, Text, StyleSheet, ScrollView, RefreshControl, TouchableOpacity, ActivityIndicator } from 'react-native';
import { useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useStore } from '../lib/store';
import { supabase } from '../lib/supabase';

export default function RiderDashboard() {
  const { user, setUser } = useStore();
  const router = useRouter();
  const [stats, setStats] = useState({ totalOrders: 0, totalTransport: 0, paidTransport: 0 });
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fetchStats = useCallback(async () => {
    try {
      const { data } = await supabase.functions.invoke('orders', {
        body: { action: 'get_rider_stats', rider_id: user?.id },
      });
      if (data) {
        setStats({
          totalOrders: data.totalOrders || 0,
          totalTransport: data.totalTransport || 0,
          paidTransport: data.paidTransport || 0,
        });
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 10000);
    return () => clearInterval(interval);
  }, [fetchStats]);

  const handleLogout = () => {
    setUser(null);
    router.replace('/');
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <View>
          <Text style={styles.greeting}>Welcome,</Text>
          <Text style={styles.userName}>{user?.name || 'Rider'}</Text>
          <View style={styles.methodBadge}>
            <Ionicons name={user?.delivery_method === 'bicycle' ? 'bicycle' : 'car-sport'} size={14} color="#fff" />
            <Text style={styles.methodText}>{user?.delivery_method === 'bicycle' ? 'Bicycle' : 'Motorbike'}</Text>
          </View>
        </View>
        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Ionicons name="log-out-outline" size={22} color="#fff" />
        </TouchableOpacity>
      </View>

      <ScrollView
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => { setRefreshing(true); fetchStats(); }} tintColor="#2ECC71" />}
        contentContainerStyle={{ padding: 16 }}
      >
        {loading ? (
          <ActivityIndicator size="large" color="#2ECC71" style={{ marginTop: 40 }} />
        ) : (
          <>
            <Text style={styles.sectionTitle}>Your Performance</Text>
            <View style={styles.statsGrid}>
              <View style={[styles.statCard, { backgroundColor: '#e8f5e9' }]}>
                <Ionicons name="checkmark-done-circle" size={32} color="#2ECC71" />
                <Text style={styles.statValue}>{stats.totalOrders}</Text>
                <Text style={styles.statLabel}>Orders Completed</Text>
              </View>
              <View style={[styles.statCard, { backgroundColor: '#e3f2fd' }]}>
                <Ionicons name="cash" size={32} color="#3498db" />
                <Text style={styles.statValue}>KSh {stats.totalTransport}</Text>
                <Text style={styles.statLabel}>Total Transport</Text>
              </View>
            </View>
            <View style={styles.earningsCard}>
              <View style={styles.earningsHeader}>
                <Ionicons name="wallet" size={24} color="#2ECC71" />
                <Text style={styles.earningsTitle}>Your Earnings (65%)</Text>
              </View>
              <Text style={styles.earningsAmount}>KSh {stats.paidTransport.toFixed(0)}</Text>
              <Text style={styles.earningsNote}>You earn 65% of every delivery fee</Text>
            </View>

            <TouchableOpacity
              style={styles.actionCard}
              onPress={() => router.push('/(rider)/available')}
            >
              <Ionicons name="flash" size={28} color="#f39c12" />
              <View style={{ flex: 1, marginLeft: 14 }}>
                <Text style={styles.actionTitle}>Available Orders</Text>
                <Text style={styles.actionDesc}>Grab new orders to deliver</Text>
              </View>
              <Ionicons name="chevron-forward" size={24} color="#999" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionCard}
              onPress={() => router.push('/(rider)/my-orders')}
            >
              <Ionicons name="bicycle" size={28} color="#2ECC71" />
              <View style={{ flex: 1, marginLeft: 14 }}>
                <Text style={styles.actionTitle}>My Deliveries</Text>
                <Text style={styles.actionDesc}>View and manage your active orders</Text>
              </View>
              <Ionicons name="chevron-forward" size={24} color="#999" />
            </TouchableOpacity>
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#f8f9fa' },
  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start',
    backgroundColor: '#2ECC71', paddingTop: 55, paddingBottom: 20, paddingHorizontal: 20,
    borderBottomLeftRadius: 24, borderBottomRightRadius: 24,
  },
  greeting: { color: '#c8f7dc', fontSize: 14 },
  userName: { color: '#fff', fontSize: 22, fontWeight: '800' },
  methodBadge: { flexDirection: 'row', alignItems: 'center', backgroundColor: 'rgba(255,255,255,0.25)', borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4, marginTop: 6 },
  methodText: { color: '#fff', fontSize: 12, fontWeight: '600', marginLeft: 4 },
  logoutBtn: { width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(255,255,255,0.25)', justifyContent: 'center', alignItems: 'center' },
  sectionTitle: { fontSize: 18, fontWeight: '700', color: '#1a1a1a', marginBottom: 14 },
  statsGrid: { flexDirection: 'row', gap: 12, marginBottom: 16 },
  statCard: {
    flex: 1, borderRadius: 16, padding: 18, alignItems: 'center',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2,
  },
  statValue: { fontSize: 22, fontWeight: '800', color: '#1a1a1a', marginTop: 8 },
  statLabel: { fontSize: 12, color: '#666', marginTop: 4 },
  earningsCard: {
    backgroundColor: '#fff', borderRadius: 16, padding: 20, marginBottom: 20,
    borderWidth: 2, borderColor: '#2ECC71',
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  earningsHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 8 },
  earningsTitle: { fontSize: 16, fontWeight: '700', color: '#1a5c2e', marginLeft: 8 },
  earningsAmount: { fontSize: 32, fontWeight: '800', color: '#2ECC71' },
  earningsNote: { fontSize: 12, color: '#888', marginTop: 4 },
  actionCard: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#fff',
    borderRadius: 14, padding: 18, marginBottom: 12,
    shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 6, elevation: 3,
  },
  actionTitle: { fontSize: 16, fontWeight: '700', color: '#1a1a1a' },
  actionDesc: { fontSize: 13, color: '#888', marginTop: 2 },
});
